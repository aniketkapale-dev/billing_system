from decimal import Decimal

from django.db import models
from django.utils import timezone

from apps.products.models import Product
from apps.users.models import User
from core.base_entity import BaseEntity


class Purchase(BaseEntity):
    owner = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="purchases",
        db_column="owner_id",
    )
    business = models.ForeignKey(
        "businesses.Business",
        on_delete=models.CASCADE,
        related_name="purchases",
        db_column="business_id",
    )
    supplier_name = models.CharField(max_length=150, blank=True, default="")
    customer_name = models.CharField(max_length=150)
    customer = models.ForeignKey(
        "customers.Customer",
        on_delete=models.SET_NULL,
        related_name="purchases",
        db_column="customer_id",
        null=True,
        blank=True,
    )
    reference_no = models.CharField(max_length=50, blank=True, default="")
    invoice_setting = models.ForeignKey(
        "settings.InvoiceSetting",
        on_delete=models.SET_NULL,
        related_name="purchases",
        db_column="invoice_setting_id",
        null=True,
        blank=True,
    )
    purchase_date = models.DateField(default=timezone.localdate)
    notes = models.TextField(blank=True, default="")
    billing_address = models.TextField(blank=True, default="")
    shipping_address = models.TextField(blank=True, default="")
    payment_type = models.ForeignKey(
        "catalog.PaymentType",
        on_delete=models.SET_NULL,
        related_name="purchases",
        db_column="payment_type_id",
        null=True,
        blank=True,
    )
    total_amount = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0"))
    total_cost = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0"))
    total_profit = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0"))
    is_paid = models.BooleanField(default=False)
    paid_at = models.DateTimeField(null=True, blank=True)
    due_date = models.DateField(null=True, blank=True)
    is_draft = models.BooleanField(default=False)
    is_cancelled = models.BooleanField(default=False)
    cancelled_at = models.DateTimeField(null=True, blank=True)
    cancellation_date = models.DateField(null=True, blank=True)
    cancellation_reason = models.TextField(blank=True, default="")
    invoice_pdf = models.FileField(
        upload_to="sale_invoices/",
        blank=True,
        null=True,
    )

    class Meta:
        db_table = "purchases"
        verbose_name = "Purchase"
        verbose_name_plural = "Purchases"
        ordering = ("-purchase_date", "-created_at")
        indexes = [
            models.Index(
                fields=["business", "is_deleted", "is_draft", "purchase_date"],
                name="idx_purch_biz_status_date",
            ),
            models.Index(
                fields=["business", "reference_no"],
                name="idx_purch_biz_reference",
            ),
            models.Index(
                fields=["business", "customer_name"],
                name="idx_purch_biz_customer",
            ),
        ]

    def __str__(self):
        return self.reference_no or f"Purchase #{self.pk}"


class PurchaseItem(BaseEntity):
    purchase = models.ForeignKey(
        Purchase,
        on_delete=models.CASCADE,
        related_name="items",
        db_column="purchase_id",
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.PROTECT,
        related_name="purchase_items",
        db_column="product_id",
    )
    quantity = models.DecimalField(max_digits=12, decimal_places=2)
    list_price = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0"))
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    line_total = models.DecimalField(max_digits=14, decimal_places=2)
    discount_amount = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0"))
    discount_type = models.CharField(max_length=10, default="percent")
    discount_value = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0"))
    distributor_discount_type = models.CharField(max_length=10, default="percent")
    distributor_discount_value = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0"))
    sale_tax_ids = models.JSONField(default=list, blank=True)
    tax_amount = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0"))
    gst_rate = models.DecimalField(max_digits=6, decimal_places=2, null=True, default=Decimal("0"))
    cost_amount = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0"))
    profit_amount = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0"))

    class Meta:
        db_table = "purchase_items"
        verbose_name = "Purchase Item"
        verbose_name_plural = "Purchase Items"

    def __str__(self):
        return f"{self.product_id} x {self.quantity}"


class PurchasePayment(BaseEntity):
    purchase = models.ForeignKey(
        Purchase,
        on_delete=models.CASCADE,
        related_name="payments",
        db_column="purchase_id",
    )
    amount = models.DecimalField(max_digits=14, decimal_places=2)
    payment_date = models.DateField(default=timezone.localdate)
    next_due_date = models.DateField(null=True, blank=True)
    payment_type = models.ForeignKey(
        "catalog.PaymentType",
        on_delete=models.SET_NULL,
        related_name="purchase_payments",
        db_column="payment_type_id",
        null=True,
        blank=True,
    )
    notes = models.TextField(blank=True, default="")

    class Meta:
        db_table = "purchase_payments"
        verbose_name = "Purchase Payment"
        verbose_name_plural = "Purchase Payments"
        ordering = ("payment_date", "created_at")

    def __str__(self):
        return f"Payment {self.amount} for {self.purchase_id}"


class SaleDueSetting(BaseEntity):
    business = models.ForeignKey(
        "businesses.Business",
        on_delete=models.CASCADE,
        related_name="sale_due_settings",
        db_column="business_id",
    )
    default_due_days_after_sale = models.PositiveIntegerField(
        default=7,
        help_text="Default payment due days after sale date when due date is not entered.",
    )

    class Meta:
        db_table = "sale_due_settings"
        verbose_name = "Sale Due Setting"
        verbose_name_plural = "Sale Due Settings"
        constraints = [
            models.UniqueConstraint(
                fields=["business"],
                condition=models.Q(is_deleted=False),
                name="uniq_active_business_sale_due_setting",
            )
        ]

    def __str__(self):
        return f"Sale due after {self.default_due_days_after_sale} day(s)"
