from apps.products.serializers import ProductSerializer, ProductWriteSerializer
from apps.products.services import ProductService
from core.base_viewset import BaseViewSet
from core.business_viewset import BusinessScopedViewSetMixin
from core.base_response import ApiResponse
from core.permissions import HasRole, IsAuthenticatedUser
from rest_framework import status


class ProductViewSet(BusinessScopedViewSetMixin, BaseViewSet):
    service_class = ProductService
    serializer_class = ProductSerializer
    write_serializer_class = ProductWriteSerializer
    search_fields = ("name", "sku", "hsn_code", "barcode", "description")
    ordering_default = ("-created_at",)
    ordering_fields = {
        "name": "name",
        "sku": "sku",
        "hsn_code": "hsn_code",
        "barcode": "barcode",
        "purchase_price": "purchase_price",
        "category": "category__name",
        "brand": "brand__name",
        "unit": "unit__short_name",
        "created_at": "created_at",
    }
    required_roles = ["Business Owner", "Business Staff"]
    required_tab = "products"
    read_access_tabs = ("purchases", "stock-in", "inventory", "settings-barcode")

    def get_permissions(self):
        return [IsAuthenticatedUser(), HasRole()]

    def list(self, request):
        include_deleted = request.query_params.get("include_deleted") == "true"
        service = self.get_service()
        queryset = (
            service.repository.all_with_deleted()
            if include_deleted
            else service.repository.get_list_queryset()
        )
        queryset = self.filter_queryset(queryset)
        queryset = self._apply_query(queryset)
        return self._paginate(queryset)

    def filter_queryset(self, queryset):
        queryset = super().filter_queryset(queryset)
        category_id = self.request.query_params.get("category_id")
        unit_id = self.request.query_params.get("unit_id")
        if category_id:
            queryset = queryset.filter(category_id=category_id)
        if unit_id:
            queryset = queryset.filter(unit_id=unit_id)
        return queryset

    def create(self, request):
        serializer = self.get_write_serializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        data = self.inject_business_scope(dict(serializer.validated_data))
        instance = self.get_service().create(data)
        payload = self.serializer_class(instance, context={"request": request}).data
        return ApiResponse.success(
            data=payload,
            message="Record created",
            status_code=status.HTTP_201_CREATED,
        )

    def next_sku(self, request):
        business = self.get_active_business()
        sku = self.get_service().get_next_sku(business.id)
        return ApiResponse.success(data={"sku": sku})
