from rest_framework import status

from apps.users.querysets import business_owner_users_queryset
from apps.users.serializers import (
    BusinessOwnerCreateSerializer,
    UserDetailSerializer,
    UserSerializer,
    UserWriteSerializer,
)
from apps.users.services import UserService
from core.base_response import ApiResponse
from core.base_viewset import BaseViewSet
from core.permissions import HasRole, IsAuthenticatedUser


class UserViewSet(BaseViewSet):
    service_class = UserService
    serializer_class = UserSerializer
    write_serializer_class = UserWriteSerializer
    search_fields = ("full_name", "email", "mobile_number")
    required_roles = ["Super Admin"]

    def get_permissions(self):
        return [IsAuthenticatedUser(), HasRole()]

    def filter_queryset(self, queryset):
        queryset = super().filter_queryset(queryset)
        scoped = business_owner_users_queryset()
        return queryset.filter(pk__in=scoped.values("pk"))

    def retrieve(self, request, pk=None):
        instance = self.get_service().get(pk, include_deleted=True)
        data = UserDetailSerializer(instance, context={"request": request}).data
        return ApiResponse.success(data=data, message="User details fetched")

    def create(self, request):
        serializer = BusinessOwnerCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        instance = self.get_service().create_business_owner(serializer.validated_data)
        data = UserSerializer(instance, context={"request": request}).data
        return ApiResponse.success(
            data=data,
            message="Business owner created successfully.",
            status_code=status.HTTP_201_CREATED,
        )

    def destroy(self, request, pk=None):
        self.get_service().hard_delete_business_owner(pk)
        return ApiResponse.success(message="User and all related data deleted permanently")
