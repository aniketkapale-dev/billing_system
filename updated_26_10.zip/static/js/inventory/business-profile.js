var InventoryBusinessProfile = (function () {
    "use strict";

    var API = "/api/businesses";
    var currentBusiness = null;
    var logoFile = null;
    var clearLogo = false;
    var previewBlobUrl = null;

    function request(path, opts) {
        return InventoryApi.request(API, path, opts);
    }

    function formatDateParts(value) {
        if (!value) {
            return { date: "—", time: "—" };
        }
        var parsed = new Date(value);
        if (isNaN(parsed.getTime())) {
            return { date: "—", time: "—" };
        }
        return {
            date: InventoryApi.formatDisplayDate(value, "—"),
            time: parsed.toLocaleTimeString(undefined, {
                hour: "numeric",
                minute: "2-digit",
                second: "2-digit"
            })
        };
    }

    function setMetaDate(prefix, value) {
        var parts = formatDateParts(value);
        var dateEl = document.getElementById(prefix + "-date");
        var timeEl = document.getElementById(prefix + "-time");
        if (dateEl) dateEl.textContent = parts.date;
        if (timeEl) timeEl.textContent = parts.time;
    }

    function togglePanels(hasBusiness) {
        var empty = document.getElementById("business-profile-empty");
        var panel = document.getElementById("business-profile-panel");

        if (empty) empty.classList.toggle("inv-hidden", hasBusiness);
        if (panel) panel.classList.toggle("inv-hidden", !hasBusiness);

        if (window.InventoryBusinessUsers && typeof InventoryBusinessUsers.syncUi === "function") {
            InventoryBusinessUsers.syncUi({ hasBusiness: hasBusiness });
        }
    }

    function revokePreviewBlob() {
        if (previewBlobUrl) {
            URL.revokeObjectURL(previewBlobUrl);
            previewBlobUrl = null;
        }
    }

    function setLogoPreview(url) {
        var preview = document.getElementById("business-profile-logo-preview");
        var clearBtn = document.getElementById("business-profile-logo-clear");
        if (!preview) return;

        if (url) {
            preview.innerHTML = '<img src="' + InventoryApi.escapeHtml(url) + '" alt="Business logo"/>';
            if (clearBtn) clearBtn.classList.remove("inv-hidden");
            return;
        }

        preview.innerHTML = '<span class="material-symbols-outlined">storefront</span>';
        if (clearBtn) clearBtn.classList.add("inv-hidden");
    }

    function clearLogoInput() {
        logoFile = null;
        var input = document.getElementById("business-profile-logo");
        if (input) input.value = "";
    }

    function resetLogoState() {
        clearLogo = false;
        clearLogoInput();
        revokePreviewBlob();
    }

    function populateForm(business) {
        currentBusiness = business;
        document.getElementById("business-profile-name").value = business.business_name || "";
        document.getElementById("business-profile-gst").value = business.gst_number || "";
        document.getElementById("business-profile-phone").value = business.phone || "";
        document.getElementById("business-profile-email").value = business.email || "";
        document.getElementById("business-profile-state-code").value = business.state_code || "";
        document.getElementById("business-profile-pin-code").value = business.pin_code || "";
        document.getElementById("business-profile-address").value = business.address || "";
        document.getElementById("business-profile-bank-details").value = business.bank_details || "";
        document.getElementById("business-profile-owner").textContent = business.owner_name || "—";
        setMetaDate("business-profile-created", business.created_at);
        setMetaDate("business-profile-updated", business.updated_at);

        resetLogoState();
        setLogoPreview(business.logo_url || null);
        updateDeleteAction(business);
        togglePanels(true);
        window.dispatchEvent(new CustomEvent("inventory:business-profile-loaded"));
    }

    function updateDeleteAction(business) {
        var deleteBtn = document.getElementById("business-profile-delete-btn");
        var hintEl = document.getElementById("business-profile-delete-hint");
        var canDelete = !!(business && business.is_owner && business.can_delete);

        if (deleteBtn) {
            deleteBtn.classList.toggle("inv-hidden", !canDelete);
        }

        if (hintEl) {
            var showHint = !!(business && business.is_owner && !business.can_delete);
            hintEl.classList.toggle("inv-hidden", !showHint);
        }
    }

    function loadActiveBusiness() {
        var activeId = InventoryBusiness.getActiveId();
        if (!activeId) {
            currentBusiness = null;
            togglePanels(false);
            return Promise.resolve();
        }

        InventoryLoader.show();
        return request("/" + activeId + "/")
            .then(function (body) {
                if (body && body.isSuccess && body.data) {
                    populateForm(body.data);
                    return;
                }
                currentBusiness = null;
                togglePanels(false);
                InventoryToast.error(body && body.message ? body.message : "Failed to load business.");
            })
            .catch(function () {
                currentBusiness = null;
                togglePanels(false);
                InventoryToast.error("Network error while loading business.");
            })
            .finally(function () {
                InventoryLoader.hide();
            });
    }

    function collectPayload() {
        var businessName = document.getElementById("business-profile-name").value.trim();
        if (!businessName) {
            InventoryToast.error("Business name is required.");
            return null;
        }

        var phone = document.getElementById("business-profile-phone").value.trim();
        if (phone && (!window.InventoryAuth || !InventoryAuth.isValidMobile(phone))) {
            InventoryToast.error("Enter a valid 10-digit mobile number.");
            var phoneInput = document.getElementById("business-profile-phone");
            if (phoneInput) phoneInput.focus();
            return null;
        }

        var stateCode = document.getElementById("business-profile-state-code").value.trim();
        if (stateCode && (!/^\d{1,2}$/.test(stateCode))) {
            InventoryToast.error("Enter a valid GST state code (1–2 digits).");
            var stateInput = document.getElementById("business-profile-state-code");
            if (stateInput) stateInput.focus();
            return null;
        }

        var pinInput = document.getElementById("business-profile-pin-code");
        var pinCode = pinInput ? pinInput.value.trim() : "";
        if (window.InventoryPinCodeInput) {
            pinCode = InventoryPinCodeInput.normalize(pinCode);
            if (pinInput) pinInput.value = pinCode;
            if (!InventoryPinCodeInput.isValid(pinCode, true)) {
                InventoryToast.error("Enter a valid 6-digit pin code.");
                pinInput.focus();
                return null;
            }
        } else if (pinCode && (!/^\d{6}$/.test(pinCode))) {
            InventoryToast.error("Enter a valid 6-digit pin code.");
            if (pinInput) pinInput.focus();
            return null;
        }

        if (logoFile || clearLogo) {
            var formData = new FormData();
            formData.append("business_name", businessName);
            formData.append("gst_number", document.getElementById("business-profile-gst").value.trim());
            formData.append("phone", document.getElementById("business-profile-phone").value.trim());
            formData.append("email", document.getElementById("business-profile-email").value.trim());
            formData.append("state_code", stateCode);
            formData.append("pin_code", pinCode);
            formData.append("address", document.getElementById("business-profile-address").value.trim());
            formData.append("bank_details", document.getElementById("business-profile-bank-details").value.trim());
            if (logoFile) formData.append("logo", logoFile);
            if (clearLogo) formData.append("clear_logo", "true");
            return formData;
        }

        return {
            business_name: businessName,
            gst_number: document.getElementById("business-profile-gst").value.trim(),
            phone: document.getElementById("business-profile-phone").value.trim(),
            email: document.getElementById("business-profile-email").value.trim(),
            state_code: stateCode,
            pin_code: pinCode,
            address: document.getElementById("business-profile-address").value.trim(),
            bank_details: document.getElementById("business-profile-bank-details").value.trim()
        };
    }

    function deleteBusiness() {
        if (!currentBusiness || !currentBusiness.id || !currentBusiness.can_delete) {
            InventoryToast.error("This business cannot be deleted.");
            return;
        }

        var businessName = currentBusiness.business_name || "this business";
        InventoryConfirm.delete({
            title: "Delete business?",
            message: "Are you sure you want to delete " + businessName + "? This action cannot be undone."
        }).then(function (confirmed) {
            if (!confirmed) return;

            var btn = document.getElementById("business-profile-delete-btn");
            InventoryLoader.button(btn, true, "Deleting...");

            return request("/" + currentBusiness.id + "/", { method: "DELETE" })
                .then(function (body) {
                    if (body && body.isSuccess) {
                        InventoryToast.success(body.message || "Business deleted successfully.");
                        currentBusiness = null;
                        togglePanels(false);
                        updateDeleteAction(null);
                        return InventoryBusiness.reload();
                    }
                    InventoryToast.error(body.message || "Unable to delete business.");
                })
                .catch(function () {
                    InventoryToast.error("Network error. Please try again.");
                })
                .finally(function () {
                    InventoryLoader.button(btn, false);
                });
        });
    }

    function saveBusiness(e) {
        if (e) e.preventDefault();
        if (!currentBusiness || !currentBusiness.id) {
            InventoryToast.error("No active business selected.");
            return;
        }

        var payload = collectPayload();
        if (!payload) return;

        var btn = document.getElementById("business-profile-save-btn");
        InventoryLoader.button(btn, true, "Saving...");

        request("/" + currentBusiness.id + "/", {
            method: "PATCH",
            body: payload
        })
            .then(function (body) {
                if (body && body.isSuccess && body.data) {
                    InventoryToast.success("Business updated successfully.");
                    populateForm(body.data);
                    return InventoryBusiness.reload();
                }
                var err = body.message || "Unable to update business.";
                if (body.errors && body.errors.length) err = body.errors.join(" • ");
                InventoryToast.error(err);
            })
            .catch(function () {
                InventoryToast.error("Network error. Please try again.");
            })
            .finally(function () {
                InventoryLoader.button(btn, false);
            });
    }

    function init() {
        var form = document.getElementById("business-profile-form");
        var logoInput = document.getElementById("business-profile-logo");
        var clearBtn = document.getElementById("business-profile-logo-clear");
        var emptyAddBtn = document.getElementById("business-profile-empty-add-btn");
        var deleteBtn = document.getElementById("business-profile-delete-btn");

        if (form) form.addEventListener("submit", saveBusiness);
        if (deleteBtn) deleteBtn.addEventListener("click", deleteBusiness);

        if (logoInput) {
            logoInput.addEventListener("change", function () {
                var file = logoInput.files && logoInput.files[0] ? logoInput.files[0] : null;
                if (!file) return;
                clearLogo = false;
                revokePreviewBlob();
                logoFile = file;
                previewBlobUrl = URL.createObjectURL(file);
                setLogoPreview(previewBlobUrl);
            });
        }

        if (clearBtn) {
            clearBtn.addEventListener("click", function () {
                clearLogo = true;
                clearLogoInput();
                revokePreviewBlob();
                setLogoPreview(null);
            });
        }

        if (emptyAddBtn) {
            emptyAddBtn.addEventListener("click", function () {
                var addBtn = document.getElementById("inv-business-add-btn");
                if (addBtn) addBtn.click();
            });
        }

        if (window.InventoryAuth && typeof InventoryAuth.wireMobileInput === "function") {
            InventoryAuth.wireMobileInput(document.getElementById("business-profile-phone"));
        }

        InventoryBusiness.whenReady(loadActiveBusiness);
        window.addEventListener("inventory:business-changed", loadActiveBusiness);
        window.addEventListener("inventory:nav-access-changed", function () {
            togglePanels(!!currentBusiness);
        });
    }

    return { init: init, loadActiveBusiness: loadActiveBusiness };
})();
