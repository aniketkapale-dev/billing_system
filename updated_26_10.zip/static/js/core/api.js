/**
 * Shared authenticated API helper for business-owner inventory pages.
 */
var InventoryApi = (function () {
    "use strict";

    var TOKEN_KEY = "vrms_access_token";
    var REFRESH_KEY = "vrms_refresh_token";
    var USER_KEY = "vrms_user";
    var LOGIN_URL = "/login/";
    var AUTH_API = "/api/auth";

    // Invalidate reference data after writes, across tabs, and on returning online.
    var dataWatchers = [];
    var CHANGE_KEY = "billing:data-change";
    var observedRevision = null;
    var observedRevisionBusiness = "";
    var revisionRequest = null;
    function activeBusinessId() {
        return window.InventoryBusiness ? String(InventoryBusiness.getActiveId() || "") : "";
    }
    function refreshWatchers(change) {
        if (document.hidden) return;
        dataWatchers.forEach(function (watcher) {
            if (change && change.business && change.business !== activeBusinessId()) return;
            if (change && !watcher.paths.some(function (path) { return change.path.indexOf(path) === 0; })) return;
            clearTimeout(watcher.timer);
            watcher.timer = setTimeout(function run() {
                if (document.hidden) return;
                if (watcher.running) { watcher.timer = setTimeout(run, 300); return; }
                watcher.running = true;
                Promise.resolve().then(watcher.refresh).catch(function () {
                    // Keep the current form intact; retry on the next notification/focus.
                }).finally(function () { watcher.running = false; });
            }, 400);
        });
    }
    function publishChange(path, business) {
        var change = { path: path, business: business, revision: Date.now() + Math.random() };
        refreshWatchers(change);
        try { localStorage.setItem(CHANGE_KEY, JSON.stringify(change)); } catch (e) {}
    }
    function watch(paths, refresh) {
        dataWatchers.push({ paths: paths, refresh: refresh, running: false, timer: null });
    }
    function pollDataRevision() {
        var business = activeBusinessId();
        if (document.hidden || !business || revisionRequest) return;
        if (observedRevisionBusiness !== business) {
            observedRevisionBusiness = business;
            observedRevision = null;
        }
        revisionRequest = request("/api/businesses", "/revision/", { skipBusiness: false })
            .then(function (body) {
                if (!body || !body.isSuccess || !body.data) return;
                var revision = String(body.data.revision);
                if (observedRevision !== null && revision !== observedRevision) refreshWatchers();
                observedRevision = revision;
            })
            .catch(function () {})
            .finally(function () { revisionRequest = null; });
    }
    window.addEventListener("storage", function (event) {
        if (event.key !== CHANGE_KEY || !event.newValue) return;
        try { refreshWatchers(JSON.parse(event.newValue)); } catch (e) {}
    });
    window.addEventListener("focus", function () { refreshWatchers(); });
    window.addEventListener("online", function () { refreshWatchers(); });
    document.addEventListener("visibilitychange", function () {
        if (!document.hidden) {
            refreshWatchers();
            pollDataRevision();
        }
    });
    window.addEventListener("inventory:business-changed", function () {
        observedRevision = null;
        observedRevisionBusiness = activeBusinessId();
        pollDataRevision();
    });
    // The revision endpoint is shared by browser profiles; localStorage handles same-profile tabs immediately.
    setInterval(function () {
        pollDataRevision();
    }, 3000);

    var refreshPromise = null;
    var expiryTimer = null;
    var loggingOut = false;

    function decodeJwtPayload(token) {
        var parts = String(token || "").split(".");
        if (parts.length < 2) return null;

        var base64 = parts[1].replace(/-/g, "+").replace(/_/g, "/");
        var pad = base64.length % 4;
        if (pad) base64 += new Array(5 - pad).join("=");

        try {
            return JSON.parse(atob(base64));
        } catch (e) {
            return null;
        }
    }

    function clearSession() {
        localStorage.removeItem(TOKEN_KEY);
        localStorage.removeItem(REFRESH_KEY);
        localStorage.removeItem(USER_KEY);
    }

    function logoutAndRedirect(message) {
        if (loggingOut) return;
        loggingOut = true;

        if (expiryTimer) {
            clearTimeout(expiryTimer);
            expiryTimer = null;
        }

        clearSession();

        if (message && typeof InventoryToast !== "undefined") {
            InventoryToast.warning(message);
        }

        window.location.replace(LOGIN_URL);
    }

    function tryRefreshToken() {
        if (refreshPromise) return refreshPromise;

        var refresh = localStorage.getItem(REFRESH_KEY);
        if (!refresh) return Promise.resolve(false);

        refreshPromise = fetch(AUTH_API + "/refresh/", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ refresh: refresh }),
            cache: "no-store"
        })
            .then(function (res) {
                return res.json();
            })
            .then(function (body) {
                if (body && body.isSuccess && body.data && body.data.access) {
                    localStorage.setItem(TOKEN_KEY, body.data.access);
                    scheduleSessionExpiry();
                    return true;
                }
                return false;
            })
            .catch(function () {
                return false;
            })
            .finally(function () {
                refreshPromise = null;
            });

        return refreshPromise;
    }

    function handleSessionExpired() {
        return tryRefreshToken().then(function (ok) {
            if (!ok) {
                logoutAndRedirect("Your session has expired. Please sign in again.");
            }
            return ok;
        });
    }

    function scheduleSessionExpiry() {
        if (expiryTimer) {
            clearTimeout(expiryTimer);
            expiryTimer = null;
        }

        var token = localStorage.getItem(TOKEN_KEY);
        var payload = decodeJwtPayload(token);
        if (!payload || !payload.exp) return;

        var expiresAt = payload.exp * 1000;
        var delay = expiresAt - Date.now();

        if (delay <= 0) {
            handleSessionExpired();
            return;
        }

        expiryTimer = window.setTimeout(function () {
            handleSessionExpired();
        }, Math.max(delay - 2000, 0));
    }

    function buildUrl(basePath, path) {
        path = path == null ? "" : String(path);
        var base = basePath.replace(/\/+$/, "");
        if (!path) {
            return base + "/";
        }
        if (path.charAt(0) === "?") {
            return base + "/" + path;
        }
        if (path.charAt(0) !== "/") {
            path = "/" + path;
        }
        return base + path;
    }

    function authHeaders(opts) {
        opts = opts || {};
        var headers = { "Content-Type": "application/json" };
        var token = localStorage.getItem(TOKEN_KEY);
        if (token) headers["Authorization"] = "Bearer " + token;

        if (!opts.skipBusiness && window.InventoryBusiness) {
            var businessId = InventoryBusiness.getActiveId();
            if (businessId) headers["X-Business-Id"] = businessId;
        }
        return headers;
    }

    function parseResponse(res) {
        var ct = res.headers.get("content-type") || "";
        if (ct.indexOf("application/json") === -1) {
            return {
                isSuccess: res.ok,
                data: {},
                errors: [],
                message: res.statusText,
                _status: res.status
            };
        }
        return res.json().then(function (body) {
            body._status = res.status;
            return body;
        });
    }

    function request(basePath, path, opts) {
        opts = opts || {};
        var skipBusiness = opts.skipBusiness;
        if (skipBusiness === undefined) {
            skipBusiness = String(basePath).indexOf("/api/businesses") !== -1;
        }

        function doFetch() {
            var headers = authHeaders({ skipBusiness: skipBusiness });
            var body = undefined;
            if (opts.body instanceof FormData) {
                delete headers["Content-Type"];
                body = opts.body;
            } else if (opts.body) {
                body = JSON.stringify(opts.body);
            }
            return fetch(buildUrl(basePath, path), {
                method: opts.method || "GET",
                headers: headers,
                body: body,
                cache: "no-store"
            });
        }

        function execute(retrying) {
            return doFetch().then(function (res) {
                if (res.status === 401 && !retrying) {
                    return tryRefreshToken().then(function (ok) {
                        if (ok) return execute(true);
                        logoutAndRedirect("Your session has expired. Please sign in again.");
                        return parseResponse(res);
                    });
                }
                return parseResponse(res);
            });
        }

        var writeBusiness = skipBusiness ? "" : activeBusinessId();
        return execute(false).then(function (response) {
            if (["POST", "PUT", "PATCH", "DELETE"].indexOf(String(opts.method || "GET").toUpperCase()) !== -1 && response && response.isSuccess) {
                publishChange(buildUrl(basePath, path), writeBusiness);
            }
            return response;
        });
    }

    function authFetch(url, fetchOpts, retrying) {
        fetchOpts = fetchOpts || {};
        var headers = Object.assign({}, fetchOpts.headers || {});
        var token = localStorage.getItem(TOKEN_KEY);
        if (token) headers["Authorization"] = "Bearer " + token;

        var nextOpts = Object.assign({}, fetchOpts, {
            headers: headers,
            cache: "no-store"
        });

        return fetch(url, nextOpts).then(function (res) {
            if (res.status === 401 && !retrying) {
                return tryRefreshToken().then(function (ok) {
                    if (ok) return authFetch(url, fetchOpts, true);
                    logoutAndRedirect("Your session has expired. Please sign in again.");
                    return res;
                });
            }
            return res;
        });
    }

    function escapeHtml(str) {
        var div = document.createElement("div");
        div.textContent = str == null ? "" : String(str);
        return div.innerHTML;
    }

    function formatMoney(value) {
        var num = Number(value || 0);
        return num.toFixed(2);
    }

    function renderViewGrid(rows, options) {
        options = options || {};
        var colsPerRow = options.columns || 4;
        var html = [];
        var buffer = [];

        function renderItem(row) {
            var cls = "inv-product-view-item";
            if (row.full) cls += " inv-product-view-item--full";
            if (row.colStart === 1) cls += " inv-product-view-item--col-1";
            if (row.emphasis) cls += " inv-product-view-item--emphasis";
            if (row.num) cls += " inv-product-view-item--num";
            return (
                '<div class="' + cls + '">' +
                '<span class="inv-product-view-label">' + String(row.label) + "</span>" +
                '<div class="inv-product-view-value">' + row.value + "</div>" +
                "</div>"
            );
        }

        function flushRow() {
            if (!buffer.length) return;
            html.push('<div class="inv-product-view-row">' + buffer.join("") + "</div>");
            buffer = [];
        }

        (rows || []).forEach(function (row) {
            if (row.full) {
                flushRow();
                html.push('<div class="inv-product-view-row">' + renderItem(row) + "</div>");
                return;
            }
            if (row.colStart === 1 && buffer.length) {
                flushRow();
            }
            buffer.push(renderItem(row));
            if (buffer.length >= colsPerRow) {
                flushRow();
            }
        });
        flushRow();
        return html.join("");
    }

    function formatDisplayDate(value, emptyValue) {
        if (typeof InventoryDateFormat !== "undefined") {
            return InventoryDateFormat.formatDisplayDate(value, emptyValue);
        }
        return value == null || String(value).trim() === "" ? (emptyValue !== undefined ? emptyValue : "") : String(value);
    }

    function formatDateTime(value, emptyValue) {
        if (typeof InventoryDateFormat !== "undefined") {
            return InventoryDateFormat.formatDateTime(value, emptyValue);
        }
        return formatDisplayDate(value, emptyValue);
    }

    function toInputDateValue(value) {
        if (typeof InventoryDateFormat !== "undefined") {
            return InventoryDateFormat.toInputDateValue(value);
        }
        return value == null ? "" : String(value).slice(0, 10);
    }

    function getDateInputValue(el) {
        if (!el) return "";
        if (typeof InventoryDateInput !== "undefined") {
            return InventoryDateInput.getValue(el);
        }
        return (el.value || "").trim();
    }

    function setDateInputValue(el, iso) {
        if (!el) return;
        if (typeof InventoryDateInput !== "undefined") {
            InventoryDateInput.setValue(el, iso);
            return;
        }
        el.value = iso || "";
    }

    function setDateInputMin(el, iso) {
        if (!el || typeof InventoryDateInput === "undefined") return;
        InventoryDateInput.setMin(el, iso);
    }

    return {
        watch: watch,
        buildUrl: buildUrl,
        request: request,
        authFetch: authFetch,
        clearSession: clearSession,
        logoutAndRedirect: logoutAndRedirect,
        scheduleSessionExpiry: scheduleSessionExpiry,
        escapeHtml: escapeHtml,
        formatMoney: formatMoney,
        formatDisplayDate: formatDisplayDate,
        formatDateTime: formatDateTime,
        toInputDateValue: toInputDateValue,
        getDateInputValue: getDateInputValue,
        setDateInputValue: setDateInputValue,
        setDateInputMin: setDateInputMin,
        renderViewGrid: renderViewGrid
    };
})();
