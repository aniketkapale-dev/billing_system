var InventoryCustomers = (function () {
    "use strict";

    var API = "/api/customers";
    var LIST_PANEL = "customers-list-panel";
    var FORM_PANEL = "customers-form-panel";
    var VIEW_PANEL = "customers-view-panel";
    var currentPage = 1;
    var currentSearch = "";
    var currentOrdering = "name";
    var searchTimer = null;
    var editingId = null;
    var cachedItems = [];
    var bulkSelect = null;
    var columnCtrl = null;

    function getColumnCtrl() {
        if (!columnCtrl && isListPage()) {
            columnCtrl = InventoryColumnCustomize.create({
                tableKey: "customers",
                theadSelector: ".inv-mgmt-table--customers thead tr",
                toolbarSelector: "#customers-list-panel .inv-mgmt-toolbar",
                includeBulkCheck: false,
                bulkHeaderHtml: '<th class="inv-col-check d-none"><input type="checkbox" class="inv-bulk-select-all" aria-label="Select all"/></th>',
                sortDefault: "name",
                onSortChange: function (ordering) {
                    currentOrdering = ordering;
                    loadCustomers(1);
                },
                columns: [
                    {
                        id: "name",
                        label: "Full Name",
                        locked: true,
                        sortKey: "name",
                        cell: function (item) { return "<td>" + displayValue(item.name) + "</td>"; }
                    },
                    {
                        id: "mobile",
                        label: "Mobile",
                        sortKey: "mobile",
                        cell: function (item) { return "<td>" + displayValue(item.mobile) + "</td>"; }
                    },
                    {
                        id: "email",
                        label: "Email",
                        sortKey: "email",
                        cell: function (item) { return "<td>" + displayValue(item.email) + "</td>"; }
                    },
                    {
                        id: "address",
                        label: "Address",
                        sortKey: "address",
                        cell: function (item) { return "<td>" + displayValue(item.address) + "</td>"; }
                    }
                ],
                onApply: function () {
                    renderRows(cachedItems);
                }
            });
            columnCtrl.mount();
            columnCtrl.renderHeader();
        }
        return columnCtrl;
    }

    function getBulkSelect() {
        if (!bulkSelect && isListPage()) {
            bulkSelect = InventoryBulkSelect.create({
                tbodyId: "customers-table-body",
                tableSelector: ".inv-mgmt-table--customers",
                entitySingular: "Customer",
                entityPlural: "Customers",
                onDelete: bulkDeleteCustomers,
                onPdf: exportCustomersPdf,
                onPrint: exportCustomersPrint
            });
        }
        return bulkSelect;
    }

    function getSelectedItems(ids) {
        return cachedItems.filter(function (item) {
            return ids.indexOf(String(item.id)) !== -1;
        });
    }

    function exportCustomersPdf(ids) {
        var items = getSelectedItems(ids);
        if (!items.length) return;
        InventoryDocumentExport.downloadTablePdf(
            "Customers",
            ["Full Name", "Mobile", "Email", "Address"],
            items.map(function (item) {
                return [item.name || "", item.mobile || "", item.email || "", item.address || ""];
            }),
            "customers.pdf"
        );
    }

    function exportCustomersPrint(ids) {
        var items = getSelectedItems(ids);
        if (!items.length) return;
        var html = InventoryDocumentExport.buildTableHtml(
            "Customers",
            ["Full Name", "Mobile", "Email", "Address"],
            items.map(function (item) {
                return [item.name || "", item.mobile || "", item.email || "", item.address || ""];
            })
        );
        InventoryDocumentExport.printHtml("Customers", html);
    }

    function bulkDeleteCustomers(ids) {
        InventoryConfirm.delete({
            title: "Delete selected customers?",
            message: ids.length + " customer(s) will be removed."
        }).then(function (confirmed) {
            if (!confirmed) return;

            InventoryLoader.show();
            var chain = Promise.resolve();
            var deleted = 0;
            var failed = 0;

            ids.forEach(function (id) {
                chain = chain.then(function () {
                    return request(String(id) + "/", { method: "DELETE" }).then(function (body) {
                        if (body && body.isSuccess) {
                            deleted++;
                            getBulkSelect().removeId(id);
                        } else {
                            failed++;
                        }
                    }).catch(function () {
                        failed++;
                    });
                });
            });

            chain.finally(function () {
                InventoryLoader.hide();
                if (deleted) InventoryToast.success(deleted + " customer(s) deleted.");
                if (failed) InventoryToast.error(failed + " customer(s) could not be deleted.");
                getBulkSelect().clearSelection();
                loadCustomers(currentPage);
            });
        });
    }

    function request(path, opts) {
        return InventoryApi.request(API, path, opts);
    }

    function isModalMode() {
        return !!document.getElementById("customer-modal");
    }

    function isListPage() {
        return !!document.getElementById("customers-list-panel");
    }

    function buildQuery(page) {
        var params = new URLSearchParams();
        params.set("page", String(page || 1));
        params.set("page_size", String(InventoryPagination.getPageSize("customers-pagination")));
        if (currentSearch) params.set("search", currentSearch);
        if (currentOrdering) params.set("ordering", currentOrdering);
        return "?" + params.toString();
    }

    function displayValue(value) {
        if (value === null || value === undefined || String(value).trim() === "") return "—";
        return InventoryApi.escapeHtml(String(value));
    }

    function formatDate(value) {
        return InventoryApi.formatDateTime(value, "—");
    }

    function renderRows(items) {
        var tbody = document.getElementById("customers-table-body");
        if (!tbody) return;

        var cols = getColumnCtrl();
        var colspan = cols ? cols.getColspan() : 6;

        if (!items || !items.length) {
            tbody.innerHTML = '<tr><td colspan="' + colspan + '" class="inv-mgmt-empty">No customers found.</td></tr>';
            return;
        }

        cachedItems = items;

        tbody.innerHTML = items.map(function (item) {
            return (
                "<tr>" +
                cols.renderRowCells(item) +
                '<td class="inv-col-action inv-mgmt-cell--action"><div class="inv-row-actions">' +
                '<button type="button" class="inv-row-action-btn inv-row-action-btn--view customer-view" data-id="' + item.id + '" title="View" aria-label="View customer">' +
                '<span class="material-symbols-outlined">visibility</span></button>' +
                '<button type="button" class="inv-row-action-btn inv-row-action-btn--edit customer-edit" data-id="' + item.id + '" title="Edit" aria-label="Edit customer">' +
                '<span class="material-symbols-outlined">edit</span></button>' +
                '<button type="button" class="inv-row-action-btn inv-row-action-btn--delete customer-delete" data-id="' + item.id + '" title="Delete" aria-label="Delete customer">' +
                '<span class="material-symbols-outlined">delete</span></button>' +
                "</div></td></tr>"
            );
        }).join("");
    }

    function loadCustomers(page) {
        currentPage = page || 1;
        InventoryLoader.show();
        return request(buildQuery(currentPage))
            .then(function (body) {
                if (body && body.isSuccess && body.data) {
                    renderRows(body.data.items || []);
                    InventoryPagination.render("customers-pagination", body.data.pagination, function (p) {
                        loadCustomers(p);
                    }, {
                        onPageSizeChange: function () {
                            loadCustomers(1);
                        }
                    });
                } else {
                    renderRows([]);
                    InventoryPagination.render("customers-pagination", null, function () {});
                    InventoryToast.error(body && body.message ? body.message : "Failed to load customers.");
                }
            })
            .catch(function () {
                renderRows([]);
                InventoryToast.error("Network error while loading customers.");
            })
            .finally(function () {
                InventoryLoader.hide();
            });
    }

    function setBusinessFieldsVisible(show) {
        var panel = document.getElementById("customer-business-fields");
        var checkbox = document.getElementById("customer-add-business");
        if (checkbox) checkbox.checked = !!show;
        if (panel) panel.classList.toggle("inv-hidden", !show);
    }

    function hasBusinessData(customer) {
        if (!customer) return false;
        return !!(
            (customer.company_name && String(customer.company_name).trim()) ||
            (customer.company_mobile && String(customer.company_mobile).trim()) ||
            (customer.gst_number && String(customer.gst_number).trim()) ||
            (customer.business_address && String(customer.business_address).trim()) ||
            (customer.shipping_address && String(customer.shipping_address).trim())
        );
    }

    function resetForm() {
        editingId = null;
        document.getElementById("customer-name").value = "";
        document.getElementById("customer-mobile").value = "";
        document.getElementById("customer-email").value = "";
        document.getElementById("customer-pin-code").value = "";
        document.getElementById("customer-address").value = "";
        document.getElementById("customer-company-name").value = "";
        document.getElementById("customer-company-mobile").value = "";
        document.getElementById("customer-gst").value = "";
        document.getElementById("customer-business-address").value = "";
        document.getElementById("customer-shipping-address").value = "";
        setBusinessFieldsVisible(false);
        var formTitle = document.getElementById("customer-form-title");
        var modalTitle = document.getElementById("customer-modal-title");
        var saveBtn = document.getElementById("customer-save-btn");
        if (formTitle) formTitle.textContent = "Add Customer";
        if (modalTitle) modalTitle.textContent = "Add Customer";
        if (saveBtn) saveBtn.textContent = "Save Customer";
    }

    function populateForm(customer) {
        document.getElementById("customer-name").value = customer.name || "";
        document.getElementById("customer-mobile").value = customer.mobile || "";
        document.getElementById("customer-email").value = customer.email || "";
        document.getElementById("customer-pin-code").value = customer.pin_code || "";
        document.getElementById("customer-address").value = customer.address || "";
        document.getElementById("customer-company-name").value = customer.company_name || "";
        document.getElementById("customer-company-mobile").value = customer.company_mobile || "";
        document.getElementById("customer-gst").value = customer.gst_number || "";
        document.getElementById("customer-business-address").value = customer.business_address || "";
        document.getElementById("customer-shipping-address").value = customer.shipping_address || "";
        setBusinessFieldsVisible(hasBusinessData(customer));
    }

    function isValidMobile(value) {
        if (window.InventoryAuth && typeof InventoryAuth.isValidMobile === "function") {
            return InventoryAuth.isValidMobile(value);
        }
        return /^[0-9]{10}$/.test(String(value || "").trim());
    }

    function isValidPinCode(value) {
        return /^[0-9]{6}$/.test(String(value || "").trim());
    }

    function collectPayload() {
        var name = document.getElementById("customer-name").value.trim();
        var mobile = document.getElementById("customer-mobile").value.trim();
        var email = document.getElementById("customer-email").value.trim();
        var pinCode = document.getElementById("customer-pin-code").value.trim();
        var address = document.getElementById("customer-address").value.trim();
        var addBusiness = document.getElementById("customer-add-business").checked;
        var companyName = document.getElementById("customer-company-name").value.trim();
        var companyMobile = document.getElementById("customer-company-mobile").value.trim();
        var gstNumber = document.getElementById("customer-gst").value.trim();
        var businessAddress = document.getElementById("customer-business-address").value.trim();
        var shippingAddress = document.getElementById("customer-shipping-address").value.trim();

        if (!name) {
            InventoryToast.error("Full name is required.");
            document.getElementById("customer-name").focus();
            return null;
        }
        if (!mobile) {
            InventoryToast.error("Mobile number is required.");
            document.getElementById("customer-mobile").focus();
            return null;
        }
        if (!isValidMobile(mobile)) {
            InventoryToast.error("Enter a valid 10-digit mobile number.");
            document.getElementById("customer-mobile").focus();
            return null;
        }
        if (!pinCode) {
            InventoryToast.error("Pin code is required.");
            document.getElementById("customer-pin-code").focus();
            return null;
        }
        if (!isValidPinCode(pinCode)) {
            InventoryToast.error("Enter a valid 6-digit pin code.");
            document.getElementById("customer-pin-code").focus();
            return null;
        }
        if (!address) {
            InventoryToast.error("Address is required.");
            document.getElementById("customer-address").focus();
            return null;
        }

        if (addBusiness && !companyName) {
            InventoryToast.error("Company name is required when Add company is selected.");
            document.getElementById("customer-company-name").focus();
            return null;
        }
        if (addBusiness && companyMobile && !isValidMobile(companyMobile)) {
            InventoryToast.error("Enter a valid 10-digit company mobile number.");
            document.getElementById("customer-company-mobile").focus();
            return null;
        }

        return {
            name: name,
            mobile: mobile,
            email: email,
            pin_code: pinCode,
            address: address,
            company_name: addBusiness ? companyName : "",
            company_mobile: addBusiness ? companyMobile : "",
            gst_number: addBusiness ? gstNumber : "",
            business_address: addBusiness ? businessAddress : "",
            shipping_address: addBusiness ? shippingAddress : ""
        };
    }

    function openFormPanel() {
        resetForm();
        InventoryPagePanel.showPanel(LIST_PANEL, FORM_PANEL);
        document.getElementById("customer-name").focus();
    }

    function openAddModal() {
        if (!InventoryBusiness.getActiveId()) {
            InventoryToast.error("Select or create a business first.");
            return;
        }
        resetForm();
        if (isModalMode()) {
            InventoryModal.open("customer-modal");
            document.getElementById("customer-name").focus();
            return;
        }
        openFormPanel();
    }

    function renderViewDetails(customer) {
        var container = document.getElementById("customer-view-body");
        if (!container) return;

        var rows = [
            { label: "Full Name", value: displayValue(customer.name), emphasis: true },
            { label: "Mobile", value: displayValue(customer.mobile) },
            { label: "Email", value: displayValue(customer.email) },
            { label: "Pin Code", value: displayValue(customer.pin_code) },
            { label: "Address", value: displayValue(customer.address), full: true }
        ];

        if (hasBusinessData(customer)) {
            rows.push(
                { label: "Company Name", value: displayValue(customer.company_name) },
                { label: "Company Mobile", value: displayValue(customer.company_mobile) },
                { label: "GST No", value: displayValue(customer.gst_number) },
                { label: "Company Address", value: displayValue(customer.business_address), full: true },
                { label: "Shipping Address", value: displayValue(customer.shipping_address), full: true }
            );
        }

        rows.push(
            { label: "Created", value: displayValue(formatDate(customer.created_at)) },
            { label: "Last Updated", value: displayValue(formatDate(customer.updated_at)) }
        );

        container.innerHTML = InventoryApi.renderViewGrid(rows);
    }

    function openViewPanel(id) {
        InventoryLoader.show();
        request("/" + id + "/")
            .then(function (body) {
                if (!body || !body.isSuccess || !body.data) {
                    InventoryToast.error(body && body.message ? body.message : "Failed to load customer.");
                    return;
                }
                var customer = body.data;
                var titleEl = document.getElementById("customer-view-title");
                if (titleEl) titleEl.textContent = customer.name || "Customer Details";
                renderViewDetails(customer);
                InventoryPagePanel.showPanel(LIST_PANEL, VIEW_PANEL);
            })
            .catch(function () {
                InventoryToast.error("Network error while loading customer.");
            })
            .finally(function () {
                InventoryLoader.hide();
            });
    }

    function openEditPanel(id) {
        InventoryLoader.show();
        request("/" + id + "/")
            .then(function (body) {
                if (!body || !body.isSuccess || !body.data) {
                    InventoryToast.error(body && body.message ? body.message : "Failed to load customer.");
                    return;
                }
                editingId = body.data.id;
                populateForm(body.data);
                var formTitle = document.getElementById("customer-form-title");
                var saveBtn = document.getElementById("customer-save-btn");
                if (formTitle) formTitle.textContent = "Edit Customer";
                if (saveBtn) saveBtn.textContent = "Update Customer";
                InventoryPagePanel.showPanel(LIST_PANEL, FORM_PANEL);
            })
            .catch(function () {
                InventoryToast.error("Network error while loading customer.");
            })
            .finally(function () {
                InventoryLoader.hide();
            });
    }

    function saveCustomer() {
        var payload = collectPayload();
        if (!payload) return;

        var btn = document.getElementById("customer-save-btn");
        InventoryLoader.button(btn, true, editingId ? "Updating..." : "Saving...");

        request(editingId ? "/" + editingId + "/" : "", {
            method: editingId ? "PATCH" : "POST",
            body: payload
        })
            .then(function (body) {
                if (body && body.isSuccess) {
                    InventoryToast.success(editingId ? "Customer updated." : "Customer added.");
                    if (isModalMode()) {
                        InventoryModal.close("customer-modal");
                        resetForm();
                        if (body.data) {
                            window.dispatchEvent(new CustomEvent("inventory:customer-created", {
                                detail: { customer: body.data }
                            }));
                        }
                    } else {
                        InventoryPagePanel.showList(LIST_PANEL);
                        loadCustomers(editingId ? currentPage : 1);
                    }
                } else {
                    var err = body.message || "Unable to save customer.";
                    if (body.errors && body.errors.length) err = body.errors.join(" • ");
                    InventoryToast.error(err);
                }
            })
            .catch(function () {
                InventoryToast.error("Network error. Please try again.");
            })
            .finally(function () {
                InventoryLoader.button(btn, false);
            });
    }

    function deleteCustomer(id, btn) {
        InventoryConfirm.delete({
            title: "Delete customer?",
            message: "This customer will be removed from your list."
        }).then(function (confirmed) {
            if (!confirmed) return;
            InventoryLoader.button(btn, true, "");
            request("/" + id + "/", { method: "DELETE" })
                .then(function (body) {
                    if (body && body.isSuccess) {
                        InventoryToast.success("Customer deleted.");
                        loadCustomers(currentPage);
                    } else {
                        InventoryToast.error(body && body.message ? body.message : "Unable to delete customer.");
                    }
                })
                .catch(function () {
                    InventoryToast.error("Network error. Please try again.");
                })
                .finally(function () {
                    InventoryLoader.button(btn, false);
                });
        });
    }

    function init() {
        if (init._wired) return;
        init._wired = true;

        if (isModalMode()) {
            InventoryModal.wire("customer-modal");
        }

        if (window.InventoryPagePanel && isListPage()) {
            InventoryPagePanel.init();
        }

        if (window.InventoryAuth && typeof InventoryAuth.wireMobileInput === "function") {
            InventoryAuth.wireMobileInput(document.getElementById("customer-mobile"));
        }

        var pinCodeEl = document.getElementById("customer-pin-code");
        if (pinCodeEl) {
            pinCodeEl.addEventListener("input", function () {
                this.value = this.value.replace(/\D/g, "").slice(0, 6);
            });
        }

        var addBusinessCheckbox = document.getElementById("customer-add-business");
        if (addBusinessCheckbox) {
            addBusinessCheckbox.addEventListener("change", function () {
                setBusinessFieldsVisible(addBusinessCheckbox.checked);
                if (addBusinessCheckbox.checked) {
                    document.getElementById("customer-company-name").focus();
                }
            });
        }

        var openBtn = document.getElementById("customer-open-form-btn");
        var saveBtn = document.getElementById("customer-save-btn");
        var searchEl = document.getElementById("customers-search");
        var tbody = document.getElementById("customers-table-body");

        if (isListPage()) {
            getColumnCtrl();
            function boot() {
                if (!InventoryBusiness.getActiveId()) return;
                loadCustomers(1);
            }

            InventoryBusiness.whenReady(function () {
                boot();
                if (window.InventorySidebar && InventorySidebar.consumeAddAction()) {
                    openFormPanel();
                }
            });
            window.addEventListener("inventory:business-changed", function () {
                currentPage = 1;
                boot();
            });
        }

        if (openBtn) openBtn.addEventListener("click", openFormPanel);
        if (saveBtn) saveBtn.addEventListener("click", saveCustomer);

        if (searchEl) {
            searchEl.addEventListener("input", function () {
                window.clearTimeout(searchTimer);
                searchTimer = window.setTimeout(function () {
                    currentSearch = searchEl.value.trim();
                    loadCustomers(1);
                }, 300);
            });
        }

        if (tbody) {
            tbody.addEventListener("click", function (e) {
                var viewBtn = e.target.closest(".customer-view");
                if (viewBtn) {
                    openViewPanel(viewBtn.getAttribute("data-id"));
                    return;
                }
                var editBtn = e.target.closest(".customer-edit");
                if (editBtn) {
                    openEditPanel(editBtn.getAttribute("data-id"));
                    return;
                }
                var deleteBtn = e.target.closest(".customer-delete");
                if (deleteBtn) {
                    deleteCustomer(deleteBtn.getAttribute("data-id"), deleteBtn);
                }
            });
        }
    }

    return { init: init, loadCustomers: loadCustomers, openAddModal: openAddModal };
})();
