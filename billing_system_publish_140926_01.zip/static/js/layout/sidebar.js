/**
 * Sidebar expandable nav groups, quick-add (+) actions, and hamburger flyout.
 */
var InventorySidebar = (function () {
    "use strict";

    var HOVER_OPEN_DELAY_MS = 180;
    var HOVER_CLOSE_DELAY_MS = 400;

    function clearGroupTimers(group) {
        clearTimeout(group._openTimer);
        clearTimeout(group._closeTimer);
        group._openTimer = null;
        group._closeTimer = null;
    }

    function shouldKeepGroupOpen(group) {
        if (isCollapsedRail()) return false;
        if (group.classList.contains("inv-nav-group--has-active-child")) return true;
        return group.dataset.clickOpen === "1";
    }

    function scheduleCloseGroup(group) {
        clearTimeout(group._closeTimer);
        group._closeTimer = setTimeout(function () {
            group._closeTimer = null;
            if (shouldKeepGroupOpen(group)) return;
            setGroupOpen(group, false);
        }, HOVER_CLOSE_DELAY_MS);
    }
    function isCollapsedRail() {
        var body = document.body;
        return body.classList.contains("inv-sidebar-collapsed") &&
            !body.classList.contains("inv-sidebar-pinned") &&
            !body.classList.contains("inv-sidebar-open");
    }

    function syncGroupsForSidebarMode() {
        document.querySelectorAll(".inv-nav-group").forEach(function (group) {
            var toggle = group.querySelector(".inv-nav-group-toggle");
            if (isCollapsedRail()) {
                group.dataset.clickOpen = "0";
                setGroupOpen(group, false);
                return;
            }
            if (group.classList.contains("inv-nav-group--has-active-child")) {
                setGroupOpen(group, true);
                group.dataset.clickOpen = "1";
                if (toggle) toggle.setAttribute("aria-expanded", "true");
            }
        });
    }

    function resetFlyoutPosition(group) {
        var sub = group && group.querySelector(".inv-nav-sub");
        if (sub) sub.style.top = "";
    }

    function ensureGroupFullyVisible(group) {
        var nav = document.querySelector(".inv-sidebar-nav");
        if (!nav || !group) return;

        var sub = group.querySelector(".inv-nav-sub");
        if (!sub) return;

        function applyScroll() {
            if (isCollapsedRail()) {
                resetFlyoutPosition(group);
                var padding = 12;
                var subRect = sub.getBoundingClientRect();
                var maxBottom = window.innerHeight - padding;

                if (subRect.bottom > maxBottom) {
                    sub.style.top = (maxBottom - subRect.bottom) + "px";
                }

                var navRect = nav.getBoundingClientRect();
                var groupRect = group.getBoundingClientRect();
                if (groupRect.top < navRect.top + padding) {
                    nav.scrollTop -= navRect.top + padding - groupRect.top;
                } else if (groupRect.bottom > navRect.bottom - padding) {
                    nav.scrollTop += groupRect.bottom - navRect.bottom + padding;
                }
                return;
            }

            var navRect = nav.getBoundingClientRect();
            var padding = 8;
            var lastItem = sub.lastElementChild || sub;
            var bottomRect = lastItem.getBoundingClientRect();
            var topRect = group.getBoundingClientRect();

            if (bottomRect.bottom > navRect.bottom - padding) {
                nav.scrollTop += bottomRect.bottom - navRect.bottom + padding;
            } else if (topRect.top < navRect.top + padding) {
                nav.scrollTop -= navRect.top + padding - topRect.top;
            }
        }

        requestAnimationFrame(function () {
            requestAnimationFrame(applyScroll);
        });
        setTimeout(applyScroll, 480);
    }

    function setGroupOpen(group, open) {
        var toggle = group.querySelector(".inv-nav-group-toggle");
        group.classList.toggle("inv-nav-group--open", open);
        if (toggle) toggle.setAttribute("aria-expanded", open ? "true" : "false");
        if (open) {
            ensureGroupFullyVisible(group);
        } else {
            resetFlyoutPosition(group);
        }
    }

    function closeOtherGroups(except) {
        document.querySelectorAll(".inv-nav-group").forEach(function (group) {
            if (group === except) return;
            if (!isCollapsedRail() && group.classList.contains("inv-nav-group--has-active-child")) return;
            if (!isCollapsedRail() && group.dataset.clickOpen === "1") return;
            clearGroupTimers(group);
            scheduleCloseGroup(group);
        });
    }

    function initGroups() {
        document.querySelectorAll(".inv-nav-group").forEach(function (group) {
            var toggle = group.querySelector(".inv-nav-group-toggle");
            if (!toggle || toggle.dataset.sidebarWired === "1") return;
            toggle.dataset.sidebarWired = "1";

            if (group.classList.contains("inv-nav-group--open")) {
                group.dataset.clickOpen = isCollapsedRail() ? "0" : "1";
            }

            group.addEventListener("mouseenter", function () {
                if (!group.querySelector(".inv-nav-sub")) return;
                clearGroupTimers(group);
                ensureGroupFullyVisible(group);
                group._openTimer = setTimeout(function () {
                    group._openTimer = null;
                    closeOtherGroups(group);
                    setGroupOpen(group, true);
                }, HOVER_OPEN_DELAY_MS);
            });

            group.addEventListener("mouseleave", function () {
                clearGroupTimers(group);
                resetFlyoutPosition(group);
                scheduleCloseGroup(group);
            });

            toggle.addEventListener("click", function () {
                clearGroupTimers(group);
                var isOpen = !group.classList.contains("inv-nav-group--open");
                setGroupOpen(group, isOpen);
                group.dataset.clickOpen = isOpen ? "1" : "0";
                if (isOpen) closeOtherGroups(group);
            });
        });
    }

    function wireAddButtons() {
        document.querySelectorAll(".inv-nav-add-btn").forEach(function (btn) {
            if (btn.dataset.sidebarAddWired === "1") return;
            btn.dataset.sidebarAddWired = "1";

            btn.addEventListener("click", function (e) {
                e.preventDefault();
                e.stopPropagation();

                if (btn.getAttribute("data-add-action") === "business") {
                    var businessAddBtn = document.getElementById("inv-business-add-btn");
                    if (businessAddBtn) businessAddBtn.click();
                    return;
                }

                var href = btn.getAttribute("href");
                if (href) window.location.href = href;
            });
        });
    }

    function initSidebarToggle() {
        var toggle = document.getElementById("inv-sidebar-toggle");
        var sidebar = document.querySelector(".inv-sidebar");
        var body = document.body;

        if (!toggle || !sidebar || !body.classList.contains("inv-dashboard-body")) return;
        if (toggle.dataset.sidebarToggleWired === "1") return;
        toggle.dataset.sidebarToggleWired = "1";

        var hoverTimer = null;
        var hoverOpen = false;

        function syncOpenState() {
            var pinned = body.classList.contains("inv-sidebar-pinned");
            body.classList.toggle("inv-sidebar-open", hoverOpen || pinned);
            toggle.setAttribute("aria-expanded", pinned || hoverOpen ? "true" : "false");
            syncGroupsForSidebarMode();
        }

        function openSidebar() {
            clearTimeout(hoverTimer);
            hoverOpen = true;
            syncOpenState();
        }

        function scheduleCloseSidebar() {
            clearTimeout(hoverTimer);
            hoverTimer = setTimeout(function () {
                hoverOpen = false;
                syncOpenState();
            }, 200);
        }

        toggle.addEventListener("mouseenter", openSidebar);
        toggle.addEventListener("mouseleave", scheduleCloseSidebar);
        sidebar.addEventListener("mouseenter", openSidebar);
        sidebar.addEventListener("mouseleave", scheduleCloseSidebar);

        toggle.addEventListener("click", function () {
            body.classList.toggle("inv-sidebar-pinned");
            syncOpenState();
            syncGroupsForSidebarMode();
        });

        syncGroupsForSidebarMode();
    }

    function consumeAddAction() {
        var params = new URLSearchParams(window.location.search);
        if (params.get("action") !== "add") return false;

        params.delete("action");
        var query = params.toString();
        var nextUrl = window.location.pathname + (query ? "?" + query : "") + window.location.hash;
        window.history.replaceState({}, "", nextUrl);
        return true;
    }

    function init() {
        initGroups();
        wireAddButtons();
        initSidebarToggle();
        syncGroupsForSidebarMode();
    }

    return {
        init: init,
        consumeAddAction: consumeAddAction
    };
})();

document.addEventListener("DOMContentLoaded", function () {
    InventorySidebar.init();
});
