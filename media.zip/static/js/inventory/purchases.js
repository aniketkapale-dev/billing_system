var InventoryPurchases = (function () {
    "use strict";

    var API = "/api/purchases";
    var saleDueDefaultDays = 7;
    var PRODUCTS_API = "/api/products";
    var CATALOG_API = "/api/catalog";
    var CUSTOMERS_API = "/api/customers";
    var TAXES_API = "/api/settings/taxes";
    var INVOICE_SETTINGS_API = "/api/settings/invoice-settings";
    var PAGE_SIZE = (window.InventoryConstants && InventoryConstants.PAGE_SIZE) || 10;
    var currentPage = 1;
    var currentOrdering = "-created_at";
    var searchTimer = null;
    var products = [];
    var services = [];
    var taxes = [];
    var paymentTypes = [];
    var customers = [];
    var invoiceSettings = [];
    var editingPurchaseId = null;
    var saleFormKind = "service";
    var serviceAddTargetSelect = null;
    var editingPurchaseIsDraft = false;
    var viewingPurchaseId = null;
    var viewingPurchase = null;
    var addPaymentPurchaseId = null;
    var addPaymentSaleType = "product";
    var addPaymentPendingAmount = 0;
    var addPaymentMinDate = "";
    var editingSaleStockByProduct = {};
    var PURCHASES_LIST_PANEL = "purchases-list-panel";
    var PURCHASES_FORM_PANEL = "purchases-form-panel";
    var PURCHASES_VIEW_PANEL = "purchases-view-panel";
    var cachedItems = [];
    var bulkSelect = null;
    var SALE_PRINT_META_KEY = "billingSalePrintMeta";

    function readSalePrintMetaStore() {
        try {
            return JSON.parse(localStorage.getItem(SALE_PRINT_META_KEY) || "{}") || {};
        } catch (e) {
            return {};
        }
    }

    function writeSalePrintMetaStore(store) {
        localStorage.setItem(SALE_PRINT_META_KEY, JSON.stringify(store || {}));
    }

    function getSalePrintMetaFromForm() {
        var transportEl = document.getElementById("purchase-invoice-transport");
        var cartonsEl = document.getElementById("purchase-invoice-cartons");
        var ewayEl = document.getElementById("purchase-invoice-eway-bill");
        var dueDateEl = document.getElementById("purchase-invoice-due-date");
        var termsEl = document.getElementById("purchase-invoice-terms");
        return {
            transport: transportEl ? transportEl.value.trim() : "",
            cartons: cartonsEl ? cartonsEl.value.trim() : "",
            eway_bill_no: ewayEl ? ewayEl.value.trim() : "",
            due_date: dueDateEl ? InventoryApi.getDateInputValue(dueDateEl) : "",
            terms: termsEl ? termsEl.value.trim() : "",
            is_paid: isFullPaymentReceived()
        };
    }

    function setSalePrintMetaForm(meta, purchase) {
        meta = meta || {};
        if (purchase && purchase.due_date && !meta.due_date) {
            meta.due_date = purchase.due_date;
        }
        var transportEl = document.getElementById("purchase-invoice-transport");
        var cartonsEl = document.getElementById("purchase-invoice-cartons");
        var ewayEl = document.getElementById("purchase-invoice-eway-bill");
        var dueDateEl = document.getElementById("purchase-invoice-due-date");
        var termsEl = document.getElementById("purchase-invoice-terms");
        if (transportEl) transportEl.value = meta.transport || "";
        if (cartonsEl) cartonsEl.value = meta.cartons || "";
        if (ewayEl) ewayEl.value = meta.eway_bill_no || "";
        if (dueDateEl) InventoryApi.setDateInputValue(dueDateEl, meta.due_date || "");
        if (termsEl) termsEl.value = meta.terms || "";
    }

    function saveSalePrintMeta(saleId, meta) {
        if (!saleId) return;
        var store = readSalePrintMetaStore();
        store[String(saleId)] = meta || getSalePrintMetaFromForm();
        writeSalePrintMetaStore(store);
    }

    function loadSalePrintMeta(saleId) {
        if (!saleId) return null;
        var store = readSalePrintMetaStore();
        return store[String(saleId)] || null;
    }

    function getSalePrintTermsOverrides(sale) {
        var meta = loadSalePrintMeta(sale.id) || {};
        var defaultBody = sale.invoice_terms_conditions || "";
        return {
            terms_conditions: Object.prototype.hasOwnProperty.call(meta, "terms_conditions")
                ? meta.terms_conditions
                : defaultBody
        };
    }

    function saveSalePrintTermsOverrides(saleId, overrides) {
        if (!saleId) return;
        var store = readSalePrintMetaStore();
        var key = String(saleId);
        store[key] = Object.assign({}, store[key] || {}, {
            terms_conditions: overrides.terms_conditions || ""
        });
        writeSalePrintMetaStore(store);
    }

    function mergeSalePrintMeta(sale) {
        if (!sale || !sale.id) return sale;
        var meta = loadSalePrintMeta(sale.id);
        if (!meta) return sale;
        var merged = Object.assign({}, sale, {
            invoice_transport: meta.transport || "",
            invoice_cartons: meta.cartons || "",
            invoice_eway_bill_no: meta.eway_bill_no || "",
            due_date: sale.due_date || meta.due_date || "",
            is_paid: meta.is_paid === true || sale.is_paid === true,
            invoice_print_terms: meta.terms || ""
        });
        if (Object.prototype.hasOwnProperty.call(meta, "terms_conditions")) {
            merged.invoice_terms_conditions = meta.terms_conditions;
        }
        return merged;
    }

    function clearSalePrintMetaForm() {
        setSalePrintMetaForm({});
    }
    var columnCtrl = null;

    function getColumnCtrl() {
        if (!window.InventoryColumnCustomize) {
            throw new Error("InventoryColumnCustomize is not loaded.");
        }
        if (!columnCtrl) {
            columnCtrl = InventoryColumnCustomize.create({
                tableKey: "purchases",
                theadSelector: ".inv-mgmt-table--purchases thead tr",
                toolbarSelector: "#purchases-list-panel .inv-mgmt-toolbar",
                includeBulkCheck: false,
                bulkHeaderHtml: '<th class="inv-col-check d-none"><input type="checkbox" class="inv-bulk-select-all" aria-label="Select all"/></th>',
                sortDefault: "-created_at",
                onSortChange: function (ordering) {
                    currentOrdering = ordering;
                    loadPurchases(1);
                },
                columns: [
                    { id: "date", label: "Date", locked: true, sortKey: "purchase_date", cell: function (p) { return "<td>" + InventoryApi.escapeHtml(InventoryApi.formatDisplayDate(p.purchase_date, "—")) + "</td>"; } },
                    { id: "invoice_no", label: "Invoice No.", sortKey: "reference_no", cell: function (p) { return "<td>" + formatInvoiceNoCell(p) + "</td>"; } },
                    { id: "customer", label: "Customer", locked: true, sortKey: "customer_name", cell: function (p) { return "<td>" + formatCustomerDisplay(p) + "</td>"; } },
                    { id: "products", label: "Items Sold", cell: function (p) { return '<td class="inv-col-name">' + formatProductsSoldCell(p.items || [], p.id, p.sale_type) + "</td>"; } },
                    { id: "sale_amount", label: "Bill Amount", sortKey: "total_amount", headerClass: "inv-mgmt-cell--num", cell: function (p) { return '<td class="inv-mgmt-cell--num">' + InventoryApi.formatMoney(p.total_amount) + "</td>"; } },
                    { id: "total_paid", label: "Total Paid", headerClass: "inv-mgmt-cell--num", cell: function (p) { return '<td class="inv-mgmt-cell--num">' + InventoryApi.formatMoney(p.total_paid) + "</td>"; } },
                    { id: "pending_bill", label: "Pending Bill", headerClass: "inv-mgmt-cell--num", cell: function (p) { return formatPendingBillCell(p); } }
                ],
                onApply: function () {
                    renderPurchaseRows(cachedItems);
                }
            });
            columnCtrl.mount();
            columnCtrl.renderHeader();
        }
        return columnCtrl;
    }

    function getBulkSelect() {
        if (!bulkSelect) {
            bulkSelect = InventoryBulkSelect.create({
                tbodyId: "purchases-table-body",
                tableSelector: ".inv-mgmt-table--purchases",
                entitySingular: "Sale",
                entityPlural: "Sales",
                enableDelete: false,
                onPdf: exportSalesPdf,
                onPrint: exportSalesPrint
            });
        }
        return bulkSelect;
    }

    function getSelectedItems(ids) {
        return cachedItems.filter(function (item) {
            return ids.indexOf(String(item.id)) !== -1;
        });
    }

    function isServiceSaleType(saleType) {
        return saleType === "service";
    }

    function resolveSaleType(saleType, id) {
        if (saleType === "service" || saleType === "product") return saleType;
        var cached = findCachedPurchase(id);
        if (cached && cached.sale_type === "service") return "service";
        if (viewingPurchase && String(viewingPurchase.id) === String(id) && viewingPurchase.sale_type === "service") {
            return "service";
        }
        return "product";
    }

    function saleDetailPath(id, saleType) {
        return isServiceSaleType(saleType) ? "/service-sales/" + id + "/" : "/" + id + "/";
    }

    function saleActionPath(id, saleType, action) {
        var base = isServiceSaleType(saleType) ? "/service-sales/" + id : "/" + id;
        return base + "/" + action + "/";
    }

    function fetchSale(id, saleType) {
        return request(saleDetailPath(id, saleType)).then(function (body) {
            if (body && body.isSuccess && body.data) {
                return mergeSalePrintMeta(body.data);
            }
            InventoryToast.error(body.message || "Failed to load sale details.");
            return null;
        });
    }

    function fetchSalesDetails(entries) {
        return Promise.all((entries || []).map(function (entry) {
            var id = entry && typeof entry === "object" ? entry.id : entry;
            var saleType = entry && typeof entry === "object"
                ? resolveSaleType(entry.sale_type, id)
                : resolveSaleType(null, id);
            return fetchSale(id, saleType);
        })).then(function (results) {
            return results.filter(Boolean).map(mergeSalePrintMeta);
        });
    }

    function exportSalesPdf(ids) {
        fetchSalesDetails(ids)
            .then(function (sales) {
                if (!sales.length) {
                    InventoryToast.error("Unable to load selected sales.");
                    return;
                }
                InventoryDocumentExport.downloadSalesPdf(sales, "sales.pdf");
            });
    }

    function sendSaleInvoicePdf(id, saleType) {
        saleType = resolveSaleType(saleType, id);
        InventoryLoader.show();
        Promise.all([fetchSale(id, saleType), loadTaxes()])
            .then(function (results) {
                var sale = results[0];
                var taxList = taxes || [];
                if (!sale) throw new Error("Unable to load this sale.");
                sale = mergeSalePrintMeta(sale);
                return InventoryDocumentExport.generateSaleInvoicePdfBlob(sale, taxList).then(function (blob) {
                    var form = new FormData();
                    var name = (sale.reference_no || ("sale-" + sale.id)).replace(/[^\w.-]+/g, "_") + ".pdf";
                    form.append("file", blob, name);
                    return request(saleActionPath(sale.id, saleType, "invoice-pdf"), {
                        method: "POST",
                        body: form
                    });
                });
            })
            .then(function (body) {
                if (!(body && body.isSuccess && body.data && body.data.url)) {
                    throw new Error(body && body.message ? body.message : "Unable to save the invoice PDF.");
                }
                console.log("Sale invoice PDF:", body.data.url);
                InventoryToast.success("Invoice PDF saved. Link printed in the browser console.");
            })
            .catch(function (err) {
                InventoryToast.error(err && err.message ? err.message : "Unable to create the invoice PDF.");
            })
            .finally(function () {
                InventoryLoader.hide();
            });
    }

    function exportSalesPrint(entries) {
        InventoryLoader.show();
        Promise.all([fetchSalesDetails(entries), loadTaxes()])
            .then(function (results) {
                var sales = results[0];
                InventoryLoader.hide();
                if (!sales.length) {
                    InventoryToast.error("Unable to load selected sales.");
                    return;
                }
                if (window.InventorySalePrintPreview) {
                    InventorySalePrintPreview.open(sales, taxes, {
                        getInitialOverrides: getSalePrintTermsOverrides
                    });
                    return;
                }
                var html = InventoryDocumentExport.buildSalesDocumentHtml(sales, { taxes: taxes });
                var printTitle = sales.length === 1
                    ? "Sale Invoice" + (sales[0].reference_no ? " - " + sales[0].reference_no : "")
                    : "Sales Invoices";
                InventoryDocumentExport.printHtml(printTitle, html);
            })
            .catch(function () {
                InventoryLoader.hide();
                InventoryToast.error("Unable to load selected sales.");
            });
    }

    function request(path, opts) {
        return InventoryApi.request(API, path, opts);
    }

    function catalogRequest(resource, path, opts) {
        path = path == null ? "" : String(path);
        var segment = String(resource).replace(/^\/+|\/+$/g, "");
        var urlPath;
        if (path.charAt(0) === "?") {
            urlPath = "/" + segment + "/" + path;
        } else if (!path) {
            urlPath = "/" + segment + "/";
        } else {
            urlPath = "/" + segment + "/" + path.replace(/^\//, "");
        }
        return InventoryApi.request(CATALOG_API, urlPath, opts);
    }

    function customerDisplayLabel(name, companyName, mobile) {
        name = name ? String(name).trim() : "—";
        companyName = companyName ? String(companyName).trim() : "";
        mobile = mobile ? String(mobile).trim() : "";
        if (companyName) {
            return InventoryApi.escapeHtml(companyName) + " (" + InventoryApi.escapeHtml(name) + ")";
        }
        if (mobile) {
            return InventoryApi.escapeHtml(name) + " (" + InventoryApi.escapeHtml(mobile) + ")";
        }
        return InventoryApi.escapeHtml(name);
    }

    function customerHasCompany(customer) {
        return !!(customer && customer.company_name && String(customer.company_name).trim());
    }

    function findCustomerById(id) {
        if (!id) return null;
        for (var i = 0; i < customers.length; i++) {
            if (String(customers[i].id) === String(id)) return customers[i];
        }
        return null;
    }

    function setAddressFieldLabels(isCompany) {
        var billingLabel = document.querySelector('label[for="purchase-billing-address"]');
        var shippingLabel = document.querySelector('label[for="purchase-shipping-address"]');
        if (billingLabel) {
            billingLabel.innerHTML = isCompany
                ? 'Company Address <span class="inv-field-optional">(optional)</span>'
                : 'Billing Address <span class="inv-field-optional">(optional)</span>';
        }
        if (shippingLabel) {
            shippingLabel.innerHTML = 'Shipping Address <span class="inv-field-optional">(optional)</span>';
        }
    }

    function setAddressPlaceholders(isCompany) {
        var billingEl = document.getElementById("purchase-billing-address");
        var shippingEl = document.getElementById("purchase-shipping-address");
        if (billingEl) {
            billingEl.placeholder = isCompany ? "Company address" : "Billing address";
        }
        if (shippingEl) {
            shippingEl.placeholder = "Shipping address";
        }
    }

    function applyCustomerAddressesFromSelection(customerId, preserveExisting) {
        var billingEl = document.getElementById("purchase-billing-address");
        var shippingEl = document.getElementById("purchase-shipping-address");
        if (!billingEl || !shippingEl) return;

        if (!customerId) {
            setAddressFieldLabels(false);
            setAddressPlaceholders(false);
            if (!preserveExisting) {
                billingEl.value = "";
                shippingEl.value = "";
            }
            return;
        }

        var customer = findCustomerById(customerId);
        if (!customer) return;

        var isCompany = customerHasCompany(customer);
        setAddressFieldLabels(isCompany);
        setAddressPlaceholders(isCompany);

        if (preserveExisting) return;

        if (isCompany) {
            billingEl.value = (customer.business_address || "").trim();
            shippingEl.value = (customer.shipping_address || "").trim();
        } else {
            var address = (customer.address || "").trim();
            billingEl.value = address;
            shippingEl.value = address;
        }
    }

    function onCustomerSelectionChange() {
        var customerSelect = document.getElementById("purchase-customer");
        if (!customerSelect) return;
        applyCustomerAddressesFromSelection(customerSelect.value, false);
    }

    function customerLabel(customer) {
        return customerDisplayLabel(customer.name, customer.company_name, customer.mobile);
    }

    function formatInvoiceNumber(prefix, counter, suffix) {
        var parts = [];
        var prefixText = String(prefix || "").trim();
        var suffixText = String(suffix || "").trim();
        if (prefixText) parts.push(prefixText);
        parts.push(String(counter != null ? counter : 0));
        if (suffixText) parts.push(suffixText);
        return parts.join("/");
    }

    function invoiceSettingLabel(item) {
        var number = formatInvoiceNumber(item.prefix, item.current_counter, item.suffix);
        return number || "—";
    }

    function renderInvoiceSettingSelect(selectedId) {
        var select = document.getElementById("purchase-invoice-setting");
        if (!select) return;
        if (selectedId === undefined || selectedId === null) selectedId = select.value;

        var html;
        if (!invoiceSettings.length) {
            html = '<option value="">No invoice settings — add one in Settings first</option>';
        } else {
            html = '<option value="">Select invoice</option>';
            invoiceSettings.forEach(function (item) {
                var selected = String(item.id) === String(selectedId) ? " selected" : "";
                html += '<option value="' + item.id + '"' + selected + ">" +
                    InventoryApi.escapeHtml(invoiceSettingLabel(item)) + "</option>";
            });
        }
        select.innerHTML = html;
        if (selectedId) {
            select.value = String(selectedId);
        }
        if (window.InventorySearchableSelect) {
            InventorySearchableSelect.refresh(select);
        }
    }

    function isInvoiceSettingSelectable(item) {
        if (!item.end_counter) return true;
        var today = new Date().toISOString().slice(0, 10);
        return item.end_counter >= today;
    }

    function loadInvoiceSettings(selectedId) {
        return InventoryApi.request(INVOICE_SETTINGS_API, "?page_size=100&ordering=-year").then(function (body) {
            var items = body && body.isSuccess ? (body.data.items || []) : [];
            var activeItems = items.filter(isInvoiceSettingSelectable);
            invoiceSettings = activeItems.length ? activeItems : items;
            renderInvoiceSettingSelect(selectedId);
            return invoiceSettings;
        });
    }

    function toggleInvoiceSettingField(show) {
        var field = document.getElementById("purchase-invoice-setting-field");
        if (field) {
            field.classList.toggle("inv-hidden", !show);
        }
    }

    function renderCustomerSelect(selectedId) {
        var select = document.getElementById("purchase-customer");
        if (!select) return;
        if (selectedId === undefined || selectedId === null) selectedId = select.value;

        var applyOptions = function (el) {
            var html;
            if (!customers.length) {
                html = '<option value="">No customers — add a customer first</option>';
            } else {
                html = '<option value="">Select customer or company</option>';
                customers.forEach(function (item) {
                    var selected = String(item.id) === String(selectedId) ? " selected" : "";
                    html += '<option value="' + item.id + '"' + selected + ">" +
                        customerLabel(item) + "</option>";
                });
            }
            el.innerHTML = html;
            if (selectedId) {
                el.value = String(selectedId);
            }
        };

        if (window.InventorySearchableSelect) {
            InventorySearchableSelect.rebuild(select, applyOptions);
            return;
        }

        applyOptions(select);
    }

    function loadCustomers(selectedId) {
        return InventoryApi.request(CUSTOMERS_API, "?page_size=100").then(function (body) {
            customers = body && body.isSuccess ? (body.data.items || []) : [];
            renderCustomerSelect(selectedId);
            return customers;
        });
    }

    function openAddCustomerModal() {
        if (window.InventoryCustomers && typeof InventoryCustomers.openAddModal === "function") {
            InventoryCustomers.openAddModal();
            return;
        }
        InventoryToast.error("Customer form is not available.");
    }

    function openAddInvoiceModal() {
        if (window.InventorySettingsInvoice && typeof InventorySettingsInvoice.openAddModal === "function") {
            InventorySettingsInvoice.openAddModal();
            return;
        }
        InventoryToast.error("Invoice form is not available.");
    }

    function openAddTaxModal() {
        if (window.InventorySettingsTax && typeof InventorySettingsTax.openAddModal === "function") {
            InventorySettingsTax.openAddModal();
            return;
        }
        InventoryToast.error("Tax form is not available.");
    }

    function formatCustomerDisplay(purchase) {
        return customerDisplayLabel(
            purchase.customer_name,
            purchase.company_name,
            purchase.customer_mobile
        );
    }

    function fillPaymentTypeSelect(select, selectedId) {
        if (!select) return;
        if (selectedId === undefined || selectedId === null) selectedId = select.value;
        var html = '<option value="">Select payment type (optional)</option>';
        paymentTypes.forEach(function (item) {
            var selected = String(item.id) === String(selectedId) ? " selected" : "";
            html += '<option value="' + item.id + '"' + selected + ">" +
                InventoryApi.escapeHtml(item.name) + "</option>";
        });
        select.innerHTML = html;
        if (selectedId) {
            select.value = String(selectedId);
        }
        if (window.InventorySearchableSelect) {
            InventorySearchableSelect.rebuild(select);
        }
    }

    function renderPaymentTypeSelect(selectedId) {
        fillPaymentTypeSelect(document.getElementById("purchase-payment-type"), selectedId);
    }

    function togglePaymentTypePanel(show) {
        var panel = document.getElementById("purchase-payment-type-new-panel");
        if (!panel) return;
        panel.classList.toggle("inv-hidden", !show);
        if (show) {
            document.getElementById("purchase-payment-type-new-name").focus();
        } else {
            document.getElementById("purchase-payment-type-new-name").value = "";
        }
    }

    function loadPaymentTypes(selectedId) {
        return catalogRequest("payment-types", "?page_size=100").then(function (body) {
            paymentTypes = body && body.isSuccess ? (body.data.items || []) : [];
            renderPaymentTypeSelect(selectedId);
            return paymentTypes;
        });
    }

    function saveNewPaymentType() {
        var name = document.getElementById("purchase-payment-type-new-name").value.trim();
        if (!name) {
            InventoryToast.error("Payment type name is required.");
            return;
        }

        var btn = document.getElementById("purchase-payment-type-save-btn");
        InventoryLoader.button(btn, true, "Saving...");

        catalogRequest("payment-types", "", {
            method: "POST",
            body: { name: name }
        })
            .then(function (body) {
                if (body && body.isSuccess && body.data) {
                    InventoryToast.success(body.message || "Payment type added.");
                    togglePaymentTypePanel(false);
                    return loadPaymentTypes(body.data.id);
                }
                var err = body.message || "Unable to add payment type.";
                if (body.errors && body.errors.length) err = body.errors.join(" • ");
                InventoryToast.error(err);
            })
            .catch(function () {
                InventoryToast.error("Network error while saving payment type.");
            })
            .finally(function () {
                InventoryLoader.button(btn, false);
            });
    }

    function loadProducts(opts) {
        opts = opts || {};
        var includeProductIds = (opts.includeProductIds || []).map(String);
        var includeAll = !!opts.includeAll || isDraftFlow();
        return InventoryApi.request(PRODUCTS_API, "?page_size=100")
            .then(function (body) {
                if (body && body.isSuccess && body.data) {
                    products = (body.data.items || []).filter(function (product) {
                        if (includeAll) return true;
                        if (includeProductIds.indexOf(String(product.id)) !== -1) return true;
                        return Number(product.quantity || 0) > 0;
                    });
                } else {
                    products = [];
                }
                syncRowTaxesFromProducts();
            });
    }

    function setEditingSaleStockFromPurchase(purchase) {
        editingSaleStockByProduct = {};
        (purchase.items || []).forEach(function (line) {
            var productId = String(getLineProductId(line));
            if (!productId || productId === "undefined" || productId === "null") return;
            editingSaleStockByProduct[productId] =
                (editingSaleStockByProduct[productId] || 0) + Number(line.quantity || 0);
        });
    }

    function getEditingStockBonus(productId) {
        if (!editingPurchaseId) return 0;
        return Number(editingSaleStockByProduct[String(productId)] || 0);
    }

    function getIncludedEditProductIds() {
        return Object.keys(editingSaleStockByProduct || {});
    }

    function taxLabel(item) {
        return item.key + " (" + item.value + "%)";
    }

    function getTax(taxId) {
        return taxes.find(function (tax) {
            return String(tax.id) === String(taxId);
        });
    }

    function getTaxRate(taxId) {
        var tax = getTax(taxId);
        return tax ? Number(tax.value || 0) : 0;
    }

    function roundMoney(value) {
        return Math.round(Number(value || 0) * 100) / 100;
    }

    function computeWithGst(actualPrice, taxRate) {
        var actual = Number(actualPrice || 0);
        var rate = Number(taxRate || 0);
        if (isNaN(actual)) actual = 0;
        if (isNaN(rate)) rate = 0;
        return roundMoney(actual * (1 + rate / 100));
    }

    function computeGstAmount(actualPrice, taxRate) {
        var actual = Number(actualPrice || 0);
        var rate = Number(taxRate || 0);
        if (isNaN(actual)) actual = 0;
        if (isNaN(rate)) rate = 0;
        return roundMoney(actual * rate / 100);
    }

    /** GST-inclusive price → taxable value (e.g. ₹100 @ 5% → ₹95.24). */
    function extractTaxableFromInclusive(inclusivePrice, taxRate) {
        var inclusive = Number(inclusivePrice || 0);
        var rate = Number(taxRate || 0);
        if (isNaN(inclusive) || inclusive <= 0) return 0;
        if (rate <= 0) return roundMoney(inclusive);
        return roundMoney(inclusive / (1 + rate / 100));
    }

    /** GST-inclusive price → GST portion (e.g. ₹45 @ 5% → ₹2.14). */
    function extractGstFromInclusive(inclusivePrice, taxRate) {
        var inclusive = Number(inclusivePrice || 0);
        var rate = Number(taxRate || 0);
        if (isNaN(inclusive) || inclusive <= 0 || rate <= 0) return 0;
        return roundMoney(inclusive - extractTaxableFromInclusive(inclusive, rate));
    }

    function getCombinedTaxRate(taxIds) {
        return InventoryTaxSelect.getCombinedRate(taxes, taxIds);
    }

    function getProductDefaultSaleTaxIds(product) {
        if (!product) return [];
        if (Array.isArray(product.category_sale_tax_ids)) {
            return product.category_sale_tax_ids.slice(0, 1).map(String);
        }
        return [];
    }

    function normalizeIds(ids) {
        return InventoryMultiSelect ? InventoryMultiSelect.parseIds(ids) : [];
    }

    function rowTaxMultiSelectHtml() {
        return InventoryTaxSelect.html("inv-item-sale-gst", "No Tax");
    }

    function rowTaxFieldHtml() {
        return (
            '<div class="inv-mgmt-field inv-mgmt-field--sale-tax">' +
            '<div class="inv-sale-tax-labels">' +
            "<label>Tax for Sale</label>" +
            '<label class="inv-sale-tax-amount-label">Tax Amount</label>' +
            "</div>" +
            '<div class="inv-sale-tax-inline">' +
            rowTaxMultiSelectHtml() +
            '<input class="inv-mgmt-input inv-input-readonly inv-item-sale-tax-amount" type="text" readonly placeholder="0.00" value="" aria-label="Tax Amount" title="Tax Amount"/>' +
            "</div></div>"
        );
    }

    function getRowUnitTaxAmount(row) {
        var rate = getRowTaxRate(row);
        if (rate <= 0) return 0;
        return extractGstFromInclusive(getRowAfterDistributorPrice(row), rate);
    }

    function updateRowSaleTaxAmount(row, qty) {
        var taxAmountEl = row.querySelector(".inv-item-sale-tax-amount");
        if (!taxAmountEl) return;

        var select = row.querySelector(".inv-item-product");
        var product = select && select.value ? getProduct(select.value) : null;
        if (!product || getRowTaxRate(row) <= 0 || qty <= 0) {
            taxAmountEl.value = "";
            return;
        }

        var lineTax = roundMoney(getRowUnitTaxAmount(row) * qty);
        taxAmountEl.value = lineTax > 0 ? InventoryApi.formatMoney(lineTax) : "";
    }

    function updateRowPriceWithoutGst(row, priceWithGstUnit, qty) {
        var el = row.querySelector(".inv-item-price-without-gst");
        if (!el) return;

        var inclusiveUnit = Number(priceWithGstUnit || 0);
        if (isNaN(inclusiveUnit) || inclusiveUnit <= 0 || qty <= 0) {
            el.value = "";
            return;
        }

        var taxAmountUnit = getRowUnitTaxAmount(row);
        var withoutGstUnit = roundMoney(Math.max(0, inclusiveUnit - taxAmountUnit));
        el.value = InventoryApi.formatMoney(roundMoney(withoutGstUnit * qty));
    }

    function initRowTaxMultiSelect(row, selectedIds) {
        var root = row.querySelector(".inv-item-sale-gst");
        if (!root || !window.InventoryTaxSelect) return;

        InventoryTaxSelect.init(root, {
            taxes: taxes,
            selectedIds: normalizeIds(selectedIds),
            placeholder: "No Tax",
            onChange: function () {
                updateRowPricing(row);
            }
        });
    }

    function getRowTaxRate(row) {
        if (row.dataset.gstRate != null) return Number(row.dataset.gstRate);
        var root = row.querySelector(".inv-item-sale-gst");
        if (!root || !window.InventoryTaxSelect) return 0;
        return getCombinedTaxRate(InventoryTaxSelect.getSelected(root));
    }

    function setRowTaxSelection(row, selectedIds, silent) {
        var root = row.querySelector(".inv-item-sale-gst");
        if (!root || !window.InventoryTaxSelect) return;
        var ids = normalizeIds(selectedIds);
        if (typeof InventoryTaxSelect.refresh === "function") {
            InventoryTaxSelect.refresh(root, taxes, ids);
            return;
        }
        InventoryTaxSelect.setSelected(root, ids, silent !== false);
    }

    function refreshAllRowTaxSelects() {
        InventoryTaxSelect.refreshAll("#purchase-items-container .inv-item-sale-gst", taxes);
        InventoryTaxSelect.refreshAll("#purchase-service-items-container .inv-item-service-gst", taxes);
        syncRowTaxesFromProducts();
        document.querySelectorAll("#purchase-items-container .inv-mgmt-item-row").forEach(function (row) {
            updateRowPricing(row);
        });
        document.querySelectorAll("#purchase-service-items-container .inv-mgmt-item-row--service").forEach(function (row) {
            updateServiceRowPricing(row);
        });
    }

    function syncRowTaxesFromProducts() {
        document.querySelectorAll("#purchase-items-container .inv-mgmt-item-row").forEach(function (row) {
            if (row.dataset.saleLineId) return;
            var select = row.querySelector(".inv-item-product");
            if (!select || !select.value) return;
            var product = getProduct(select.value);
            if (!product) return;
            var root = row.querySelector(".inv-item-sale-gst");
            if (!root || !window.InventoryTaxSelect) return;
            var current = InventoryTaxSelect.getSelected(root);
            if (current.length) return;
            var defaults = getProductDefaultSaleTaxIds(product);
            if (!defaults.length) return;
            setRowTaxSelection(row, defaults, true);
            updateRowPricing(row);
        });
    }

    function loadTaxes() {
        return InventoryApi.request(TAXES_API, "?page_size=100&ordering=key").then(function (body) {
            taxes = body && body.isSuccess ? (body.data.items || []) : [];
            refreshAllRowTaxSelects();
        });
    }

    function getProductBuyDetails(product) {
        if (!product) {
            return { actual: 0, gstAmount: 0, buyPrice: 0 };
        }
        var rate = product.tax ? Number(product.tax_value || 0) : 0;
        var actual = Number(product.actual_price || 0);
        if (!actual && product.purchase_price) {
            actual = rate > 0
                ? roundMoney(Number(product.purchase_price) / (1 + rate / 100))
                : Number(product.purchase_price);
        }
        var gstAmount = computeGstAmount(actual, rate);
        var buyPrice = Number(product.purchase_price || 0) || computeWithGst(actual, rate);
        return {
            actual: actual,
            gstAmount: gstAmount,
            buyPrice: buyPrice
        };
    }

    function getRowDiscountValue(row, inputSelector) {
        var el = row.querySelector(inputSelector || ".inv-item-discount-value");
        var val = Number(el ? el.value : 0);
        if (isNaN(val) || val < 0) return 0;
        return val;
    }

    function getRowDiscountType(row, toggleSelector) {
        var toggle = row.querySelector(toggleSelector || ".inv-item-discount-type-toggle");
        if (!toggle) return "percent";
        return toggle.getAttribute("data-discount-type") === "amount" ? "amount" : "percent";
    }

    function setRowDiscountType(row, type, toggleSelector, buttonSelector) {
        var toggle = row.querySelector(toggleSelector || ".inv-item-discount-type-toggle");
        if (!toggle) return;
        var normalized = type === "amount" ? "amount" : "percent";
        toggle.setAttribute("data-discount-type", normalized);
        toggle.querySelectorAll(buttonSelector || ".inv-item-discount-type").forEach(function (btn) {
            var isActive = btn.getAttribute("data-type") === normalized;
            btn.classList.toggle("is-active", isActive);
            btn.setAttribute("aria-pressed", isActive ? "true" : "false");
        });
    }

    function wireRowDiscountTypeToggle(row, options) {
        options = options || {};
        var toggleSelector = options.toggleSelector || ".inv-item-discount-type-toggle";
        var buttonSelector = options.buttonSelector || ".inv-item-discount-type";
        var inputSelector = options.inputSelector || ".inv-item-discount-value";
        var toggle = row.querySelector(toggleSelector);
        if (!toggle || toggle.dataset.wired === "1") return;
        toggle.dataset.wired = "1";
        toggle.querySelectorAll(buttonSelector).forEach(function (btn) {
            btn.addEventListener("click", function () {
                setRowDiscountType(row, btn.getAttribute("data-type") || "percent", toggleSelector, buttonSelector);
                updateRowPricing(row);
            });
        });
        var inputEl = row.querySelector(inputSelector);
        if (inputEl && !inputEl.dataset.discountWired) {
            inputEl.dataset.discountWired = "1";
            inputEl.addEventListener("input", function () {
                if (getRowDiscountType(row, toggleSelector) === "percent") {
                    var discountVal = getRowDiscountValue(row, inputSelector);
                    if (discountVal > 100) inputEl.value = "100";
                }
                updateRowPricing(row);
            });
            inputEl.addEventListener("change", function () {
                updateRowPricing(row);
            });
        }
    }

    function applyDiscountToPrice(basePrice, discountValue, discountType) {
        var base = Number(basePrice || 0);
        if (isNaN(base) || base < 0) base = 0;
        var discount = Number(discountValue || 0);
        if (isNaN(discount) || discount <= 0) return roundMoney(base);

        if (discountType === "percent") {
            var pct = Math.min(discount, 100);
            return roundMoney(Math.max(0, base * (1 - pct / 100)));
        }
        return roundMoney(Math.max(0, base - discount));
    }

    function getRowSellPrice(row) {
        var saleActualEl = row.querySelector(".inv-item-sale-actual");
        if (!saleActualEl) return 0;
        var base = Number(saleActualEl.value || 0);
        if (isNaN(base) || base < 0) base = 0;
        return base;
    }

    function getRowNewSalePrice(row) {
        return applyDiscountToPrice(
            getRowSellPrice(row),
            getRowDiscountValue(row, ".inv-item-discount-value"),
            getRowDiscountType(row, ".inv-item-discount-type-toggle")
        );
    }

    function getRowAfterDistributorPrice(row) {
        return applyDiscountToPrice(
            getRowNewSalePrice(row),
            getRowDiscountValue(row, ".inv-item-distributor-discount-value"),
            getRowDiscountType(row, ".inv-item-distributor-discount-type-toggle")
        );
    }

    function getRowFinalSalePrice(row) {
        // MRP, discounts, and distributor margin are all on GST-inclusive amounts.
        // Salon price stays tax-inclusive; GST is extracted for reporting, not added again.
        return getRowAfterDistributorPrice(row);
    }

    function getRowDiscountAmount(row, quantity) {
        var qty = Number(quantity || 0);
        if (isNaN(qty) || qty <= 0) return 0;
        var sellPrice = getRowSellPrice(row);
        var afterDiscounts = getRowAfterDistributorPrice(row);
        return roundMoney(Math.max(0, (sellPrice - afterDiscounts) * qty));
    }

    function getRowTaxAmount(row, quantity) {
        var qty = Number(quantity || 0);
        if (isNaN(qty) || qty <= 0) return 0;
        var salonPrice = getRowAfterDistributorPrice(row);
        var rate = getRowTaxRate(row);
        return roundMoney(extractGstFromInclusive(salonPrice, rate) * qty);
    }

    function clearRowDiscount(row) {
        var valueEl = row.querySelector(".inv-item-discount-value");
        if (valueEl) valueEl.value = "";
        setRowDiscountType(row, "percent");
        var distributorValueEl = row.querySelector(".inv-item-distributor-discount-value");
        if (distributorValueEl) distributorValueEl.value = "";
        setRowDiscountType(row, "percent", ".inv-item-distributor-discount-type-toggle", ".inv-item-distributor-discount-type");
    }

    function discountFieldHtml(config) {
        config = config || {};
        var label = config.label || "Discount";
        var valueClass = config.valueClass || "inv-item-discount-value";
        var toggleClass = config.toggleClass || "inv-item-discount-type-toggle";
        var buttonClass = config.buttonClass || "inv-item-discount-type";
        var discountType = config.discount_type === "amount" ? "amount" : "percent";
        var discountValue = config.discount_value != null && config.discount_value !== "" ? config.discount_value : "";

        return (
            '<div class="inv-mgmt-field inv-mgmt-field--discount">' +
            '<label>' + label + ' <span class="inv-field-optional">(optional)</span></label>' +
            '<div class="inv-discount-inline">' +
            '<input class="inv-mgmt-input ' + valueClass + '" type="number" min="0" step="0.01" placeholder="0" value="' + discountValue + '"/>' +
            '<div class="' + toggleClass + ' inv-discount-type-toggle" role="group" aria-label="' + label + ' type" data-discount-type="' + discountType + '">' +
            '<button type="button" class="inv-discount-type-btn ' + buttonClass + (discountType === "percent" ? " is-active" : "") + '" data-type="percent" aria-pressed="' + (discountType === "percent" ? "true" : "false") + '" title="Percentage discount">%</button>' +
            '<button type="button" class="inv-discount-type-btn ' + buttonClass + (discountType === "amount" ? " is-active" : "") + '" data-type="amount" aria-pressed="' + (discountType === "amount" ? "true" : "false") + '" title="Fixed amount discount">₹</button>' +
            "</div></div></div>"
        );
    }

    function updateRowPricing(row, skipTotals) {
        if (!row) return;
        var taxRoot = row.querySelector(".inv-item-sale-gst");
        if (taxRoot) {
            var trigger = taxRoot.querySelector(".inv-multi-select-trigger");
            if (trigger) trigger.disabled = row.dataset.gstRate != null;
            if (row.dataset.gstRate != null) {
                var label = taxRoot.querySelector(".inv-multi-select-label");
                if (label) label.textContent = "GST (" + row.dataset.gstRate + "%)";
            }
        }
        var totalEl = row.querySelector(".inv-item-total");

        var qty = Number(row.querySelector(".inv-item-qty").value || 0);
        if (isNaN(qty) || qty < 0) qty = 0;

        var salePriceEl = row.querySelector(".inv-item-sale-price");
        var salonSaleUnit = getRowNewSalePrice(row);
        if (salePriceEl) {
            salePriceEl.value = qty > 0 && salonSaleUnit > 0
                ? InventoryApi.formatMoney(roundMoney(salonSaleUnit * qty))
                : "";
        }

        var newSaleEl = row.querySelector(".inv-item-new-sale-price");
        var afterDistributorUnit = getRowAfterDistributorPrice(row);
        if (newSaleEl) {
            newSaleEl.value = qty > 0 && afterDistributorUnit > 0
                ? InventoryApi.formatMoney(roundMoney(afterDistributorUnit * qty))
                : "";
        }

        var finalUnit = getRowFinalSalePrice(row);
        var linePriceWithGst = qty > 0 ? roundMoney(finalUnit * qty) : 0;
        if (totalEl) {
            totalEl.value = linePriceWithGst > 0 ? InventoryApi.formatMoney(linePriceWithGst) : "";
        }
        updateRowSaleTaxAmount(row, qty);
        updateRowPriceWithoutGst(row, finalUnit, qty);
        if (!skipTotals) {
            updateSaleTotals();
        }
    }

    function getRowSaleAmounts(row) {
        var productId = row.querySelector(".inv-item-product").value;
        if (!productId) {
            return { saleAmount: 0, totalCost: 0, profit: 0 };
        }
        var product = getProduct(productId);
        if (!product) {
            return { saleAmount: 0, totalCost: 0, profit: 0 };
        }
        var qty = Number(row.querySelector(".inv-item-qty").value || 0);
        if (isNaN(qty) || qty <= 0) qty = 0;
        var saleAmount = roundMoney(getRowFinalSalePrice(row) * (qty || 1));
        var totalCost = roundMoney(getProductBuyDetails(product).buyPrice * (qty || 1));
        return {
            saleAmount: saleAmount,
            totalCost: totalCost,
            profit: roundMoney(saleAmount - totalCost)
        };
    }

    function calculateSaleTotals() {
        var saleAmount = 0;
        var totalCost = 0;
        var profit = 0;
        document.querySelectorAll("#purchase-items-container .inv-mgmt-item-row").forEach(function (row) {
            if (!row.querySelector(".inv-item-product").value) return;
            var amounts = getRowSaleAmounts(row);
            saleAmount += amounts.saleAmount;
            totalCost += amounts.totalCost;
            profit += amounts.profit;
        });
        return {
            saleAmount: roundMoney(saleAmount),
            totalCost: roundMoney(totalCost),
            profit: roundMoney(profit)
        };
    }

    function getBillAmount() {
        if (saleFormKind === "service") {
            return calculateServiceSaleTotals().saleAmount;
        }
        return calculateSaleTotals().saleAmount;
    }

    function setSaleTotalsDisplay(totalCost, saleAmount) {
        var costEl = document.getElementById("purchase-total-cost");
        var saleEl = document.getElementById("purchase-sale-amount");
        if (costEl) costEl.textContent = InventoryApi.formatMoney(totalCost);
        if (saleEl) saleEl.textContent = InventoryApi.formatMoney(saleAmount);
        syncPaymentFields();
    }

    function updateSaleTotals() {
        var totals = calculateSaleTotals();
        setSaleTotalsDisplay(totals.totalCost, totals.saleAmount);
    }

    function isPaidSegmentSelected() {
        var input = document.getElementById("purchase-mark-paid");
        return !!(input && input.checked);
    }

    function getPaidAmountValue() {
        var paidInput = document.getElementById("purchase-paid-amount");
        if (!paidInput) return 0;
        var value = Number(paidInput.value);
        return Number.isFinite(value) ? value : 0;
    }

    function isPartialPaidAmount() {
        if (!isPaidSegmentSelected()) return false;
        var billAmount = getBillAmount();
        if (billAmount <= 0) return false;
        return getPaidAmountValue() + 0.0001 < billAmount;
    }

    function isFullPaymentReceived() {
        if (!isPaidSegmentSelected()) return false;
        var paidAmount = getPaidAmountValue();
        if (paidAmount <= 0) return false;
        return !isPartialPaidAmount();
    }

    function shouldShowDueDateField() {
        if (!isPaidSegmentSelected()) return true;
        return isPartialPaidAmount();
    }

    function syncPaidAmountFromBill() {
        var paidInput = document.getElementById("purchase-paid-amount");
        if (!paidInput || !isPaidSegmentSelected()) return;
        if (paidInput.dataset.manual === "1") return;
        paidInput.value = getBillAmount().toFixed(2);
    }

    function syncPaymentFields() {
        var dueWrap = document.getElementById("purchase-due-date-wrap");
        var paidWrap = document.getElementById("purchase-paid-amount-wrap");
        var dueInput = document.getElementById("purchase-invoice-due-date");
        var paidSelected = isPaidSegmentSelected();

        if (paidWrap) paidWrap.classList.toggle("inv-hidden", !paidSelected);

        if (paidSelected) {
            syncPaidAmountFromBill();
        } else {
            var paidInput = document.getElementById("purchase-paid-amount");
            if (paidInput) {
                paidInput.value = "";
                paidInput.dataset.manual = "0";
            }
        }

        var showDueDate = shouldShowDueDateField();
        if (dueWrap) dueWrap.classList.toggle("inv-hidden", !showDueDate);
        if (!showDueDate && dueInput) InventoryApi.setDateInputValue(dueInput, "");
        if (showDueDate && dueInput && !InventoryApi.getDateInputValue(dueInput) && !editingPurchaseId) {
            applyDefaultDueDateToForm();
        }
    }

    function formatQty(value) {
        var num = Number(value || 0);
        return Number.isInteger(num) ? String(num) : num.toFixed(2);
    }

    function getProduct(productId) {
        return products.find(function (p) {
            return String(p.id) === String(productId);
        });
    }

    function getAllocatedByProduct(excludeRow) {
        var totals = {};
        document.querySelectorAll("#purchase-items-container .inv-mgmt-item-row").forEach(function (row) {
            if (row === excludeRow) return;
            var productId = row.querySelector(".inv-item-product").value;
            if (!productId) return;
            var qty = Number(row.querySelector(".inv-item-qty").value || 0);
            totals[productId] = (totals[productId] || 0) + qty;
        });
        return totals;
    }

    function getRemainingQty(productId, excludeRow) {
        var product = getProduct(productId);
        if (!product) return 0;
        var allocated = getAllocatedByProduct(excludeRow);
        var base = Number(product.quantity || 0) + getEditingStockBonus(productId);
        return Math.max(0, base - (allocated[productId] || 0));
    }

    function hasAvailableProducts(excludeRow) {
        if (isDraftFlow()) {
            return products.length > 0;
        }
        var allocated = getAllocatedByProduct(excludeRow);
        return products.some(function (product) {
            var remaining = Number(product.quantity || 0) + getEditingStockBonus(product.id) -
                (allocated[product.id] || 0);
            return remaining > 0;
        });
    }

    function productLabel(product, availableQty) {
        var sku = product.sku ? " (" + product.sku + ")" : "";
        var qty = availableQty != null ? availableQty : Number(product.quantity || 0);
        return InventoryApi.escapeHtml(product.name) + sku +
            " — Available: " + formatQty(qty);
    }

    function productOptions(selectedId, excludeRow) {
        if (!products.length) {
            return '<option value="">No products in stock — add a purchase first</option>';
        }

        var allocated = getAllocatedByProduct(excludeRow);
        var options = '<option value="">Select product</option>';

        products.forEach(function (product) {
            var remaining = Number(product.quantity || 0) + getEditingStockBonus(product.id) -
                (allocated[product.id] || 0);
            var isSelected = String(product.id) === String(selectedId);
            if (!isDraftFlow() && remaining <= 0 && !isSelected) {
                return;
            }
            var selected = isSelected ? " selected" : "";
            var displayQty = isSelected ? getRemainingQty(product.id, excludeRow) : remaining;
            options += '<option value="' + product.id + '"' + selected + '>' +
                productLabel(product, displayQty) + "</option>";
        });

        if (options === '<option value="">Select product</option>') {
            return '<option value="">No products available — all stock is allocated</option>';
        }

        return options;
    }

    function refreshAllProductSelects(preserveCurrentValues) {
        document.querySelectorAll("#purchase-items-container .inv-mgmt-item-row").forEach(function (row) {
            var select = row.querySelector(".inv-item-product");
            if (!select) return;
            var selectedId = select.value;
            var selectedOption = select.selectedOptions.length ? select.selectedOptions[0].cloneNode(true) : null;
            select.innerHTML = productOptions(selectedId, row);
            if (selectedId && !Array.prototype.some.call(select.options, function (option) {
                return option.value === selectedId;
            }) && preserveCurrentValues && selectedOption) {
                select.appendChild(selectedOption);
            }
            if (selectedId && getRemainingQty(selectedId, row) <= 0 && !preserveCurrentValues) {
                select.value = "";
                applyProductToRow(row, null);
                return;
            }
            if (selectedId) {
                select.value = String(selectedId);
                var product = getProduct(select.value);
                if (!preserveCurrentValues) updateRowQtyLimits(row, product);
                if (product) {
                    var taxRoot = row.querySelector(".inv-item-sale-gst");
                    if (taxRoot && window.InventoryTaxSelect && !InventoryTaxSelect.getSelected(taxRoot).length) {
                        setRowTaxSelection(row, getProductDefaultSaleTaxIds(product), true);
                    }
                }
            }
            if (window.InventorySearchableSelect) {
                InventorySearchableSelect.refresh(select);
            }
        });
    }

    function getProductMrp(product) {
        if (!product) return 0;
        var batchMrp = Number(product.max_batch_mrp || 0);
        var productMrp = Number(product.mrp || 0);
        var highest = Math.max(
            isNaN(batchMrp) ? 0 : batchMrp,
            isNaN(productMrp) ? 0 : productMrp
        );
        return highest < 0 ? 0 : highest;
    }

    function defaultSalePrice(product) {
        if (!product) return "";
        var mrp = getProductMrp(product);
        if (mrp > 0) return mrp;
        if (product.sale_price != null && product.sale_price !== "" && Number(product.sale_price) > 0) {
            return product.sale_price;
        }
        return "";
    }

    function updateRowQtyLimits(row, product) {
        var qtyInput = row.querySelector(".inv-item-qty");
        if (!qtyInput) return;

        if (!product) {
            qtyInput.removeAttribute("max");
            row.dataset.maxQty = "";
            updateRowPricing(row);
            return;
        }

        var available = getRemainingQty(product.id, row);
        row.dataset.maxQty = String(available);
        if (available <= 0) {
            qtyInput.value = "";
            qtyInput.removeAttribute("max");
            qtyInput.min = 0;
        } else {
            qtyInput.max = available;
            qtyInput.min = 0;
            if (Number(qtyInput.value || 0) > available) {
                qtyInput.value = available > 0 ? available : "";
            }
        }
        updateRowPricing(row);
    }

    function applyProductToRow(row, product, options) {
        options = options || {};
        if (!options.preserveSalePricing) {
            delete row.dataset.gstRate;
            delete row.dataset.saleLineId;
            delete row.dataset.savedTaxIds;
        }
        var saleActualInput = row.querySelector(".inv-item-sale-actual");
        if (!product) {
            updateRowQtyLimits(row, null);
            if (saleActualInput) saleActualInput.value = "";
            setRowTaxSelection(row, [], true);
            clearRowDiscount(row);
            updateRowPricing(row);
            return;
        }

        updateRowQtyLimits(row, product);

        if (!options.preserveSalePricing) {
            setRowTaxSelection(row, getProductDefaultSaleTaxIds(product), true);
        }

        if (saleActualInput && options.updatePrice !== false) {
            var shouldSetPrice = options.forcePrice || saleActualInput.value === "";
            if (shouldSetPrice) {
                saleActualInput.value = defaultSalePrice(product);
            }
        }
        updateRowPricing(row);
    }

    function updateRowTotal(row) {
        updateRowPricing(row);
    }

    function createItemRow(data) {
        data = data || {};
        var row = document.createElement("div");
        row.className = "inv-mgmt-item-row inv-mgmt-item-row--sale";
        if (data.id) row.dataset.saleLineId = data.id;
        if (data.gst_rate != null) row.dataset.gstRate = data.gst_rate;
        if (data.id) row.dataset.savedTaxIds = JSON.stringify(data.sale_tax_ids || []);
        row.innerHTML =
            '<div class="inv-mgmt-field"><label>Available Product</label><select class="inv-mgmt-select inv-item-product" required>' + productOptions(data.product_id, row) + "</select></div>" +
            '<div class="inv-mgmt-field"><label>MRP Price</label><input class="inv-mgmt-input inv-item-sale-actual" type="number" min="0" step="0.01" placeholder="0.00" value="' + (data.sale_actual_price != null && data.sale_actual_price !== "" ? data.sale_actual_price : "") + '" required/></div>' +
            '<div class="inv-mgmt-field"><label>Quantity</label><input class="inv-mgmt-input inv-item-qty" type="number" min="0" step="0.01" placeholder="1" value="' + (data.quantity != null && data.quantity !== "" ? data.quantity : 1) + '" required/></div>' +
            discountFieldHtml({
                label: "Salon discount",
                discount_type: data.discount_type,
                discount_value: data.discount_value
            }) +
            '<div class="inv-mgmt-field"><label>Sale Price</label><input class="inv-mgmt-input inv-item-sale-price" type="text" readonly placeholder="0.00" value=""/></div>' +
            discountFieldHtml({
                label: "Distributor Discount",
                valueClass: "inv-item-distributor-discount-value",
                toggleClass: "inv-item-distributor-discount-type-toggle",
                buttonClass: "inv-item-distributor-discount-type",
                discount_type: data.distributor_discount_type,
                discount_value: data.distributor_discount_value
            }) +
            '<div class="inv-mgmt-field"><label>New Sale Price</label><input class="inv-mgmt-input inv-item-new-sale-price" type="text" readonly placeholder="0.00" value=""/></div>' +
            '<div class="inv-mgmt-field"><label>Price without GST </label><input class="inv-mgmt-input inv-input-readonly inv-item-price-without-gst" type="text" readonly placeholder="0.00" value=""/></div>' +
            rowTaxFieldHtml() +
            '<div class="inv-mgmt-field"><label>Total Price (with gst)</label><input class="inv-mgmt-input inv-item-total" type="text" readonly value="0.00"/></div>' +
            '<div class="inv-mgmt-item-row-remove">' +
            '<button type="button" class="inv-row-action-btn inv-row-action-btn--delete inv-item-remove" title="Remove" aria-label="Remove product row">' +
            '<span class="material-symbols-outlined">delete</span></button></div>';

        row.querySelector(".inv-item-qty").addEventListener("input", function () {
            var product = getProduct(row.querySelector(".inv-item-product").value);
            if (product) {
                var max = getRemainingQty(product.id, row);
                var val = Number(row.querySelector(".inv-item-qty").value || 0);
                if (val > max) {
                    row.querySelector(".inv-item-qty").value = max > 0 ? max : "";
                    InventoryToast.warning("Quantity cannot exceed available stock (" + formatQty(max) + ").");
                }
            }
            updateRowPricing(row);
            refreshAllProductSelects();
        });
        row.querySelector(".inv-item-sale-actual").addEventListener("input", function () {
            updateRowPricing(row);
        });
        row.querySelector(".inv-item-sale-actual").addEventListener("change", function () {
            updateRowPricing(row);
        });
        wireRowDiscountTypeToggle(row);
        wireRowDiscountTypeToggle(row, {
            toggleSelector: ".inv-item-distributor-discount-type-toggle",
            buttonSelector: ".inv-item-distributor-discount-type",
            inputSelector: ".inv-item-distributor-discount-value"
        });
        initRowTaxMultiSelect(row, data.sale_tax_ids || data.sale_tax_id || []);
        row.querySelector(".inv-item-remove").addEventListener("click", function () {
            row.remove();
            refreshAllProductSelects();
            updateSaleTotals();
        });

        var select = row.querySelector(".inv-item-product");
        select.addEventListener("change", function () {
            applyProductToRow(row, getProduct(select.value), { forcePrice: true });
            refreshAllProductSelects();
        });

        if (data.product_id) {
            applyProductToRow(row, getProduct(data.product_id), {
                updatePrice: data.sale_actual_price == null || data.sale_actual_price === "",
                preserveSalePricing: !!data.preserveSalePricing
            });
        } else {
            updateRowPricing(row);
        }
        syncRowTaxesFromProducts();
        return row;
    }

    function getService(serviceId) {
        return services.find(function (item) {
            return String(item.id) === String(serviceId);
        }) || null;
    }

    function applyServiceDefaultsToRow(row) {
        var select = row.querySelector(".inv-item-service");
        var baseEl = row.querySelector(".inv-item-service-base");
        if (!select || !baseEl) return;
        var service = getService(select.value);
        if (!service) {
            baseEl.value = "";
            return;
        }
        if (service.base_price != null && service.base_price !== "") {
            baseEl.value = String(Number(service.base_price));
        } else {
            baseEl.value = "";
        }
    }

    function serviceOptions(selectedId) {
        var html = '<option value="">Select service</option>';
        services.forEach(function (item) {
            html +=
                '<option value="' + item.id + '"' +
                (String(item.id) === String(selectedId || "") ? " selected" : "") +
                ">" + InventoryApi.escapeHtml(item.name || "") + "</option>";
        });
        return html;
    }

    function refreshAllServiceSelects(targetSelect, preferredIdForTarget) {
        document.querySelectorAll("#purchase-service-items-container .inv-item-service").forEach(function (select) {
            var current = select.value;
            if (
                targetSelect &&
                select === targetSelect &&
                preferredIdForTarget != null &&
                preferredIdForTarget !== ""
            ) {
                current = String(preferredIdForTarget);
            }
            select.innerHTML = serviceOptions(current);
            select.value = current ? String(current) : "";
            if (window.InventorySearchableSelect) {
                InventorySearchableSelect.refresh(select);
            }
        });
    }

    function loadServices(targetSelect, preferredIdForTarget) {
        return catalogRequest("services", "?page_size=100&ordering=name").then(function (body) {
            services = body && body.isSuccess ? (body.data.items || []) : [];
            refreshAllServiceSelects(targetSelect || null, preferredIdForTarget);
            return services;
        });
    }

    function serviceRowTaxFieldHtml() {
        return (
            '<div class="inv-mgmt-field inv-mgmt-field--sale-tax">' +
            '<div class="inv-sale-tax-labels">' +
            "<label>GST</label>" +
            '<label class="inv-sale-tax-amount-label">Tax Amount</label>' +
            "</div>" +
            '<div class="inv-sale-tax-inline">' +
            InventoryTaxSelect.html("inv-item-service-gst", "No Tax") +
            '<input class="inv-mgmt-input inv-input-readonly inv-item-service-tax-amount" type="text" readonly placeholder="0.00" value="" aria-label="Tax Amount" title="Tax Amount"/>' +
            "</div></div>"
        );
    }

    function getServiceRowTaxRate(row) {
        var root = row.querySelector(".inv-item-service-gst");
        if (!root || !window.InventoryTaxSelect) return 0;
        return getCombinedTaxRate(InventoryTaxSelect.getSelected(root));
    }

    function updateServiceRowPricing(row) {
        var baseEl = row.querySelector(".inv-item-service-base");
        var taxAmountEl = row.querySelector(".inv-item-service-tax-amount");
        var totalEl = row.querySelector(".inv-item-service-total");
        var base = Number(baseEl ? baseEl.value : 0);
        if (isNaN(base) || base < 0) base = 0;
        var rate = getServiceRowTaxRate(row);
        var taxAmount = rate > 0 ? computeGstAmount(base, rate) : 0;
        var total = roundMoney(base + taxAmount);
        if (taxAmountEl) {
            taxAmountEl.value = taxAmount > 0 ? InventoryApi.formatMoney(taxAmount) : "";
        }
        if (totalEl) totalEl.value = InventoryApi.formatMoney(total);
        updateServiceSaleTotals();
    }

    function initServiceRowTaxMultiSelect(row, selectedIds) {
        var root = row.querySelector(".inv-item-service-gst");
        if (!root || !window.InventoryTaxSelect) return;
        var ids = normalizeIds(selectedIds).slice(0, 1);
        InventoryTaxSelect.init(root, {
            taxes: taxes,
            selectedIds: ids,
            placeholder: "No Tax",
            maxSelections: 1,
            onChange: function () {
                updateServiceRowPricing(row);
            }
        });
    }

    function calculateServiceSaleTotals() {
        var subtotal = 0;
        var taxTotal = 0;
        document.querySelectorAll("#purchase-service-items-container .inv-mgmt-item-row--service").forEach(function (row) {
            var base = Number(row.querySelector(".inv-item-service-base").value || 0);
            if (isNaN(base) || base < 0) base = 0;
            var rate = getServiceRowTaxRate(row);
            var taxAmount = rate > 0 ? computeGstAmount(base, rate) : 0;
            subtotal = roundMoney(subtotal + base);
            taxTotal = roundMoney(taxTotal + taxAmount);
        });
        return {
            subtotal: subtotal,
            taxTotal: taxTotal,
            saleAmount: roundMoney(subtotal + taxTotal)
        };
    }

    function updateServiceSaleTotals() {
        var totals = calculateServiceSaleTotals();
        var subtotalEl = document.getElementById("purchase-service-subtotal");
        var taxEl = document.getElementById("purchase-service-tax-total");
        var saleEl = document.getElementById("purchase-service-sale-amount");
        if (subtotalEl) subtotalEl.textContent = InventoryApi.formatMoney(totals.subtotal);
        if (taxEl) taxEl.textContent = InventoryApi.formatMoney(totals.taxTotal);
        if (saleEl) saleEl.textContent = InventoryApi.formatMoney(totals.saleAmount);
        if (saleFormKind === "service") {
            syncPaymentFields();
        }
    }

    function createServiceItemRow(data) {
        data = data || {};
        var row = document.createElement("div");
        row.className = "inv-mgmt-item-row inv-mgmt-item-row--service";
        row.innerHTML =
            '<div class="inv-mgmt-field"><label>Service Name</label>' +
            '<div class="inv-field-inline">' +
            '<select class="inv-mgmt-select inv-item-service" required>' + serviceOptions(data.service_id) + "</select>" +
            '<button type="button" class="inv-inline-add-btn inv-item-service-add" title="Add service" aria-label="Add service">' +
            '<span class="material-symbols-outlined">add</span></button></div></div>' +
            '<div class="inv-mgmt-field"><label>Base Price <span class="inv-field-optional">(optional)</span></label>' +
            '<input class="inv-mgmt-input inv-item-service-base" type="number" min="0" step="0.01" placeholder="0.00" value="' +
            (data.base_price != null && data.base_price !== "" ? data.base_price : "") + '"/></div>' +
            serviceRowTaxFieldHtml() +
            '<div class="inv-mgmt-field"><label>Subtotal</label>' +
            '<input class="inv-mgmt-input inv-input-readonly inv-item-service-total" type="text" readonly value="0.00"/></div>' +
            '<div class="inv-mgmt-item-row-remove">' +
            '<button type="button" class="inv-row-action-btn inv-row-action-btn--delete inv-item-service-remove" title="Remove" aria-label="Remove service row">' +
            '<span class="material-symbols-outlined">delete</span></button></div>';

        initServiceRowTaxMultiSelect(row, data.sale_tax_ids || []);

        row.querySelector(".inv-item-service-base").addEventListener("input", function () {
            updateServiceRowPricing(row);
        });
        row.querySelector(".inv-item-service-base").addEventListener("change", function () {
            updateServiceRowPricing(row);
        });
        row.querySelector(".inv-item-service").addEventListener("change", function () {
            applyServiceDefaultsToRow(row);
            updateServiceRowPricing(row);
        });
        row.querySelector(".inv-item-service-add").addEventListener("click", function () {
            openAddServiceModal(row.querySelector(".inv-item-service"));
        });
        row.querySelector(".inv-item-service-remove").addEventListener("click", function () {
            row.remove();
            ensureServiceItemRows();
            updateServiceSaleTotals();
        });

        updateServiceRowPricing(row);
        return row;
    }

    function addServiceItemRow(data) {
        var container = document.getElementById("purchase-service-items-container");
        if (!container) return null;
        var row = createServiceItemRow(data);
        container.appendChild(row);
        updateServiceSaleTotals();
        return row;
    }

    function ensureServiceItemRows() {
        var container = document.getElementById("purchase-service-items-container");
        if (!container) return;
        if (!container.querySelector(".inv-mgmt-item-row--service")) {
            addServiceItemRow(null);
        }
    }

    function resetServiceForm() {
        var container = document.getElementById("purchase-service-items-container");
        if (container) container.innerHTML = "";
        addServiceItemRow(null);
        updateServiceSaleTotals();
    }

    function openAddServiceModal(targetSelect) {
        serviceAddTargetSelect = targetSelect || null;
        var nameEl = document.getElementById("purchase-new-service-name");
        var priceEl = document.getElementById("purchase-new-service-base-price");
        if (nameEl) nameEl.value = "";
        if (priceEl) priceEl.value = "";
        if (window.InventoryModal) {
            InventoryModal.open("purchase-add-service-modal");
        }
        if (nameEl) {
            window.setTimeout(function () {
                nameEl.focus();
            }, 50);
        }
    }

    function saveNewServiceFromModal() {
        var nameEl = document.getElementById("purchase-new-service-name");
        var priceEl = document.getElementById("purchase-new-service-base-price");
        var name = nameEl ? nameEl.value.trim() : "";
        if (!name) {
            InventoryToast.error("Service name is required.");
            if (nameEl) nameEl.focus();
            return;
        }
        var priceRaw = priceEl ? String(priceEl.value || "").trim() : "";
        var basePrice = priceRaw === "" ? 0 : Number(priceRaw);
        if (isNaN(basePrice) || basePrice < 0) {
            InventoryToast.error("Enter a valid base price.");
            if (priceEl) priceEl.focus();
            return;
        }
        var saveBtn = document.getElementById("purchase-add-service-save-btn");
        if (saveBtn) saveBtn.disabled = true;
        catalogRequest("services", "", {
            method: "POST",
            body: { name: name, base_price: roundMoney(basePrice) }
        }).then(function (body) {
            if (!(body && body.isSuccess && body.data)) {
                var err = (body && body.message) || "Could not save service.";
                if (body && body.errors && body.errors.length) err = body.errors.join(" • ");
                InventoryToast.error(err);
                return;
            }
            InventoryToast.success(body.message || "Service created");
            if (window.InventoryModal) {
                InventoryModal.close("purchase-add-service-modal");
            }
            var targetSelect = serviceAddTargetSelect;
            return loadServices(targetSelect, body.data.id).then(function () {
                if (targetSelect) {
                    targetSelect.value = String(body.data.id);
                    if (window.InventorySearchableSelect) {
                        InventorySearchableSelect.refresh(targetSelect);
                    }
                    targetSelect.dispatchEvent(new Event("change", { bubbles: true }));
                }
                serviceAddTargetSelect = null;
            });
        }).catch(function () {
            InventoryToast.error("Network error while saving service.");
        }).then(function () {
            if (saveBtn) saveBtn.disabled = false;
        });
    }

    function setSaleFormKind(kind, options) {
        var opts = options || {};
        var nextKind = kind === "service" ? "service" : "product";
        saleFormKind = nextKind;

        var productPanel = document.getElementById("purchase-sale-kind-product");
        var servicePanel = document.getElementById("purchase-sale-kind-service");
        var kindBar = document.getElementById("purchase-sale-kind-bar");
        var productBtn = document.getElementById("purchase-sale-kind-product-btn");
        var serviceBtn = document.getElementById("purchase-sale-kind-service-btn");
        var saveBtn = document.getElementById("purchase-save-btn");
        var draftBtn = document.getElementById("purchase-save-draft-btn");
        var finalizeBtn = document.getElementById("purchase-finalize-btn");

        if (productPanel) productPanel.classList.toggle("inv-hidden", nextKind !== "product");
        if (servicePanel) {
            servicePanel.classList.toggle("inv-hidden", nextKind !== "service");
            servicePanel.setAttribute("aria-hidden", nextKind === "service" ? "false" : "true");
        }
        if (productBtn) productBtn.classList.toggle("is-active", nextKind === "product");
        if (serviceBtn) serviceBtn.classList.toggle("is-active", nextKind === "service");

        var hideKindBar = opts.hideKindBar === true;
        if (kindBar) kindBar.classList.toggle("inv-hidden", hideKindBar);

        if (!editingPurchaseId) {
            if (saveBtn) {
                saveBtn.classList.remove("inv-hidden");
                saveBtn.textContent = "Create Sale";
            }
            if (draftBtn) draftBtn.classList.remove("inv-hidden");
        }
        if (finalizeBtn) {
            finalizeBtn.classList.toggle("inv-hidden", !editingPurchaseIsDraft);
        }

        if (nextKind === "service") {
            if (!editingPurchaseId) {
                toggleMarkPaidField(true);
            }
            loadServices().then(function () {
                ensureServiceItemRows();
                updateServiceSaleTotals();
            });
            if (!taxes.length) loadTaxes();
        } else if (!editingPurchaseId) {
            syncPaymentFields();
        }
    }

    function setFormMode(mode, options) {
        var opts = options || {};
        var kind = opts.kind === "service" ? "service" : "product";
        var titleEl = document.getElementById("purchase-form-title");
        var saveBtn = document.getElementById("purchase-save-btn");
        var draftBtn = document.getElementById("purchase-save-draft-btn");
        var finalizeBtn = document.getElementById("purchase-finalize-btn");

        if (mode === "draft") {
            if (titleEl) titleEl.textContent = kind === "service" ? "Edit Draft Service Sale" : "Edit Draft Sale";
            if (saveBtn) saveBtn.textContent = "Update Draft";
            if (draftBtn) draftBtn.classList.add("inv-hidden");
            if (finalizeBtn) finalizeBtn.classList.remove("inv-hidden");
            if (kind === "service") {
                ensureServiceItemsEditablePanel();
            } else {
                ensureSaleItemsEditablePanel();
            }
            toggleInvoiceSettingField(true);
            toggleMarkPaidField(true);
            setSaleFormKind(kind, { hideKindBar: true });
            return;
        }

        if (mode === "edit") {
            if (titleEl) titleEl.textContent = kind === "service" ? "Edit Service Sale" : "Edit Sale";
            if (saveBtn) saveBtn.textContent = "Update Sale";
            if (draftBtn) draftBtn.classList.add("inv-hidden");
            if (finalizeBtn) finalizeBtn.classList.add("inv-hidden");
            if (kind === "service") {
                ensureServiceItemsReadonlyPanel();
            } else {
                ensureSaleItemsReadonlyPanel();
            }
            toggleInvoiceSettingField(false);
            toggleMarkPaidField(false);
            setSaleFormKind(kind, { hideKindBar: true });
        } else {
            if (titleEl) titleEl.textContent = "Add Sale";
            if (saveBtn) saveBtn.textContent = "Create Sale";
            if (draftBtn) draftBtn.classList.remove("inv-hidden");
            if (finalizeBtn) finalizeBtn.classList.add("inv-hidden");
            ensureSaleItemsEditablePanel();
            ensureServiceItemsEditablePanel();
            toggleInvoiceSettingField(true);
            toggleMarkPaidField(true);
            setSaleFormKind("service", { hideKindBar: false });
        }
    }

    function setServiceItemsEditable(editable) {
        var container = document.getElementById("purchase-service-items-container");
        if (!container) return;
        container.querySelectorAll(".inv-item-service").forEach(function (select) {
            select.disabled = !editable;
            if (window.InventorySearchableSelect) {
                InventorySearchableSelect.rebuild(select, function (el) {
                    el.disabled = !editable;
                });
            }
        });
        container.querySelectorAll(".inv-item-service-base").forEach(function (input) {
            input.readOnly = !editable;
            input.disabled = !editable;
        });
        container.querySelectorAll(".inv-item-remove, .inv-item-service-gst button, .inv-item-service-gst input").forEach(function (el) {
            el.disabled = !editable;
        });
        var addBtn = document.getElementById("purchase-add-service-item-btn");
        if (addBtn) addBtn.classList.toggle("inv-hidden", !editable);
    }

    function ensureServiceItemsReadonlyPanel() {
        var panel = document.getElementById("purchase-sale-kind-service");
        if (panel) panel.classList.add("inv-sale-items--readonly");
        setServiceItemsEditable(false);
    }

    function ensureServiceItemsEditablePanel() {
        var panel = document.getElementById("purchase-sale-kind-service");
        if (panel) panel.classList.remove("inv-sale-items--readonly");
        setServiceItemsEditable(true);
    }

    function populateServiceItemRows(lines) {
        var container = document.getElementById("purchase-service-items-container");
        if (!container) return;
        container.innerHTML = "";
        if (!lines || !lines.length) {
            if (!editingPurchaseId || editingPurchaseIsDraft) {
                addServiceItemRow(null);
            }
            setServiceItemsEditable(!editingPurchaseId || editingPurchaseIsDraft);
            updateServiceSaleTotals();
            return;
        }
        lines.forEach(function (line) {
            addServiceItemRow({
                service_id: line.service_id != null ? line.service_id : line.service,
                base_price: line.base_price,
                sale_tax_ids: Array.isArray(line.sale_tax_ids)
                    ? line.sale_tax_ids.map(function (id) { return String(id); })
                    : []
            });
        });
        setServiceItemsEditable(!editingPurchaseId || editingPurchaseIsDraft);
        updateServiceSaleTotals();
    }

    function populateServiceForm(sale) {
        var customerId = sale.customer || sale.customer_id || "";
        loadCustomers(customerId).then(function () {
            applyCustomerAddressesFromSelection(customerId, true);
        });
        InventoryApi.setDateInputValue(
            document.getElementById("purchase-date"),
            sale.sale_date || sale.purchase_date || ""
        );
        loadPaymentTypes(sale.payment_type || "");
        setSalePrintMetaForm(loadSalePrintMeta(sale.id), sale);
        var termsEl = document.getElementById("purchase-invoice-terms");
        var meta = loadSalePrintMeta(sale.id) || {};
        if (termsEl) {
            termsEl.value = Object.prototype.hasOwnProperty.call(meta, "terms")
                ? (meta.terms || "")
                : (sale.terms || "");
        }
        if (sale.is_draft) {
            var draftMeta = loadSalePrintMeta(sale.id) || {};
            setSalePaidToggle(draftMeta.is_paid === true);
            if (draftMeta.due_date) {
                InventoryApi.setDateInputValue(
                    document.getElementById("purchase-invoice-due-date"),
                    draftMeta.due_date
                );
            } else if (sale.due_date) {
                InventoryApi.setDateInputValue(
                    document.getElementById("purchase-invoice-due-date"),
                    sale.due_date
                );
            }
        } else if (!sale.is_paid) {
            toggleUnpaidDueDateEdit(true);
            InventoryApi.setDateInputValue(
                document.getElementById("purchase-invoice-due-date"),
                sale.due_date || ""
            );
        }
        populateServiceItemRows(sale.items || []);
    }

    function toggleMarkPaidField(show) {
        var wrap = document.getElementById("purchase-mark-paid-wrap");
        var paidWrap = document.getElementById("purchase-paid-amount-wrap");
        if (wrap) wrap.classList.toggle("inv-hidden", !show);
        if (!show) {
            toggleUnpaidDueDateEdit(false);
            if (paidWrap) paidWrap.classList.add("inv-hidden");
        } else {
            var segment = document.querySelector(".inv-sale-paid-segment");
            if (segment) segment.classList.remove("inv-hidden");
            syncPaymentFields();
        }
    }

    function toggleUnpaidDueDateEdit(show) {
        var wrap = document.getElementById("purchase-mark-paid-wrap");
        var paidWrap = document.getElementById("purchase-paid-amount-wrap");
        var dueWrap = document.getElementById("purchase-due-date-wrap");
        var segment = document.querySelector(".inv-sale-paid-segment");
        if (wrap) wrap.classList.toggle("inv-hidden", !show);
        if (segment) segment.classList.toggle("inv-hidden", show);
        if (paidWrap) paidWrap.classList.add("inv-hidden");
        if (dueWrap) dueWrap.classList.toggle("inv-hidden", !show);
    }

    function setSalePaidToggle(checked) {
        var input = document.getElementById("purchase-mark-paid");
        var paidInput = document.getElementById("purchase-paid-amount");
        if (!input) return;
        input.checked = !!checked;
        if (checked && paidInput) {
            paidInput.dataset.manual = "0";
        }
        syncPaymentFields();
        syncSalePaidSegmentUI(!!checked);
    }

    function syncSalePaidSegmentUI(isPaid) {
        document.querySelectorAll(".inv-sale-paid-segment-btn").forEach(function (btn) {
            var wantPaid = btn.getAttribute("data-paid") === "true";
            btn.classList.toggle("is-active", wantPaid === isPaid);
        });
    }

    function wireSalePaidToggle() {
        var input = document.getElementById("purchase-mark-paid");
        if (!input || input.dataset.wired === "1") return;
        input.dataset.wired = "1";
        document.querySelectorAll(".inv-sale-paid-segment-btn").forEach(function (btn) {
            btn.addEventListener("click", function () {
                setSalePaidToggle(btn.getAttribute("data-paid") === "true");
            });
        });

        var paidInput = document.getElementById("purchase-paid-amount");
        if (paidInput) {
            paidInput.addEventListener("input", function () {
                paidInput.dataset.manual = "1";
                syncPaymentFields();
            });
        }
    }

    function setSaleItemActionButtonsVisible(visible) {
        document.querySelectorAll(".purchase-add-item-btn, .purchase-tax-add-btn").forEach(function (btn) {
            btn.classList.toggle("inv-hidden", !visible);
        });
        var footerActions = document.querySelector("#purchases-form-panel .inv-mgmt-items-footer-actions");
        if (footerActions) footerActions.classList.toggle("inv-hidden", !visible);
    }

    function ensureSaleItemsReadonlyPanel() {
        var itemsPanel = document.querySelector("#purchases-form-panel .inv-mgmt-items-panel");
        var itemsTitle = itemsPanel ? itemsPanel.querySelector("h4") : null;

        if (itemsPanel) itemsPanel.classList.add("inv-sale-items--readonly");
        setSaleItemActionButtonsVisible(false);
        if (itemsTitle) itemsTitle.textContent = "Products on Invoice";
        setSaleItemsEditable(false);
    }

    function getLineProductId(line) {
        if (!line) return null;
        return line.product_id != null ? line.product_id : line.product;
    }

    function ensureSaleItemsEditablePanel() {
        var itemsPanel = document.querySelector("#purchases-form-panel .inv-mgmt-items-panel");
        var itemsTitle = itemsPanel ? itemsPanel.querySelector("h4") : null;

            if (itemsPanel) itemsPanel.classList.remove("inv-sale-items--readonly");
        setSaleItemActionButtonsVisible(true);
            if (itemsTitle) itemsTitle.textContent = "Products to Sell";
        setSaleItemsEditable(true);
    }

    function setSaleItemsEditable(editable) {
        var container = document.getElementById("purchase-items-container");
        if (!container) return;

        container.querySelectorAll(".inv-item-product").forEach(function (select) {
            select.disabled = !editable;
            if (window.InventorySearchableSelect) {
                InventorySearchableSelect.rebuild(select, function (el) {
                    el.disabled = !editable;
                });
            }
        });

        container.querySelectorAll(
            ".inv-item-qty, .inv-item-sale-actual, .inv-item-discount-value, .inv-item-distributor-discount-value"
        ).forEach(function (input) {
            input.readOnly = !editable;
            input.disabled = !editable;
        });

        container.querySelectorAll(
            ".inv-item-discount-type, .inv-item-distributor-discount-type, .inv-item-remove"
        ).forEach(function (btn) {
            btn.disabled = !editable;
        });

        container.querySelectorAll(".inv-item-sale-gst button, .inv-item-sale-gst input").forEach(function (el) {
            el.disabled = !editable;
        });
    }

    function enhanceSaleItemRows() {
        if (editingPurchaseId && !editingPurchaseIsDraft) {
            setSaleItemsEditable(false);
            return;
        }
        setSaleItemsEditable(true);
    }

    function buildRowDataFromPurchaseLine(line) {
        var productId = getLineProductId(line);
        var product = getProduct(productId);
        var qty = Number(line.quantity || 1) || 1;
        var listPrice = line.list_price != null && line.list_price !== ""
            ? Number(line.list_price)
            : Number(line.unit_price || 0);
        var discountValue = line.discount_value != null && line.discount_value !== ""
            ? line.discount_value
            : "";
        var distributorDiscountValue = line.distributor_discount_value != null && line.distributor_discount_value !== ""
            ? line.distributor_discount_value
            : "";
        var saleTaxIds = Array.isArray(line.sale_tax_ids)
            ? line.sale_tax_ids.map(function (id) { return String(id); })
            : [];

        var discountType = line.discount_type || "percent";

        if ((discountValue === "" || Number(discountValue) === 0) && Number(line.discount_amount || 0) > 0) {
            discountType = "amount";
            discountValue = roundMoney(Number(line.discount_amount) / qty);
        }

        return {
            id: line.id,
            gst_rate: line.gst_rate != null ? line.gst_rate : (Number(line.line_total) > Number(line.tax_amount)
                ? roundMoney(Number(line.tax_amount || 0) * 100 / (Number(line.line_total) - Number(line.tax_amount || 0))) : 0),
            product_id: productId,
            quantity: line.quantity,
            sale_actual_price: listPrice,
            discount_type: discountType,
            discount_value: discountValue,
            distributor_discount_type: line.distributor_discount_type || "percent",
            distributor_discount_value: distributorDiscountValue,
            sale_tax_ids: saleTaxIds,
            preserveSalePricing: true
        };
    }

    function populateItemRows(lines) {
        var container = document.getElementById("purchase-items-container");
        container.innerHTML = "";
        if (!editingPurchaseId || editingPurchaseIsDraft) {
            ensureSaleItemsEditablePanel();
        }

        if (!lines || !lines.length) {
            if (!editingPurchaseId || editingPurchaseIsDraft) {
                addItemRow(null, true);
            }
            enhanceSaleItemRows();
            updateSaleTotals();
            return;
        }

        lines.forEach(function (line) {
            container.appendChild(createItemRow(buildRowDataFromPurchaseLine(line)));
        });
        refreshAllProductSelects();
        enhanceSaleItemRows();
        updateSaleTotals();
    }

    function populateForm(purchase) {
        loadCustomers(purchase.customer || "").then(function () {
            applyCustomerAddressesFromSelection(purchase.customer, true);
            document.getElementById("purchase-billing-address").value = purchase.billing_address || "";
            document.getElementById("purchase-shipping-address").value = purchase.shipping_address || "";
        });
        InventoryApi.setDateInputValue(document.getElementById("purchase-date"), purchase.purchase_date || "");
        loadPaymentTypes(purchase.payment_type || "");
        setSalePrintMetaForm(loadSalePrintMeta(purchase.id), purchase);
        if (purchase.is_draft) {
            var draftMeta = loadSalePrintMeta(purchase.id) || {};
            setSalePaidToggle(draftMeta.is_paid === true);
        } else if (!purchase.is_paid) {
            toggleUnpaidDueDateEdit(true);
        }
        populateItemRows(purchase.items || []);
    }

    function formatProfit(value) {
        var num = Number(value || 0);
        var formatted = InventoryApi.formatMoney(num);
        if (num > 0) return "+" + formatted;
        return formatted;
    }

    function sumSaleLineField(lines, field) {
        return roundMoney((lines || []).reduce(function (sum, line) {
            return sum + Number(line[field] || 0);
        }, 0));
    }

    function getSaleLineProfit(line, isDraft) {
        if (isDraft) return null;
        if (line.profit_amount != null && line.profit_amount !== "") {
            return roundMoney(line.profit_amount);
        }
        return roundMoney(Number(line.line_total || 0) - Number(line.cost_amount || 0));
    }

    function formatProfitLossValue(value, isDraft) {
        if (isDraft || value == null || value === "") {
            return "—";
        }
        return formatProfit(value);
    }

    function formatProfitLossCell(value, isDraft) {
        if (isDraft || value == null || value === "") {
            return '<td class="inv-mgmt-cell--num">—</td>';
        }
        var num = Number(value || 0);
        var cls = num >= 0 ? "inv-profit-positive" : "inv-profit-negative";
        return '<td class="inv-mgmt-cell--num ' + cls + '">' + formatProfit(num) + "</td>";
    }

    function formatSaleCostCell(value, isDraft) {
        if (isDraft) {
            return '<td class="inv-mgmt-cell--num">—</td>';
        }
        return '<td class="inv-mgmt-cell--num">' + InventoryApi.formatMoney(value) + "</td>";
    }

    function isDraftFlow() {
        return !!editingPurchaseIsDraft;
    }

    function getSaleRowStatusClass(purchase) {
        if (!purchase) return "";
        if (purchase.is_cancelled) return "inv-sale-row--cancelled";
        if (purchase.is_draft) return "inv-sale-row--draft";
        if (purchase.is_paid || purchase.payment_status === "paid") return "inv-sale-row--paid";
        if (purchase.payment_status === "partial") return "inv-sale-row--partial";
        return "inv-sale-row--pending";
    }

    function formatSaleStatusBadge(purchase) {
        if (!purchase) return "";
        if (purchase.is_cancelled) {
            return '<span class="inv-sale-status-badge inv-sale-status-badge--cancelled">Cancelled</span>';
        }
        if (purchase.is_draft) {
            return '<span class="inv-sale-status-badge inv-sale-status-badge--draft">Draft</span>';
        }
        if (purchase.is_paid || purchase.payment_status === "paid") {
            return '<span class="inv-sale-status-badge inv-sale-status-badge--paid">Paid</span>';
        }
        if (purchase.payment_status === "partial") {
            return '<span class="inv-sale-status-badge inv-sale-status-badge--partial">Partial</span>';
        }
        return '<span class="inv-sale-status-badge inv-sale-status-badge--pending">Pending</span>';
    }

    function formatPaymentStatusLabel(purchase) {
        if (!purchase || purchase.is_draft) return "—";
        if (purchase.is_cancelled) return "—";
        if (purchase.is_paid || purchase.payment_status === "paid") return "Paid";
        if (purchase.payment_status === "partial") return "Partially Paid";
        return "Unpaid";
    }

    function formatInvoiceNoCell(purchase) {
        var ref = displayValue(purchase.reference_no);
        var typeBadge = purchase.sale_type === "service"
            ? '<span class="inv-sale-status-badge inv-sale-status-badge--service">Service</span>'
            : "";
        var badge = formatSaleStatusBadge(purchase);
        var wrapBits = [typeBadge, badge].filter(Boolean).join(" ");
        if (!wrapBits) return ref;
        return ref + ' <span class="inv-sale-status-wrap">' + wrapBits + "</span>";
    }

    function displayValue(value) {
        if (value === null || value === undefined || String(value).trim() === "") return "—";
        return InventoryApi.escapeHtml(String(value));
    }

    function getPendingBillAmount(purchase) {
        if (purchase && purchase.is_draft) return 0;
        if (purchase && purchase.pending_bill != null) {
            return Number(purchase.pending_bill) || 0;
        }
        if (!purchase || purchase.is_cancelled || purchase.is_paid) return 0;
        return Number(purchase.total_amount) || 0;
    }

    function getPendingBillToneClass(amount) {
        return Number(amount) > 0 ? "inv-pending-bill--due" : "inv-pending-bill--clear";
    }

    function formatPendingBillCell(purchase) {
        var amount = getPendingBillAmount(purchase);
        return (
            '<td class="inv-mgmt-cell--num">' +
            '<span class="' + getPendingBillToneClass(amount) + '">' +
            InventoryApi.formatMoney(amount) +
            "</span></td>"
        );
    }

    function formatPendingBillValue(purchase) {
        var amount = getPendingBillAmount(purchase);
        return (
            '<span class="' + getPendingBillToneClass(amount) + '">' +
            InventoryApi.formatMoney(amount) +
            "</span>"
        );
    }

    function actionSlot() {
        return '<span class="inv-row-action-btn inv-row-action-btn--slot" aria-hidden="true"></span>';
    }

    function actionButtons(purchase) {
        var isCancelled = !!purchase.is_cancelled;
        var isDraft = !!purchase.is_draft;
        var saleType = purchase.sale_type === "service" ? "service" : "product";
        var typeAttr = ' data-sale-type="' + saleType + '"';

        var editBtn = isCancelled
            ? actionSlot()
            : isDraft
                ? (
                    '<button type="button" class="inv-row-action-btn inv-row-action-btn--finalize inv-purchase-edit" data-id="' + purchase.id + '"' + typeAttr + ' title="Finalize sale" aria-label="Finalize sale">' +
                    '<span class="material-symbols-outlined">task_alt</span></button>'
                )
                : (
            '<button type="button" class="inv-row-action-btn inv-row-action-btn--edit inv-purchase-edit" data-id="' + purchase.id + '"' + typeAttr + ' title="Edit" aria-label="Edit sale">' +
                    '<span class="material-symbols-outlined">edit</span></button>'
                );

        var paidBtn = (isCancelled || isDraft)
            ? actionSlot()
            : purchase.is_paid
                ? (
                    '<button type="button" class="inv-row-action-btn inv-row-action-btn--paid" disabled ' +
                    'title="Paid" aria-label="Paid">' +
                    '<span class="material-symbols-outlined">account_balance_wallet</span></button>'
                )
                : (
                    '<button type="button" class="inv-row-action-btn inv-row-action-btn--mark-paid inv-purchase-add-payment" ' +
                    'data-id="' + purchase.id + '"' + typeAttr + ' title="Add payment" aria-label="Add payment">' +
                    '<span class="material-symbols-outlined">payments</span></button>'
                );

        var historyBtn = isDraft
            ? actionSlot()
            : (
                '<button type="button" class="inv-row-action-btn inv-row-action-btn--history inv-purchase-invoice-history" ' +
                'data-id="' + purchase.id + '"' + typeAttr + ' title="Invoice history" aria-label="Invoice history">' +
                '<span class="material-symbols-outlined">history</span></button>'
            );

        var cancelBtnLabel = isDraft ? "Delete draft" : "Delete sale";

        var cancelBtn = isCancelled
            ? (
                '<button type="button" class="inv-row-action-btn inv-row-action-btn--cancelled" disabled ' +
                'title="Cancelled" aria-label="Cancelled">' +
                '<span class="material-symbols-outlined">cancel</span></button>'
            )
            : (
                '<button type="button" class="inv-row-action-btn inv-row-action-btn--mark-cancelled inv-purchase-mark-cancelled" ' +
                'data-id="' + purchase.id + '"' + typeAttr + ' title="' + cancelBtnLabel + '" aria-label="' + cancelBtnLabel + '">' +
                '<span class="material-symbols-outlined">highlight_off</span></button>'
            );

        var viewBtn =
            '<button type="button" class="inv-row-action-btn inv-row-action-btn--view inv-purchase-view" data-id="' + purchase.id + '"' + typeAttr + ' title="View" aria-label="View sale">' +
            '<span class="material-symbols-outlined">visibility</span></button>';

        var printBtn =
            '<button type="button" class="inv-row-action-btn inv-row-action-btn--print inv-purchase-print" data-id="' + purchase.id + '"' + typeAttr + ' title="Print" aria-label="Print sale">' +
            '<span class="material-symbols-outlined">print</span></button>';

        var sendPdfBtn =
            '<button type="button" class="inv-row-action-btn inv-row-action-btn--print inv-purchase-send-pdf" data-id="' + purchase.id + '"' + typeAttr + ' title="Send sale invoice PDF" aria-label="Send sale invoice PDF">' +
            '<span class="material-symbols-outlined">picture_as_pdf</span></button>';

        return (
            '<div class="inv-row-actions inv-row-actions--stacked">' +
                '<div class="inv-row-actions-row">' +
                    viewBtn + editBtn + paidBtn +
                "</div>" +
                '<div class="inv-row-actions-row">' +
                    cancelBtn + historyBtn + printBtn + sendPdfBtn +
                "</div>" +
            "</div>"
        );
    }


    function getLastPaymentDate(purchase) {
        var payments = (purchase && purchase.payments) || [];
        var last = "";
        payments.forEach(function (payment) {
            var dateValue = InventoryApi.toInputDateValue(payment.payment_date);
            if (dateValue && (!last || dateValue > last)) {
                last = dateValue;
            }
        });
        return last;
    }

    function getMinPaymentDate(purchase) {
        var lastPaymentDate = getLastPaymentDate(purchase);
        if (lastPaymentDate) return lastPaymentDate;
        return InventoryApi.toInputDateValue(
            purchase && (purchase.purchase_date || purchase.sale_date)
        ) || "";
    }

    function syncAddPaymentNextDueMin() {
        var dateEl = document.getElementById("purchase-add-payment-date");
        var dueEl = document.getElementById("purchase-add-payment-next-due");
        if (!dateEl || !dueEl) return;

        var paymentDate = InventoryApi.getDateInputValue(dateEl);
        if (!paymentDate) return;

        InventoryApi.setDateInputMin(dueEl, paymentDate);
        var dueDate = InventoryApi.getDateInputValue(dueEl);
        if (dueDate && dueDate < paymentDate) {
            InventoryApi.setDateInputValue(dueEl, paymentDate);
        }
    }

    function syncAddPaymentDueField(pendingAmount) {
        var amountEl = document.getElementById("purchase-add-payment-amount");
        var dueWrap = document.getElementById("purchase-add-payment-next-due-wrap");
        var dueEl = document.getElementById("purchase-add-payment-next-due");
        var dateEl = document.getElementById("purchase-add-payment-date");
        if (!amountEl || !dueWrap) return;

        var amount = Number(amountEl.value) || 0;
        var showDue = amount > 0 && amount + 0.0001 < pendingAmount;
        dueWrap.classList.toggle("inv-hidden", !showDue);
        if (!showDue && dueEl) {
            InventoryApi.setDateInputValue(dueEl, "");
            return;
        }
        syncAddPaymentNextDueMin();
        if (showDue && dueEl && !InventoryApi.getDateInputValue(dueEl)) {
            var paymentDate = dateEl ? InventoryApi.getDateInputValue(dateEl) : "";
            InventoryApi.setDateInputValue(
                dueEl,
                paymentDate || (window.InventoryDateInput ? InventoryDateInput.getMin(dueEl) : "") || ""
            );
        }
    }

    function populateAddPaymentModal(purchase) {
        purchase = purchase || {};
        addPaymentPurchaseId = purchase.id || null;
        var pending = getPendingBillAmount(purchase);
        addPaymentPendingAmount = pending;
        var totalPaid = Number(purchase.total_paid) || 0;

        document.getElementById("purchase-add-payment-bill").textContent = InventoryApi.formatMoney(purchase.total_amount);
        document.getElementById("purchase-add-payment-paid").textContent = InventoryApi.formatMoney(totalPaid);
        document.getElementById("purchase-add-payment-pending").textContent = InventoryApi.formatMoney(pending);

        var amountEl = document.getElementById("purchase-add-payment-amount");
        var dateEl = document.getElementById("purchase-add-payment-date");
        var notesEl = document.getElementById("purchase-add-payment-notes");
        var dueEl = document.getElementById("purchase-add-payment-next-due");
        if (amountEl) {
            amountEl.value = pending > 0 ? pending.toFixed(2) : "";
            amountEl.max = pending > 0 ? pending.toFixed(2) : "";
        }
        var today = new Date().toISOString().slice(0, 10);
        var minPaymentDate = getMinPaymentDate(purchase);
        addPaymentMinDate = minPaymentDate;
        var defaultPaymentDate = today;
        if (minPaymentDate && defaultPaymentDate < minPaymentDate) {
            defaultPaymentDate = minPaymentDate;
        }
        if (dateEl) {
            InventoryApi.setDateInputMin(dateEl, minPaymentDate || "");
            InventoryApi.setDateInputValue(dateEl, defaultPaymentDate);
        }
        if (notesEl) notesEl.value = "";
        if (dueEl) {
            var paymentDate = dateEl ? InventoryApi.getDateInputValue(dateEl) : defaultPaymentDate;
            var existingDue = purchase.due_date || "";
            InventoryApi.setDateInputMin(dueEl, paymentDate);
            InventoryApi.setDateInputValue(
                dueEl,
                existingDue && existingDue >= paymentDate ? existingDue : paymentDate
            );
        }

        fillPaymentTypeSelect(
            document.getElementById("purchase-add-payment-type"),
            purchase.payment_type || ""
        );
        syncAddPaymentDueField(pending);
    }

    function openAddPaymentModal(id, saleType) {
        if (!id) return;
        saleType = resolveSaleType(saleType, id);
        InventoryLoader.show();
        fetchSale(id, saleType)
            .then(function (purchase) {
                if (!purchase) return;
                if (purchase.is_draft) {
                    InventoryToast.error("Draft sales must be finalized before recording payments.");
                    return;
                }
                if (purchase.is_cancelled) {
                    InventoryToast.error("Cancelled invoices cannot receive payments.");
                    return;
                }
                if (purchase.is_paid || getPendingBillAmount(purchase) <= 0) {
                    InventoryToast.info("This invoice is already fully paid.");
                    return;
                }
                addPaymentSaleType = saleType;
                return loadPaymentTypes(purchase.payment_type || "").then(function () {
                    populateAddPaymentModal(purchase);
                    InventoryModal.open("purchase-add-payment-modal");
                    var typeSelect = document.getElementById("purchase-add-payment-type");
                    if (window.InventorySearchableSelect && typeSelect) {
                        InventorySearchableSelect.rebuild(typeSelect);
                    }
                    var amountEl = document.getElementById("purchase-add-payment-amount");
                    if (amountEl) amountEl.focus();
                });
            })
            .catch(function () {
                InventoryToast.error("Network error while loading sale.");
            })
            .finally(function () {
                InventoryLoader.hide();
            });
    }

    function submitAddPayment() {
        if (!addPaymentPurchaseId) return;

        var amountEl = document.getElementById("purchase-add-payment-amount");
        var dateEl = document.getElementById("purchase-add-payment-date");
        var typeEl = document.getElementById("purchase-add-payment-type");
        var dueEl = document.getElementById("purchase-add-payment-next-due");
        var notesEl = document.getElementById("purchase-add-payment-notes");
        var amount = Number(amountEl && amountEl.value);
        var pending = addPaymentPendingAmount;
        if (!Number.isFinite(amount) || amount <= 0) {
            InventoryToast.error("Please enter a valid payment amount.");
            if (amountEl) amountEl.focus();
            return;
        }
        if (amount > pending + 0.0001) {
            InventoryToast.error("Payment amount cannot exceed the pending bill.");
            if (amountEl) amountEl.focus();
            return;
        }

        var paymentDate = dateEl ? InventoryApi.getDateInputValue(dateEl) : "";
        if (!paymentDate) {
            InventoryToast.error("Please select a payment date.");
            if (dateEl) dateEl.focus();
            return;
        }
        if (addPaymentMinDate && paymentDate < addPaymentMinDate) {
            InventoryToast.error("Payment date cannot be before the last recorded payment date.");
            if (dateEl) dateEl.focus();
            return;
        }

        var payload = {
            amount: amount,
            payment_date: paymentDate,
            notes: notesEl ? notesEl.value.trim() : ""
        };
        if (typeEl && typeEl.value) payload.payment_type_id = Number(typeEl.value);

        var clearsBill = amount + 0.0001 >= pending;
        if (!clearsBill) {
            var nextDue = dueEl ? InventoryApi.getDateInputValue(dueEl) : "";
            if (!nextDue) {
                InventoryToast.error("Please enter the next due date for the remaining balance.");
                if (dueEl) dueEl.focus();
                return;
            }
            if (nextDue < paymentDate) {
                InventoryToast.error("Next due date cannot be before the payment date.");
                if (dueEl) dueEl.focus();
                return;
            }
            payload.next_due_date = nextDue;
        }

        var btn = document.getElementById("purchase-add-payment-save-btn");
        InventoryLoader.button(btn, true, "Saving...");
        request(saleActionPath(addPaymentPurchaseId, addPaymentSaleType, "payments"), {
            method: "POST",
            body: payload
        })
            .then(function (body) {
                if (body && body.isSuccess) {
                    InventoryToast.success(body.message || "Payment recorded successfully.");
                    InventoryModal.close("purchase-add-payment-modal");
                    addPaymentPurchaseId = null;
                    loadPurchases(currentPage);
                    if (viewingPurchaseId && String(viewingPurchaseId) === String(body.data && body.data.id)) {
                        viewingPurchase = body.data;
                        if (isServiceSaleType(addPaymentSaleType) || body.data.sale_type === "service") {
                            renderServiceViewDetails(body.data);
                        } else {
                            renderViewDetails(body.data);
                        }
                        updateViewPanelActions(body.data);
                    }
                } else {
                    var err = body.message || "Unable to record payment.";
                    if (body.errors && body.errors.length) err = body.errors.join(" • ");
                    InventoryToast.error(err);
                }
            })
            .catch(function () {
                InventoryToast.error("Network error. Please try again.");
            })
            .finally(function () {
                InventoryLoader.button(btn, false);
            });
    }

    function renderPaymentHistorySummary(purchase) {
        var wrap = document.getElementById("purchase-payment-history-summary");
        if (!wrap) return;
        wrap.innerHTML =
            '<div class="inv-sale-payment-summary-row">' +
                "<span>Invoice</span><strong>" + displayValue(purchase.reference_no) + "</strong>" +
            "</div>" +
            '<div class="inv-sale-payment-summary-row">' +
                "<span>Bill Amount</span><strong>" + InventoryApi.formatMoney(purchase.total_amount) + "</strong>" +
            "</div>" +
            '<div class="inv-sale-payment-summary-row">' +
                "<span>Total Paid</span><strong>" + InventoryApi.formatMoney(purchase.total_paid) + "</strong>" +
            "</div>" +
            '<div class="inv-sale-payment-summary-row inv-sale-payment-summary-row--pending">' +
                "<span>Pending Bill</span><strong>" + InventoryApi.formatMoney(getPendingBillAmount(purchase)) + "</strong>" +
            "</div>";
    }

    function renderPaymentHistoryRows(payments) {
        var tbody = document.getElementById("purchase-payment-history-body");
        if (!tbody) return;

        if (!payments || !payments.length) {
            tbody.innerHTML = '<tr><td colspan="5" class="inv-mgmt-empty">No payments recorded yet.</td></tr>';
            return;
        }

        tbody.innerHTML = payments.map(function (payment) {
            return (
                "<tr>" +
                "<td>" + displayValue(formatViewDateValue(payment.payment_date)) + "</td>" +
                '<td class="inv-mgmt-cell--num">' + InventoryApi.formatMoney(payment.amount) + "</td>" +
                "<td>" + displayValue(payment.payment_type_name) + "</td>" +
                "<td>" + displayValue(formatViewDateValue(payment.next_due_date)) + "</td>" +
                "<td>" + displayValue(payment.notes) + "</td>" +
                "</tr>"
            );
        }).join("");
    }

    function openPaymentHistoryModal(id, saleType) {
        if (!id) return;
        saleType = resolveSaleType(saleType, id);
        InventoryLoader.show();
        fetchSale(id, saleType)
            .then(function (purchase) {
                if (!purchase) return;
                if (purchase.is_draft) {
                    InventoryToast.error("Draft sales do not have payment history.");
                    return;
                }
                renderPaymentHistorySummary(purchase);
                renderPaymentHistoryRows(purchase.payments || []);
                var titleEl = document.getElementById("purchase-payment-history-title");
                if (titleEl) {
                    titleEl.textContent = "Invoice History — " + (purchase.reference_no || purchase.customer_name || "Sale");
                }
                InventoryModal.open("purchase-payment-history-modal");
            })
            .catch(function () {
                InventoryToast.error("Network error while loading payment history.");
            })
            .finally(function () {
                InventoryLoader.hide();
            });
    }

    function updateViewPanelActions(purchase) {
        var addBtn = document.getElementById("purchase-view-add-payment-btn");
        var historyBtn = document.getElementById("purchase-view-payment-history-btn");
        var showHistory = purchase && !purchase.is_draft;
        var showPaymentActions = purchase && !purchase.is_draft && !purchase.is_cancelled;
        if (historyBtn) historyBtn.classList.toggle("inv-hidden", !showHistory);
        if (addBtn) {
            var showAdd = showPaymentActions && !purchase.is_paid && getPendingBillAmount(purchase) > 0;
            addBtn.classList.toggle("inv-hidden", !showAdd);
        }
    }

    function findCachedPurchase(id) {
        for (var i = 0; i < cachedItems.length; i++) {
            if (String(cachedItems[i].id) === String(id)) return cachedItems[i];
        }
        return null;
    }

    function markPurchaseCancelled(id, saleType) {
        if (!id) return;
        saleType = resolveSaleType(saleType, id);
        var purchase = findCachedPurchase(id);
        var cancelPath = saleActionPath(id, saleType, "mark-cancelled");
        var isService = isServiceSaleType(saleType);

        if (purchase && purchase.is_draft) {
            InventoryConfirm.ask({
                title: "Delete draft sale?",
                message: "This draft will be removed and its invoice number will be released for reuse.",
                confirmText: "Delete Draft",
                cancelText: "Keep Draft",
                variant: "danger",
                icon: "delete"
            }).then(function (confirmed) {
                if (!confirmed) return;
                request(cancelPath, { method: "POST", body: {} })
                    .then(function (body) {
                        if (body && body.isSuccess) {
                            InventoryToast.success(body.message || "Draft sale deleted.");
                            loadPurchases(currentPage);
                        } else {
                            InventoryToast.error(body && body.message ? body.message : "Unable to delete draft sale.");
                        }
                    })
                    .catch(function () {
                        InventoryToast.error("Network error. Please try again.");
                    });
            });
            return;
        }

        var minDate = purchase && (purchase.purchase_date || purchase.sale_date)
            ? (purchase.purchase_date || purchase.sale_date)
            : "";
        InventoryConfirm.prompt({
            title: "Cancel this invoice?",
            message: isService
                ? "The service invoice will be marked as cancelled."
                : "The invoice will be marked as cancelled and stock sold on this invoice will be restored.",
            showDate: true,
            dateLabel: "Cancellation Date",
            dateRequired: true,
            minDate: minDate,
            dateErrorMessage: "Cancellation date cannot be before the invoice date.",
            inputLabel: "Cancellation Reason",
            inputPlaceholder: "Enter reason for cancelling this invoice",
            confirmText: "Cancel Invoice",
            cancelText: "Keep Invoice",
            variant: "danger",
            icon: "highlight_off",
            required: true
        }).then(function (result) {
            if (!result) return;
            var reason = result.reason || "";
            var cancellationDate = result.cancellation_date || "";
            if (!reason) return;
            request(cancelPath, {
                method: "POST",
                body: {
                    cancellation_reason: reason,
                    cancellation_date: cancellationDate
                }
            })
                .then(function (body) {
                    if (body && body.isSuccess) {
                        InventoryToast.success(body.message || "Invoice cancelled.");
                        loadPurchases(currentPage);
                    } else {
                        InventoryToast.error(body && body.message ? body.message : "Unable to cancel invoice.");
                    }
                })
                .catch(function () {
                    InventoryToast.error("Network error. Please try again.");
                });
        });
    }

    function formatProductsSoldCell(items, purchaseId, saleType) {
        if (!items || !items.length) return "—";

        var lines = items.map(function (item) {
            var name = item.product_name || item.service_name || "";
            if (saleType === "service") {
                return InventoryApi.escapeHtml(name);
            }
            return InventoryApi.escapeHtml(name) + " × " + formatQty(item.quantity);
        });

        if (lines.length <= 2) {
            return lines.join(" · ");
        }

        var short = lines.slice(0, 2).join(" · ");
        var full = lines.join(" · ");
        var moreCount = lines.length - 2;

        return (
            '<span class="inv-products-sold" data-purchase-id="' + purchaseId + '">' +
            '<span class="inv-products-sold-collapsed">' + short + " · " +
            '<button type="button" class="inv-products-sold-toggle">+' + moreCount + " more</button></span>" +
            '<span class="inv-products-sold-expanded inv-hidden">' + full + " · " +
            '<button type="button" class="inv-products-sold-toggle inv-products-sold-toggle--less">show less</button></span>' +
            "</span>"
        );
    }

    function renderPurchaseRows(items) {
        var tbody = document.getElementById("purchases-table-body");
        if (!tbody) return;

        var cols = getColumnCtrl();
        var colspan = cols.getColspan();

        if (!items || !items.length) {
            tbody.innerHTML = '<tr><td colspan="' + colspan + '" class="inv-mgmt-empty">No sales yet. Record a purchase first, then create a sale.</td></tr>';
            return;
        }

        cachedItems = items;

        tbody.innerHTML = items.map(function (purchase) {
            var rowClass = getSaleRowStatusClass(purchase);
            return (
                '<tr class="' + rowClass + '">' +
                cols.renderRowCells(purchase) +
                '<td class="inv-col-action inv-mgmt-cell--action">' + actionButtons(purchase) + "</td>" +
                "</tr>"
            );
        }).join("");

        if (window.InventoryTableCards) {
            var table = tbody.closest(".inv-mgmt-table");
            if (table) InventoryTableCards.syncTable(table);
        }
    }

    function fetchPurchase(id) {
        return request("/" + id + "/").then(function (body) {
            if (body && body.isSuccess && body.data) {
                return mergeSalePrintMeta(body.data);
            }
            InventoryToast.error(body.message || "Failed to load sale details.");
            return null;
        });
    }

    function formatViewDateValue(value) {
        return InventoryApi.formatDisplayDate(value, "");
    }

    function formatPaymentScheduleViewField(purchase) {
        purchase = mergeSalePrintMeta(purchase || {});

        if (purchase.is_paid) {
            return {
                label: "Payment Date",
                value: displayValue(InventoryApi.formatDateTime(purchase.paid_at, "—"))
            };
        }

        return {
            label: "Payment Due Date",
            value: displayValue(formatViewDateValue(purchase.due_date))
        };
    }

    function getPaymentPayloadForSave(isPaid) {
        var dueDateEl = document.getElementById("purchase-invoice-due-date");
        var payload = {
            is_paid: !!isPaid,
            due_date: isPaid ? null : (InventoryApi.getDateInputValue(dueDateEl) || null)
        };
        if (isPaidSegmentSelected()) {
            var paidAmount = getPaidAmountValue();
            if (paidAmount > 0) payload.payment_amount = paidAmount;
        }
        return payload;
    }

    function renderViewDetails(purchase) {
        purchase = mergeSalePrintMeta(purchase || {});
        var container = document.getElementById("purchase-view-body");
        var itemsWrap = document.getElementById("purchase-view-items-wrap");
        if (!container || !itemsWrap) return;

        var rows = [
            { label: "Sale Date", value: displayValue(InventoryApi.formatDisplayDate(purchase.purchase_date, "—")) },
            { label: "Invoice No.", value: displayValue(purchase.reference_no || "—") },
            { label: "Customer", value: formatCustomerDisplay(purchase) },
            formatPaymentScheduleViewField(purchase)
        ];

        var lines = purchase.items || [];
        var isDraft = !!purchase.is_draft;
        var totalTax = isDraft ? null : sumSaleLineField(lines, "tax_amount");
        var soldTotalWithTax = isDraft ? null : roundMoney(Number(purchase.total_amount || 0));
        var soldTotalWithoutTax = null;
        if (!isDraft && soldTotalWithTax != null) {
            soldTotalWithoutTax = roundMoney(Math.max(0, soldTotalWithTax - Number(totalTax || 0)));
        }
        var totalProfit = null;
        if (!isDraft) {
            if (purchase.total_profit != null && purchase.total_profit !== "") {
                totalProfit = roundMoney(purchase.total_profit);
        } else {
                totalProfit = roundMoney(Number(purchase.total_amount || 0) - Number(purchase.total_cost || 0));
            }
        }

        rows.push(
            { label: "Billing Address", value: displayValue(purchase.billing_address) },
            { label: "Shipping Address", value: displayValue(purchase.shipping_address) },
            { label: "Invoice Status", value: purchase.is_cancelled ? "Cancelled" : (purchase.is_draft ? "Draft" : "Active") },
            { label: "Payment Status", value: formatPaymentStatusLabel(purchase) },
            { label: "Payment Type", value: displayValue(purchase.payment_type_name) },
            { label: "Bill Amount", value: InventoryApi.formatMoney(purchase.total_amount), colStart: 1, num: true, emphasis: true },
            { label: "Total Paid", value: InventoryApi.formatMoney(purchase.total_paid), num: true },
            { label: "Pending Bill", value: formatPendingBillValue(purchase), num: true },
            {
                label: "Total Cost without Tax",
                value: isDraft ? "—" : InventoryApi.formatMoney(soldTotalWithoutTax),
                num: true
            },
            { label: "Total Tax", value: isDraft ? "—" : InventoryApi.formatMoney(totalTax), num: true },
            {
                label: "Total Cost with Tax",
                value: isDraft ? "—" : InventoryApi.formatMoney(soldTotalWithTax),
                num: true
            },
            {
                label: "Total Profit / Loss",
                value: (function () {
                    if (isDraft || totalProfit == null) return "—";
                    var cls = Number(totalProfit) >= 0 ? "inv-profit-positive" : "inv-profit-negative";
                    return '<span class="' + cls + '">' + formatProfit(totalProfit) + "</span>";
                })(),
                num: true
            }
        );
        if (purchase.is_cancelled) {
            var cancelDate = purchase.cancellation_date || purchase.cancelled_at;
            rows.push({
                label: "Cancellation Date",
                value: displayValue(InventoryApi.formatDisplayDate(cancelDate, "—"))
            });
            rows.push({
                label: "Cancellation Reason",
                value: displayValue(purchase.cancellation_reason),
                full: true
            });
        }
        if (purchase.notes) {
            rows.push({ label: "Notes", value: displayValue(purchase.notes), full: true });
        }

        container.innerHTML = InventoryApi.renderViewGrid(rows);

        if (!lines.length) {
            itemsWrap.innerHTML = "";
            return;
        }

        var draftNote = isDraft
            ? '<p class="inv-mgmt-items-help">Cost and profit/loss are calculated when the sale is finalized.</p>'
            : "";

        itemsWrap.innerHTML =
            '<h4 class="inv-stockin-view-items-title">Products Sold</h4>' +
            draftNote +
            '<div class="inv-mgmt-table-wrap inv-sale-view-table-wrap">' +
            '<table class="inv-mgmt-table inv-sale-view-table">' +
            "<colgroup>" +
            '<col class="inv-sale-col-product"/>' +
            '<col class="inv-sale-col-sku"/>' +
            '<col class="inv-sale-col-unit"/>' +
            '<col class="inv-sale-col-qty"/>' +
            '<col class="inv-sale-col-money"/>' +
            '<col class="inv-sale-col-money"/>' +
            '<col class="inv-sale-col-money"/>' +
            '<col class="inv-sale-col-money"/>' +
            '<col class="inv-sale-col-money"/>' +
            '<col class="inv-sale-col-money"/>' +
            "</colgroup>" +
            "<thead><tr>" +
            "<th>Product</th>" +
            "<th>SKU</th>" +
            "<th>Unit</th>" +
            "<th class=\"inv-mgmt-cell--num\">Qty</th>" +
            "<th class=\"inv-mgmt-cell--num\">MRP</th>" +
            "<th class=\"inv-mgmt-cell--num\">Sale Price</th>" +
            "<th class=\"inv-mgmt-cell--num\">Tax</th>" +
            "<th class=\"inv-mgmt-cell--num\">Sold Total</th>" +
            "<th class=\"inv-mgmt-cell--num\">Cost (incl. tax)</th>" +
            "<th class=\"inv-mgmt-cell--num\">Profit / Loss</th>" +
            "</tr></thead><tbody>" +
            lines.map(function (line) {
                var mrp = line.list_price != null && line.list_price !== ""
                    ? line.list_price
                    : line.unit_price;
                var lineProfit = getSaleLineProfit(line, isDraft);
                return (
                    "<tr>" +
                    "<td>" + displayValue(line.product_name) + "</td>" +
                    "<td>" + displayValue(line.product_sku) + "</td>" +
                    "<td>" + displayValue(line.product_unit || "pcs") + "</td>" +
                    "<td class=\"inv-mgmt-cell--num\">" + displayValue(formatQty(line.quantity)) + "</td>" +
                    "<td class=\"inv-mgmt-cell--num\">" + InventoryApi.formatMoney(mrp) + "</td>" +
                    "<td class=\"inv-mgmt-cell--num\">" + InventoryApi.formatMoney(line.unit_price) + "</td>" +
                    "<td class=\"inv-mgmt-cell--num\">" + (isDraft ? "—" : InventoryApi.formatMoney(line.tax_amount)) + "</td>" +
                    "<td class=\"inv-mgmt-cell--num\">" + InventoryApi.formatMoney(line.line_total) + "</td>" +
                    formatSaleCostCell(line.cost_amount, isDraft) +
                    formatProfitLossCell(lineProfit, isDraft) +
                    "</tr>"
                );
            }).join("") +
            "</tbody><tfoot><tr class=\"inv-sale-view-total-row\">" +
            "<td colspan=\"6\" class=\"inv-sale-view-total-label\"><strong>Invoice Totals</strong></td>" +
            "<td class=\"inv-mgmt-cell--num\">" + (isDraft ? "—" : InventoryApi.formatMoney(totalTax)) + "</td>" +
            "<td class=\"inv-mgmt-cell--num\">" + InventoryApi.formatMoney(purchase.total_amount) + "</td>" +
            "<td class=\"inv-mgmt-cell--num\">" + (isDraft ? "—" : InventoryApi.formatMoney(purchase.total_cost)) + "</td>" +
            (function () {
                if (isDraft) {
                    return '<td class="inv-mgmt-cell--num">—</td>';
                }
                var cls = Number(totalProfit) >= 0 ? "inv-profit-positive" : "inv-profit-negative";
                return '<td class="inv-mgmt-cell--num ' + cls + '">' + formatProfit(totalProfit) + "</td>";
            })() +
            "</tr></tfoot></table></div>";
    }

    function openEditPurchase(id) {
        InventoryLoader.show();
        fetchPurchase(id)
            .then(function (purchase) {
                if (!purchase) return;
                if (purchase.is_cancelled) {
                    InventoryToast.error("Cancelled invoices cannot be edited.");
                    return;
                }
                editingPurchaseId = purchase.id;
                editingPurchaseIsDraft = !!purchase.is_draft;
                setEditingSaleStockFromPurchase(purchase);
                setFormMode(purchase.is_draft ? "draft" : "edit", { kind: "product" });
                return Promise.all([
                    loadProducts({
                        includeAll: purchase.is_draft,
                        includeProductIds: getIncludedEditProductIds()
                    }),
                    loadTaxes(),
                    purchase.is_draft ? loadInvoiceSettings("") : Promise.resolve()
                ]).then(function () {
                populateForm(purchase);
                InventoryPagePanel.showPanel(PURCHASES_LIST_PANEL, PURCHASES_FORM_PANEL);
                document.getElementById("purchase-customer").focus();
                });
            })
            .catch(function () {
                InventoryToast.error("Network error while loading sale.");
            })
            .finally(function () {
                InventoryLoader.hide();
            });
    }

    function openEditServiceSale(id) {
        InventoryLoader.show();
        fetchServiceSale(id)
            .then(function (sale) {
                if (!sale) return;
                if (sale.is_cancelled) {
                    InventoryToast.error("Cancelled invoices cannot be edited.");
                    return;
                }
                editingPurchaseId = sale.id;
                editingPurchaseIsDraft = !!sale.is_draft;
                editingSaleStockByProduct = {};
                setFormMode(sale.is_draft ? "draft" : "edit", { kind: "service" });
                return Promise.all([
                    loadServices(),
                    loadTaxes(),
                    loadCustomers(sale.customer || sale.customer_id || ""),
                    loadPaymentTypes(sale.payment_type || ""),
                    sale.is_draft ? loadInvoiceSettings("") : Promise.resolve()
                ]).then(function () {
                    populateServiceForm(sale);
                    InventoryPagePanel.showPanel(PURCHASES_LIST_PANEL, PURCHASES_FORM_PANEL);
                    document.getElementById("purchase-customer").focus();
                });
            })
            .catch(function () {
                InventoryToast.error("Network error while loading service sale.");
            })
            .finally(function () {
                InventoryLoader.hide();
            });
    }

    function openViewPurchase(id) {
        InventoryLoader.show();
        fetchPurchase(id)
            .then(function (purchase) {
                if (!purchase) return;
                viewingPurchaseId = purchase.id;
                viewingPurchase = purchase;
                var titleEl = document.getElementById("purchase-view-title");
                if (titleEl) {
                    titleEl.textContent = purchase.customer_name || "Sale Details";
                }
                renderViewDetails(purchase);
                updateViewPanelActions(purchase);
                InventoryPagePanel.showPanel(PURCHASES_LIST_PANEL, PURCHASES_VIEW_PANEL);
            })
            .catch(function () {
                InventoryToast.error("Network error while loading sale.");
            })
            .finally(function () {
                InventoryLoader.hide();
            });
    }

    function fetchServiceSale(id) {
        return request("/service-sales/" + id + "/").then(function (body) {
            if (body && body.isSuccess && body.data) {
                return mergeSalePrintMeta(body.data);
            }
            InventoryToast.error(body.message || "Failed to load service sale details.");
            return null;
        });
    }

    function renderServiceViewDetails(sale) {
        sale = mergeSalePrintMeta(sale || {});
        var container = document.getElementById("purchase-view-body");
        var itemsWrap = document.getElementById("purchase-view-items-wrap");
        if (!container || !itemsWrap) return;

        var rows = [
            { label: "Sale Date", value: displayValue(InventoryApi.formatDisplayDate(sale.sale_date || sale.purchase_date, "—")) },
            { label: "Invoice No.", value: displayValue(sale.reference_no || "—") },
            { label: "Type", value: "Service" },
            { label: "Customer", value: formatCustomerDisplay(sale) },
            formatPaymentScheduleViewField(sale),
            { label: "Invoice Status", value: sale.is_cancelled ? "Cancelled" : (sale.is_draft ? "Draft" : "Active") },
            { label: "Payment Status", value: formatPaymentStatusLabel(sale) },
            { label: "Payment Type", value: displayValue(sale.payment_type_name) },
            { label: "Bill Amount", value: InventoryApi.formatMoney(sale.total_amount), colStart: 1, num: true, emphasis: true },
            { label: "Total Paid", value: InventoryApi.formatMoney(sale.total_paid), num: true },
            { label: "Pending Bill", value: formatPendingBillValue(sale), num: true }
        ];
        if (sale.terms) {
            rows.push({ label: "Terms", value: displayValue(sale.terms), full: true });
        }
        if (sale.notes) {
            rows.push({ label: "Notes", value: displayValue(sale.notes), full: true });
        }
        container.innerHTML = InventoryApi.renderViewGrid(rows);

        var lines = sale.items || [];
        if (!lines.length) {
            itemsWrap.innerHTML = "";
            return;
        }

        var totalTax = lines.reduce(function (sum, line) {
            return sum + (Number(line.tax_amount) || 0);
        }, 0);

        itemsWrap.innerHTML =
            '<h4 class="inv-stockin-view-items-title">Services Sold</h4>' +
            '<div class="inv-mgmt-table-wrap inv-sale-view-table-wrap">' +
            '<table class="inv-mgmt-table inv-sale-view-table">' +
            "<thead><tr>" +
            "<th>Service</th>" +
            "<th class=\"inv-mgmt-cell--num\">Base Price</th>" +
            "<th class=\"inv-mgmt-cell--num\">GST %</th>" +
            "<th class=\"inv-mgmt-cell--num\">Tax</th>" +
            "<th class=\"inv-mgmt-cell--num\">Line Total</th>" +
            "</tr></thead><tbody>" +
            lines.map(function (line) {
                return (
                    "<tr>" +
                    "<td>" + displayValue(line.service_name) + "</td>" +
                    "<td class=\"inv-mgmt-cell--num\">" + InventoryApi.formatMoney(line.base_price) + "</td>" +
                    "<td class=\"inv-mgmt-cell--num\">" + displayValue(line.gst_rate != null ? line.gst_rate : "—") + "</td>" +
                    "<td class=\"inv-mgmt-cell--num\">" + InventoryApi.formatMoney(line.tax_amount) + "</td>" +
                    "<td class=\"inv-mgmt-cell--num\">" + InventoryApi.formatMoney(line.line_total) + "</td>" +
                    "</tr>"
                );
            }).join("") +
            "</tbody><tfoot><tr class=\"inv-sale-view-total-row\">" +
            "<td colspan=\"3\" class=\"inv-sale-view-total-label\"><strong>Invoice Totals</strong></td>" +
            "<td class=\"inv-mgmt-cell--num\">" + InventoryApi.formatMoney(totalTax) + "</td>" +
            "<td class=\"inv-mgmt-cell--num\">" + InventoryApi.formatMoney(sale.total_amount) + "</td>" +
            "</tr></tfoot></table></div>";
    }

    function openViewServiceSale(id) {
        InventoryLoader.show();
        fetchServiceSale(id)
            .then(function (sale) {
                if (!sale) return;
                viewingPurchaseId = sale.id;
                viewingPurchase = sale;
                var titleEl = document.getElementById("purchase-view-title");
                if (titleEl) {
                    titleEl.textContent = sale.customer_name || "Service Sale Details";
                }
                renderServiceViewDetails(sale);
                updateViewPanelActions(sale);
                InventoryPagePanel.showPanel(PURCHASES_LIST_PANEL, PURCHASES_VIEW_PANEL);
            })
            .catch(function () {
                InventoryToast.error("Network error while loading service sale.");
            })
            .finally(function () {
                InventoryLoader.hide();
            });
    }

    function buildQuery(page) {
        var params = new URLSearchParams();
        params.set("page", String(page || 1));
        params.set("page_size", String(InventoryPagination.getPageSize("purchases-pagination")));

        var searchEl = document.getElementById("purchases-search");
        var saleTypeFilterEl = document.getElementById("purchases-sale-type-filter");
        var invoiceStatusFilterEl = document.getElementById("purchases-invoice-status-filter");
        var dateFromEl = document.getElementById("purchases-date-from");
        var dateToEl = document.getElementById("purchases-date-to");
        if (searchEl && searchEl.value.trim()) {
            params.set("search", searchEl.value.trim());
        }
        if (saleTypeFilterEl && saleTypeFilterEl.value) {
            params.set("sale_type", saleTypeFilterEl.value);
        }
        if (invoiceStatusFilterEl && invoiceStatusFilterEl.value) {
            params.set("invoice_status", invoiceStatusFilterEl.value);
        }
        if (dateFromEl && InventoryApi.getDateInputValue(dateFromEl)) {
            params.set("date_from", InventoryApi.getDateInputValue(dateFromEl));
        }
        if (dateToEl && InventoryApi.getDateInputValue(dateToEl)) {
            params.set("date_to", InventoryApi.getDateInputValue(dateToEl));
        }
        if (currentOrdering) {
            params.set("ordering", currentOrdering);
        }

        return "?" + params.toString();
    }

    function clearFilters() {
        var searchEl = document.getElementById("purchases-search");
        var saleTypeFilterEl = document.getElementById("purchases-sale-type-filter");
        var invoiceStatusFilterEl = document.getElementById("purchases-invoice-status-filter");
        var dateFromEl = document.getElementById("purchases-date-from");
        var dateToEl = document.getElementById("purchases-date-to");
        if (searchEl) searchEl.value = "";
        if (saleTypeFilterEl) saleTypeFilterEl.value = "";
        if (invoiceStatusFilterEl) invoiceStatusFilterEl.value = "";
        if (dateFromEl) InventoryApi.setDateInputValue(dateFromEl, "");
        if (dateToEl) InventoryApi.setDateInputValue(dateToEl, "");
        loadPurchases(1);
    }

    function applyFiltersFromUrl() {
        var params = new URLSearchParams(window.location.search);
        var invoiceStatus = params.get("invoice_status");
        var dateFrom = params.get("date_from");
        var dateTo = params.get("date_to");
        var period = params.get("period");
        var dateFromEl = document.getElementById("purchases-date-from");
        var dateToEl = document.getElementById("purchases-date-to");

        if (invoiceStatus) {
            var normalized = invoiceStatus.toLowerCase();
            var allowed = { finalized: true, paid: true, pending: true, draft: true, cancelled: true };
            if (allowed[normalized]) {
                var invoiceStatusFilterEl = document.getElementById("purchases-invoice-status-filter");
                if (invoiceStatusFilterEl) {
                    invoiceStatusFilterEl.value = normalized;
                }
            }
        }

        if (dateFrom && dateTo) {
            if (dateFromEl) InventoryApi.setDateInputValue(dateFromEl, dateFrom);
            if (dateToEl) InventoryApi.setDateInputValue(dateToEl, dateTo);
        } else if (period && window.InventoryDashboardPeriod) {
            InventoryDashboardPeriod.applyDateRangeInputs(dateFromEl, dateToEl, period);
        }
    }

    function addDaysToIsoDate(isoDate, days) {
        if (!isoDate) return "";
        var parts = isoDate.split("-");
        if (parts.length !== 3) return "";
        var dt = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
        dt.setDate(dt.getDate() + (Number(days) || 0));
        var y = dt.getFullYear();
        var m = String(dt.getMonth() + 1).padStart(2, "0");
        var d = String(dt.getDate()).padStart(2, "0");
        return y + "-" + m + "-" + d;
    }

    function loadSaleDueSetting() {
        return request("/due-settings/")
            .then(function (body) {
                if (body && body.isSuccess && body.data) {
                    saleDueDefaultDays = body.data.default_due_days_after_sale != null
                        ? Number(body.data.default_due_days_after_sale)
                        : 7;
                }
            })
            .catch(function () {
                /* Non-blocking: sale list still works with default days. */
            });
    }

    function applyDefaultDueDateToForm() {
        if (editingPurchaseId) return;
        if (!shouldShowDueDateField()) return;
        var saleDateEl = document.getElementById("purchase-date");
        var dueDateEl = document.getElementById("purchase-invoice-due-date");
        if (!saleDateEl || !dueDateEl) return;
        var saleDate = InventoryApi.getDateInputValue(saleDateEl);
        if (!saleDate) return;
        InventoryApi.setDateInputValue(dueDateEl, addDaysToIsoDate(saleDate, saleDueDefaultDays));
    }

    function fillDueSettingModal(data) {
        var input = document.getElementById("purchase-default-due-days");
        if (input) {
            input.value = data && data.default_due_days_after_sale != null
                ? data.default_due_days_after_sale
                : 7;
        }
    }

    function openDueSettingModal() {
        if (!InventoryBusiness.getActiveId()) {
            InventoryToast.error("Select or create a business first.");
            return;
        }
        request("/due-settings/")
            .then(function (body) {
                if (!body || !body.isSuccess) {
                    InventoryToast.error((body && body.message) || "Failed to load due date settings.");
                    return;
                }
                fillDueSettingModal(body.data || {});
                if (window.InventoryModal) {
                    InventoryModal.open("purchase-due-setting-modal");
                }
            })
            .catch(function () {
                InventoryToast.error("Network error. Please try again.");
            });
    }

    function saveDueSetting() {
        var btn = document.getElementById("purchase-due-setting-save-btn");
        var input = document.getElementById("purchase-default-due-days");
        if (!input) return;
        var days = Number(input.value);
        if (!days || days < 1) {
            InventoryToast.error("Default due days must be at least 1.");
            input.focus();
            return;
        }
        InventoryLoader.button(btn, true, "Saving...");
        request("/due-settings/", {
            method: "PATCH",
            body: {
                default_due_days_after_sale: days,
                apply_pending: true
            }
        })
            .then(function (body) {
                if (!body || !body.isSuccess) {
                    InventoryToast.error((body && body.message) || "Failed to save due date settings.");
                    return;
                }
                saleDueDefaultDays = days;
                applyDefaultDueDateToForm();
                if (window.InventoryModal) {
                    InventoryModal.close("purchase-due-setting-modal");
                }
                InventoryToast.success(body.message || "Due date settings saved.");
                loadPurchases(currentPage);
            })
            .catch(function () {
                InventoryToast.error("Network error. Please try again.");
            })
            .finally(function () {
                InventoryLoader.button(btn, false);
            });
    }

    function preloadSaleFormData() {
        return loadProducts().catch(function () {
            products = [];
        }).then(function () {
            return Promise.all([
                loadPaymentTypes(),
                loadCustomers(),
                loadTaxes(),
                loadServices().catch(function () { services = []; }),
                loadInvoiceSettings(),
                loadSaleDueSetting()
            ]);
        }).catch(function () {
            /* Form preload failures must not block the sale list. */
        });
    }

    function loadPurchases(page) {
        currentPage = page || 1;
        InventoryLoader.show();

        return request(buildQuery(currentPage))
            .then(function (body) {
                if (body && body.isSuccess && body.data) {
                    renderPurchaseRows(body.data.items || []);
                    InventoryPagination.render("purchases-pagination", body.data.pagination, function (p) {
                        loadPurchases(p);
                    }, {
                        onPageSizeChange: function () {
                            loadPurchases(1);
                        }
                    });
                } else {
                    renderPurchaseRows([]);
                    InventoryPagination.render("purchases-pagination", null, function () {});
                    InventoryToast.error(body.message || "Failed to load sales.");
                }
            })
            .catch(function () {
                renderPurchaseRows([]);
                InventoryToast.error("Network error while loading sales.");
            })
            .finally(function () {
                InventoryLoader.hide();
            });
    }

    function collectItems() {
        var rows = document.querySelectorAll("#purchase-items-container .inv-mgmt-item-row");
        var items = [];
        var totalsByProduct = {};

        for (var i = 0; i < rows.length; i++) {
            var row = rows[i];
            var productId = row.querySelector(".inv-item-product").value;
            var quantity = Number(row.querySelector(".inv-item-qty").value || 0);
            var saleActualEl = row.querySelector(".inv-item-sale-actual");
            var unitPrice = getRowFinalSalePrice(row);
            if (!productId) continue;

            var product = getProduct(productId);
            if (!product) {
                InventoryToast.error("Selected product is no longer available.");
                return null;
            }

            if (!saleActualEl || saleActualEl.value === "") {
                InventoryToast.error("Enter an MRP price for " + product.name + ".");
                return null;
            }

            if (unitPrice < 0) {
                InventoryToast.error("Sale price cannot be negative.");
                return null;
            }

            var available = getRemainingQty(productId, row);
            var stockLimit = Number(product.quantity || 0) + getEditingStockBonus(productId);
            totalsByProduct[productId] = (totalsByProduct[productId] || 0) + quantity;
            if (totalsByProduct[productId] > stockLimit) {
                InventoryToast.error(
                    product.name + ": total quantity (" + formatQty(totalsByProduct[productId]) +
                    ") exceeds available stock (" + formatQty(stockLimit) + ")."
                );
                return null;
            }
            if (quantity > available) {
                InventoryToast.error(
                    product.name + ": quantity (" + formatQty(quantity) +
                    ") exceeds remaining stock (" + formatQty(available) + ")."
                );
                return null;
            }
            if (quantity <= 0) {
                InventoryToast.error("Quantity must be greater than zero.");
                return null;
            }

            items.push({
                id: row.dataset.saleLineId ? Number(row.dataset.saleLineId) : null,
                product_id: Number(productId),
                quantity: quantity,
                unit_price: unitPrice,
                list_price: getRowSellPrice(row),
                discount_type: getRowDiscountType(row),
                discount_value: getRowDiscountValue(row),
                distributor_discount_type: getRowDiscountType(row, ".inv-item-distributor-discount-type-toggle"),
                distributor_discount_value: getRowDiscountValue(row, ".inv-item-distributor-discount-value"),
                sale_tax_ids: row.dataset.savedTaxIds ? JSON.parse(row.dataset.savedTaxIds) : getRowTaxRate(row) > 0
                    ? InventoryTaxSelect.getSelected(row.querySelector(".inv-item-sale-gst")).map(function (id) { return Number(id); })
                    : [],
                discount_amount: getRowDiscountAmount(row, quantity),
                tax_amount: getRowTaxAmount(row, quantity)
            });
        }

        return items;
    }

    function addItemRow(data, silent) {
        if (!hasAvailableProducts(null)) {
            if (!silent) {
                InventoryToast.warning("No products with remaining stock available.");
            }
            return false;
        }
        var container = document.getElementById("purchase-items-container");
        container.appendChild(createItemRow(data));
        return true;
    }

    function resetForm(isSilent) {
        editingPurchaseId = null;
        editingPurchaseIsDraft = false;
        editingSaleStockByProduct = {};
        setFormMode("add");
        setSaleFormKind("service", { hideKindBar: false });
        loadInvoiceSettings("");
        loadCustomers("");
        InventoryApi.setDateInputValue(
            document.getElementById("purchase-date"),
            new Date().toISOString().slice(0, 10)
        );
        applyCustomerAddressesFromSelection("", false);
        document.getElementById("purchase-payment-type").value = "";
        togglePaymentTypePanel(false);
        clearSalePrintMetaForm();
        var paidInput = document.getElementById("purchase-paid-amount");
        if (paidInput) {
            paidInput.value = "";
            paidInput.dataset.manual = "0";
        }
        setSalePaidToggle(false);
        applyDefaultDueDateToForm();
        document.getElementById("purchase-items-container").innerHTML = "";
        addItemRow(null, isSilent !== false);
        updateSaleTotals();
        resetServiceForm();
    }

    function getSaleHeaderPayload(includeInvoiceSetting) {
        var paymentTypeEl = document.getElementById("purchase-payment-type");
        var paymentTypeId = paymentTypeEl ? paymentTypeEl.value : "";
        var customerId = document.getElementById("purchase-customer").value;
        var payload = {
            customer_id: customerId ? Number(customerId) : null,
            purchase_date: InventoryApi.getDateInputValue(document.getElementById("purchase-date")) || undefined,
            billing_address: document.getElementById("purchase-billing-address").value.trim(),
            shipping_address: document.getElementById("purchase-shipping-address").value.trim(),
            payment_type_id: paymentTypeId ? Number(paymentTypeId) : null
        };
        if (includeInvoiceSetting) {
            var invoiceSettingEl = document.getElementById("purchase-invoice-setting");
            var invoiceSettingId = invoiceSettingEl ? invoiceSettingEl.value : "";
            payload.invoice_setting_id = invoiceSettingId ? Number(invoiceSettingId) : null;
        }
        return payload;
    }

    function getServiceSaleHeaderPayload(includeInvoiceSetting) {
        var paymentTypeEl = document.getElementById("purchase-payment-type");
        var paymentTypeId = paymentTypeEl ? paymentTypeEl.value : "";
        var customerId = document.getElementById("purchase-customer").value;
        var termsEl = document.getElementById("purchase-invoice-terms");
        var payload = {
            customer_id: customerId ? Number(customerId) : null,
            sale_date: InventoryApi.getDateInputValue(document.getElementById("purchase-date")) || undefined,
            terms: termsEl ? termsEl.value.trim() : "",
            payment_type_id: paymentTypeId ? Number(paymentTypeId) : null
        };
        if (includeInvoiceSetting) {
            var invoiceSettingEl = document.getElementById("purchase-invoice-setting");
            var invoiceSettingId = invoiceSettingEl ? invoiceSettingEl.value : "";
            payload.invoice_setting_id = invoiceSettingId ? Number(invoiceSettingId) : null;
        }
        return payload;
    }

    function validateSaleItemsForSave() {
        var items = collectItems();
        if (!items || !items.length) {
            if (items !== null) {
                InventoryToast.error("Add at least one product the customer is purchasing.");
            }
            return null;
        }

        var rowCount = document.querySelectorAll("#purchase-items-container .inv-mgmt-item-row").length;
        if (items.length !== rowCount) {
            InventoryToast.error("Select an available product for each row.");
            return null;
        }
        return items;
    }

    function collectServiceItems() {
        var items = [];
        var rows = document.querySelectorAll("#purchase-service-items-container .inv-mgmt-item-row--service");
        for (var i = 0; i < rows.length; i += 1) {
            var row = rows[i];
            var serviceSelect = row.querySelector(".inv-item-service");
            var serviceId = serviceSelect ? serviceSelect.value : "";
            if (!serviceId) {
                return null;
            }
            var baseEl = row.querySelector(".inv-item-service-base");
            var baseRaw = baseEl ? String(baseEl.value || "").trim() : "";
            var basePrice = baseRaw === "" ? 0 : Number(baseRaw);
            if (isNaN(basePrice) || basePrice < 0) {
                InventoryToast.error("Enter a valid base price for each service.");
                if (baseEl) baseEl.focus();
                return false;
            }
            var taxRoot = row.querySelector(".inv-item-service-gst");
            var saleTaxIds = taxRoot && window.InventoryTaxSelect
                ? InventoryTaxSelect.getSelected(taxRoot).map(function (id) { return Number(id); }).slice(0, 1)
                : [];
            var rate = getServiceRowTaxRate(row);
            var taxAmount = rate > 0 ? computeGstAmount(basePrice, rate) : 0;
            items.push({
                service_id: Number(serviceId),
                base_price: roundMoney(basePrice),
                sale_tax_ids: saleTaxIds,
                tax_amount: taxAmount,
                gst_rate: rate,
                line_total: roundMoney(basePrice + taxAmount)
            });
        }
        return items;
    }

    function validateServiceSaleItemsForSave() {
        var rows = document.querySelectorAll("#purchase-service-items-container .inv-mgmt-item-row--service");
        if (!rows.length) {
            InventoryToast.error("Add at least one service.");
            return null;
        }
        var items = collectServiceItems();
        if (items === false) return null;
        if (items === null) {
            InventoryToast.error("Select a service for each row.");
            return null;
        }
        if (!items.length) {
            InventoryToast.error("Add at least one service.");
            return null;
        }
        return items;
    }

    function getUnpaidEditDueDatePayload() {
        var dueWrap = document.getElementById("purchase-due-date-wrap");
        if (!dueWrap || dueWrap.classList.contains("inv-hidden")) return {};
        var dueDateEl = document.getElementById("purchase-invoice-due-date");
        var dueDate = InventoryApi.getDateInputValue(dueDateEl);
        if (!dueDate) return null;
        return { due_date: dueDate };
    }

    function validatePaidAmountWithinBill() {
        if (!isPaidSegmentSelected()) return true;
        var paidAmount = getPaidAmountValue();
        if (paidAmount <= 0) return true;
        var billAmount = getBillAmount();
        if (paidAmount > billAmount + 0.0001) {
            InventoryToast.error(
                "Amount received (" + InventoryApi.formatMoney(paidAmount) +
                ") cannot be greater than the bill amount (" + InventoryApi.formatMoney(billAmount) + ")."
            );
            var paidInput = document.getElementById("purchase-paid-amount");
            if (paidInput) paidInput.focus();
            return false;
        }
        return true;
    }

    function validatePaymentFieldsForFinalize() {
        var isPaid = isFullPaymentReceived();
        if (shouldShowDueDateField()) {
            var dueDateEl = document.getElementById("purchase-invoice-due-date");
            if (!dueDateEl || !InventoryApi.getDateInputValue(dueDateEl)) {
                InventoryToast.error("Please enter a due date until the full bill amount is received.");
                if (dueDateEl) dueDateEl.focus();
                return null;
            }
        }

        if (isPaidSegmentSelected()) {
            var paidAmount = getPaidAmountValue();
            if (paidAmount <= 0) {
                InventoryToast.error("Please enter the amount received.");
                var paidInput = document.getElementById("purchase-paid-amount");
                if (paidInput) paidInput.focus();
                return null;
            }
            if (!validatePaidAmountWithinBill()) {
                return null;
            }
        }
        return isPaid;
    }

    function getSelectedInvoiceSettingId() {
        var invoiceSettingEl = document.getElementById("purchase-invoice-setting");
        if (!invoiceSettingEl || !invoiceSettingEl.value) return null;
        return Number(invoiceSettingEl.value);
    }

    function validateInvoiceSettingRequired() {
        var invoiceSettingEl = document.getElementById("purchase-invoice-setting");
        if (invoiceSettingEl && !invoiceSettingEl.closest(".inv-hidden")) {
            if (!invoiceSettingEl.value) {
                InventoryToast.error("Please select an invoice.");
                invoiceSettingEl.focus();
                return false;
            }
        }
        return true;
    }

    function validateSaleHeaderForCreate(requireInvoice) {
        if (requireInvoice !== false && !validateInvoiceSettingRequired()) {
            return false;
        }

        var customerId = document.getElementById("purchase-customer").value;
        if (!customerId) {
            InventoryToast.error("Please select a customer.");
            document.getElementById("purchase-customer").focus();
            return false;
        }
        return true;
    }

    function savePurchaseDraft() {
        if (saleFormKind === "service") {
            if (!validateSaleHeaderForCreate(false)) return;
            var serviceDraftItems = validateServiceSaleItemsForSave();
            if (!serviceDraftItems) return;

            var serviceDraftBtn = document.getElementById("purchase-save-draft-btn");
            InventoryLoader.button(serviceDraftBtn, true, "Saving...");

            request("/service-sales/", {
                method: "POST",
                body: Object.assign(getServiceSaleHeaderPayload(false), readPaymentIntentFromForm(), {
                    items: serviceDraftItems,
                    is_draft: true,
                    is_paid: false
                })
            })
                .then(function (body) {
                    if (body && body.isSuccess) {
                        if (body.data && body.data.id) {
                            saveSalePrintMeta(body.data.id, getSalePrintMetaFromForm());
                        }
                        InventoryToast.success(body.message || "Service sale saved as draft.");
                        resetForm(true);
                        InventoryPagePanel.showList(PURCHASES_LIST_PANEL);
                        loadPurchases(1);
                    } else {
                        var err = body.message || "Unable to save draft service sale.";
                        if (body.errors && body.errors.length) err = body.errors.join(" • ");
                        InventoryToast.error(err);
                    }
                })
                .catch(function () {
                    InventoryToast.error("Network error. Please try again.");
                })
                .finally(function () {
                    InventoryLoader.button(serviceDraftBtn, false);
                });
            return;
        }

        if (!validateSaleHeaderForCreate(false)) return;

        var items = validateSaleItemsForSave();
        if (!items) return;

        var btn = document.getElementById("purchase-save-draft-btn");
        InventoryLoader.button(btn, true, "Saving...");

        request("", {
            method: "POST",
            body: Object.assign(getSaleHeaderPayload(false), readPaymentIntentFromForm(), {
                items: items,
                is_draft: true,
                is_paid: false
            })
        })
            .then(function (body) {
                if (body && body.isSuccess) {
                    if (body.data && body.data.id) {
                        saveSalePrintMeta(body.data.id, getSalePrintMetaFromForm());
                    }
                    InventoryToast.success(body.message || "Sale saved as draft.");
                    resetForm(true);
                    InventoryPagePanel.showList(PURCHASES_LIST_PANEL);
                    loadPurchases(1);
                } else {
                    var err = body.message || "Unable to save draft sale.";
                    if (body.errors && body.errors.length) err = body.errors.join(" • ");
                    InventoryToast.error(err);
                }
            })
            .catch(function () {
                InventoryToast.error("Network error. Please try again.");
            })
            .finally(function () {
                InventoryLoader.button(btn, false);
            });
    }

    function readDueDateFromForm() {
        var dueDateEl = document.getElementById("purchase-invoice-due-date");
        if (!dueDateEl) return null;
        return InventoryApi.getDateInputValue(dueDateEl) || null;
    }

    function readPaymentIntentFromForm() {
        var isPaid = isFullPaymentReceived();
        var payload = {
            is_paid: !!isPaid,
            due_date: readDueDateFromForm()
        };
        if (isPaidSegmentSelected()) {
            var paidAmount = getPaidAmountValue();
            if (paidAmount > 0) payload.payment_amount = paidAmount;
        }
        return payload;
    }

    function saveDraftFinalizeMeta(purchaseId, paymentInfo) {
        var meta = loadSalePrintMeta(purchaseId) || {};
        if (paymentInfo && paymentInfo.is_paid) {
            meta.is_paid = true;
            meta.due_date = "";
        } else if (paymentInfo) {
            meta.is_paid = false;
            if (paymentInfo.due_date) meta.due_date = paymentInfo.due_date;
        }
        saveSalePrintMeta(purchaseId, meta);
    }

    function runDraftFinalize(purchaseId, paymentInfo, updatePayload, saleType) {
        saleType = saleType || "product";
        function finalizeRequest() {
            saveDraftFinalizeMeta(purchaseId, paymentInfo);
            return request(saleActionPath(purchaseId, saleType, "finalize"), {
                method: "POST",
                body: {
                    invoice_setting_id: paymentInfo.invoice_setting_id,
                    is_paid: !!paymentInfo.is_paid,
                    due_date: paymentInfo.is_paid ? null : (paymentInfo.due_date || null),
                    payment_amount: paymentInfo.payment_amount || null
                }
            });
        }

        if (updatePayload) {
            return request(saleDetailPath(purchaseId, saleType), {
                method: "PATCH",
                body: updatePayload
            }).then(function (body) {
                if (!body || !body.isSuccess) return body;
                return finalizeRequest();
            });
        }
        return finalizeRequest();
    }

    function finalizeDraftPurchase() {
        if (!editingPurchaseId || !editingPurchaseIsDraft) return;
        if (!validateSaleHeaderForCreate(true)) return;

        var isService = saleFormKind === "service";
        var items = isService ? validateServiceSaleItemsForSave() : validateSaleItemsForSave();
        if (!items) return;

        if (validatePaymentFieldsForFinalize() == null) return;

        var invoiceSettingId = getSelectedInvoiceSettingId();
        if (!invoiceSettingId) {
            InventoryToast.error("Please select an invoice before finalizing.");
            var invoiceSettingEl = document.getElementById("purchase-invoice-setting");
            if (invoiceSettingEl) invoiceSettingEl.focus();
            return;
        }

        var updatePayload = isService
            ? Object.assign(getServiceSaleHeaderPayload(false), { items: items })
            : Object.assign(getSaleHeaderPayload(false), { items: items });
        var paymentInfo = readPaymentIntentFromForm();
        paymentInfo.invoice_setting_id = invoiceSettingId;
        if (paymentInfo.is_paid) {
            paymentInfo.due_date = null;
        }

        var finalizeBtn = document.getElementById("purchase-finalize-btn");
        var updateBtn = document.getElementById("purchase-save-btn");
        InventoryLoader.show();
        InventoryLoader.button(finalizeBtn, true, "Finalizing...");

        runDraftFinalize(editingPurchaseId, paymentInfo, updatePayload, isService ? "service" : "product")
            .then(function (body) {
                if (body && body.isSuccess) {
                    InventoryToast.success(body.message || "Draft sale finalized.");
                    resetForm(true);
                    InventoryPagePanel.showList(PURCHASES_LIST_PANEL);
                    loadPurchases(currentPage);
                } else {
                    var err = (body && body.message) || "Unable to finalize draft sale.";
                    if (body && body.errors && body.errors.length) err = body.errors.join(" • ");
                    InventoryToast.error(err);
                }
            })
            .catch(function () {
                InventoryToast.error("Network error. Please try again.");
            })
            .finally(function () {
                InventoryLoader.hide();
                InventoryLoader.button(finalizeBtn, false);
                InventoryLoader.button(updateBtn, false);
            });
    }

    function savePurchase() {
        if (saleFormKind === "service") {
            if (editingPurchaseId && editingPurchaseIsDraft) {
                if (!validateSaleHeaderForCreate(false)) return;
                var draftServiceItems = validateServiceSaleItemsForSave();
                if (!draftServiceItems) return;
                if (!validatePaidAmountWithinBill()) return;

                var serviceDraftBtn = document.getElementById("purchase-save-btn");
                InventoryLoader.button(serviceDraftBtn, true, "Updating...");
                request(saleDetailPath(editingPurchaseId, "service"), {
                    method: "PATCH",
                    body: Object.assign(
                        getServiceSaleHeaderPayload(false),
                        readPaymentIntentFromForm(),
                        { items: draftServiceItems }
                    )
                })
                    .then(function (body) {
                        if (body && body.isSuccess) {
                            saveSalePrintMeta(editingPurchaseId, getSalePrintMetaFromForm());
                            InventoryToast.success(body.message || "Draft service sale updated successfully.");
                            resetForm(true);
                            InventoryPagePanel.showList(PURCHASES_LIST_PANEL);
                            loadPurchases(currentPage);
                        } else {
                            var err = body.message || "Unable to update draft service sale.";
                            if (body.errors && body.errors.length) err = body.errors.join(" • ");
                            InventoryToast.error(err);
                        }
                    })
                    .catch(function () {
                        InventoryToast.error("Network error. Please try again.");
                    })
                    .finally(function () {
                        InventoryLoader.button(serviceDraftBtn, false);
                    });
                return;
            }

            if (editingPurchaseId) {
                var serviceDuePayload = getUnpaidEditDueDatePayload();
                if (serviceDuePayload === null) {
                    InventoryToast.error("Please enter a due date for unpaid sales.");
                    var serviceDueDateEl = document.getElementById("purchase-invoice-due-date");
                    if (serviceDueDateEl) serviceDueDateEl.focus();
                    return;
                }

                var serviceEditBtn = document.getElementById("purchase-save-btn");
                InventoryLoader.button(serviceEditBtn, true, "Updating...");
                request(saleDetailPath(editingPurchaseId, "service"), {
                    method: "PATCH",
                    body: Object.assign(getServiceSaleHeaderPayload(false), serviceDuePayload)
                })
                    .then(function (body) {
                        if (body && body.isSuccess) {
                            saveSalePrintMeta(editingPurchaseId, getSalePrintMetaFromForm());
                            InventoryToast.success(body.message || "Service sale updated successfully.");
                            resetForm(true);
                            InventoryPagePanel.showList(PURCHASES_LIST_PANEL);
                            loadPurchases(currentPage);
                        } else {
                            var err = body.message || "Unable to update service sale.";
                            if (body.errors && body.errors.length) err = body.errors.join(" • ");
                            InventoryToast.error(err);
                        }
                    })
                    .catch(function () {
                        InventoryToast.error("Network error. Please try again.");
                    })
                    .finally(function () {
                        InventoryLoader.button(serviceEditBtn, false);
                    });
                return;
            }

            if (!validateSaleHeaderForCreate()) return;
            var serviceItems = validateServiceSaleItemsForSave();
            if (!serviceItems) return;
            if (!validatePaidAmountWithinBill()) return;
            if (validatePaymentFieldsForFinalize() === null) return;

            var serviceSaveBtn = document.getElementById("purchase-save-btn");
            InventoryLoader.button(serviceSaveBtn, true, "Saving...");

            request("/service-sales/", {
                method: "POST",
                body: Object.assign(
                    getServiceSaleHeaderPayload(true),
                    readPaymentIntentFromForm(),
                    { items: serviceItems, is_draft: false }
                )
            })
                .then(function (body) {
                    if (body && body.isSuccess) {
                        if (body.data && body.data.id) {
                            saveSalePrintMeta(body.data.id, getSalePrintMetaFromForm());
                        }
                        InventoryToast.success(body.message || "Service sale added successfully.");
                        resetForm(true);
                        InventoryPagePanel.showList(PURCHASES_LIST_PANEL);
                        loadPurchases(1);
                    } else {
                        var err = body.message || "Unable to create service sale.";
                        if (body.errors && body.errors.length) err = body.errors.join(" • ");
                        InventoryToast.error(err);
                    }
                })
                .catch(function () {
                    InventoryToast.error("Network error. Please try again.");
                })
                .finally(function () {
                    InventoryLoader.button(serviceSaveBtn, false);
                });
            return;
        }

        if (!validateSaleHeaderForCreate()) return;

        if (editingPurchaseId && editingPurchaseIsDraft) {
            var items = validateSaleItemsForSave();
            if (!items) return;
            if (!validatePaidAmountWithinBill()) return;

            var draftBtn = document.getElementById("purchase-save-btn");
            InventoryLoader.button(draftBtn, true, "Updating...");

            request("/" + editingPurchaseId + "/", {
                method: "PATCH",
                body: Object.assign(getSaleHeaderPayload(false), readPaymentIntentFromForm(), { items: items })
            })
                .then(function (body) {
                    if (body && body.isSuccess) {
                        saveSalePrintMeta(editingPurchaseId, getSalePrintMetaFromForm());
                        InventoryToast.success(body.message || "Draft sale updated successfully.");
                        resetForm(true);
                        InventoryPagePanel.showList(PURCHASES_LIST_PANEL);
                        loadPurchases(currentPage);
                    } else {
                        var err = body.message || "Unable to update draft sale.";
                        if (body.errors && body.errors.length) err = body.errors.join(" • ");
                        InventoryToast.error(err);
                    }
                })
                .catch(function () {
                    InventoryToast.error("Network error. Please try again.");
                })
                .finally(function () {
                    InventoryLoader.button(draftBtn, false);
                });
            return;
        }

        if (editingPurchaseId) {
            var duePayload = getUnpaidEditDueDatePayload();
            if (duePayload === null) {
                InventoryToast.error("Please enter a due date for unpaid sales.");
                var dueDateEl = document.getElementById("purchase-invoice-due-date");
                if (dueDateEl) dueDateEl.focus();
                return;
            }

            var btn = document.getElementById("purchase-save-btn");
            InventoryLoader.button(btn, true, "Updating...");
            request("/" + editingPurchaseId + "/", {
                method: "PATCH",
                body: Object.assign(getSaleHeaderPayload(false), duePayload)
            })
                .then(function (body) {
                    if (body && body.isSuccess) {
                        saveSalePrintMeta(editingPurchaseId, getSalePrintMetaFromForm());
                        InventoryToast.success(body.message || "Sale updated successfully.");
                        resetForm(true);
                        InventoryPagePanel.showList(PURCHASES_LIST_PANEL);
                        loadPurchases(currentPage);
                    } else {
                        var err = body.message || "Unable to update sale.";
                        if (body.errors && body.errors.length) err = body.errors.join(" • ");
                        InventoryToast.error(err);
                    }
                })
                .catch(function () {
                    InventoryToast.error("Network error. Please try again.");
                })
                .finally(function () {
                    InventoryLoader.button(btn, false);
                });
            return;
        }

        var items = validateSaleItemsForSave();
        if (!items) return;

        var isPaid = validatePaymentFieldsForFinalize();
        if (isPaid == null) return;

        var btn = document.getElementById("purchase-save-btn");
        InventoryLoader.button(btn, true, "Saving...");

        request("", {
            method: "POST",
            body: Object.assign(getSaleHeaderPayload(true), getPaymentPayloadForSave(isPaid), {
                items: items,
                is_draft: false
            })
        })
            .then(function (body) {
                if (body && body.isSuccess) {
                    if (body.data && body.data.id) {
                        saveSalePrintMeta(body.data.id, getSalePrintMetaFromForm());
                    }
                    InventoryToast.success(body.message || "Sale added successfully. Stock has been updated.");
                    resetForm(true);
                    InventoryPagePanel.showList(PURCHASES_LIST_PANEL);
                    loadPurchases(1);
                } else {
                    var err = body.message || "Unable to create sale.";
                    if (body.errors && body.errors.length) err = body.errors.join(" • ");
                    InventoryToast.error(err);
                }
            })
            .catch(function () {
                InventoryToast.error("Network error. Please try again.");
            })
            .finally(function () {
                InventoryLoader.button(btn, false);
            });
    }

    function init() {
        InventoryApi.watch(["/api/catalog", "/api/settings", "/api/products", "/api/customers", "/api/invoicing", "/api/purchases"], function () {
            return Promise.all([loadTaxes(), loadProducts({ includeProductIds: getIncludedEditProductIds() }), loadCustomers(), loadPaymentTypes(), loadInvoiceSettings(), loadSaleDueSetting()]).then(function () {
                refreshAllProductSelects(true);
                document.querySelectorAll("#purchase-items-container .inv-mgmt-item-row").forEach(function (row) {
                    if (row.dataset.saleLineId) return;
                    updateRowPricing(row);
                });
                return loadPurchases(currentPage);
            });
        });
        if (init._wired) return;
        init._wired = true;

        if (window.InventoryPagePanel) {
            InventoryPagePanel.init();
        }

        function boot() {
            if (!InventoryBusiness.getActiveId()) return;
            applyFiltersFromUrl();
                loadPurchases(1);
            preloadSaleFormData();
        }

        function initSaleTable() {
            if (!window.InventoryColumnCustomize) return null;
            try {
                return getColumnCtrl();
            } catch (err) {
                console.error("Failed to initialize sale table columns.", err);
                return null;
            }
        }

        InventoryBusiness.whenReady(function () {
            initSaleTable();
            boot();
            if (window.InventorySidebar && InventorySidebar.consumeAddAction()) {
                var openSaleBtn = document.getElementById("purchase-open-modal-btn");
                if (openSaleBtn) openSaleBtn.click();
            }
        });
        window.addEventListener("inventory:business-changed", function () {
            initSaleTable();
            boot();
        });

        var setDueDateBtn = document.getElementById("purchases-set-due-date-btn");
        if (setDueDateBtn) setDueDateBtn.addEventListener("click", openDueSettingModal);

        var dueSettingSaveBtn = document.getElementById("purchase-due-setting-save-btn");
        if (dueSettingSaveBtn) dueSettingSaveBtn.addEventListener("click", saveDueSetting);

        var purchaseDateEl = document.getElementById("purchase-date");
        if (purchaseDateEl) {
            purchaseDateEl.addEventListener("change", function () {
                if (!editingPurchaseId) {
                    applyDefaultDueDateToForm();
                }
            });
        }

        if (window.InventoryModal) {
            InventoryModal.wire("purchase-due-setting-modal");
            InventoryModal.wire("purchase-add-service-modal");
        }

        document.querySelectorAll(".inv-sale-kind-btn").forEach(function (kindBtn) {
            kindBtn.addEventListener("click", function () {
                if (editingPurchaseId) return;
                setSaleFormKind(kindBtn.getAttribute("data-sale-kind") || "product", { hideKindBar: false });
            });
        });

        var addServiceItemBtn = document.getElementById("purchase-add-service-item-btn");
        if (addServiceItemBtn) {
            addServiceItemBtn.addEventListener("click", function () {
                if (!services.length) {
                    InventoryToast.warning("No services found. Add a service first.");
                }
                addServiceItemRow(null);
            });
        }

        var addServiceSaveBtn = document.getElementById("purchase-add-service-save-btn");
        if (addServiceSaveBtn) {
            addServiceSaveBtn.addEventListener("click", saveNewServiceFromModal);
        }
        var newServiceNameEl = document.getElementById("purchase-new-service-name");
        if (newServiceNameEl) {
            newServiceNameEl.addEventListener("keydown", function (e) {
                if (e.key === "Enter") {
                    e.preventDefault();
                    saveNewServiceFromModal();
                }
            });
        }

        var openSaleBtnEl = document.getElementById("purchase-open-modal-btn");
        if (openSaleBtnEl) openSaleBtnEl.addEventListener("click", function () {
            if (!InventoryBusiness.getActiveId()) {
                InventoryToast.error("Select or create a business first.");
                return;
            }
            loadProducts().then(function () {
                return Promise.all([
                    loadTaxes(),
                    loadPaymentTypes(),
                    loadCustomers(),
                    loadServices().catch(function () { services = []; }),
                    loadInvoiceSettings()
                ]);
            }).then(function () {
                resetForm(true);
                if (!hasAvailableProducts(null)) {
                    InventoryToast.warning("No products with remaining stock available.");
                }
                if (!invoiceSettings.length) {
                    InventoryToast.warning("No invoice settings found. Add one in Settings first.");
                }
                if (!customers.length) {
                    InventoryToast.warning("No customers found. Add a customer first.");
                }
                InventoryPagePanel.showPanel(PURCHASES_LIST_PANEL, PURCHASES_FORM_PANEL);
                var invoiceSelect = document.getElementById("purchase-invoice-setting");
                if (invoiceSelect && !invoiceSelect.closest(".inv-hidden")) {
                    invoiceSelect.focus();
                } else {
                    var customerSelect = document.getElementById("purchase-customer");
                    if (customerSelect) customerSelect.focus();
                }
            });
        });

        document.querySelectorAll(".purchase-add-item-btn").forEach(function (addItemBtnEl) {
            addItemBtnEl.addEventListener("click", function () {
            if (!hasAvailableProducts(null)) {
                InventoryToast.warning("No products with remaining stock available.");
                return;
            }
            addItemRow(null, true);
        });
        });

        var saveBtnEl = document.getElementById("purchase-save-btn");
        if (saveBtnEl) saveBtnEl.addEventListener("click", savePurchase);
        var draftBtn = document.getElementById("purchase-save-draft-btn");
        if (draftBtn) draftBtn.addEventListener("click", savePurchaseDraft);
        var finalizeBtn = document.getElementById("purchase-finalize-btn");
        if (finalizeBtn) finalizeBtn.addEventListener("click", finalizeDraftPurchase);
        wireSalePaidToggle();
        setSalePaidToggle(false);

        var searchEl = document.getElementById("purchases-search");
        var saleTypeFilterEl = document.getElementById("purchases-sale-type-filter");
        var invoiceStatusFilterEl = document.getElementById("purchases-invoice-status-filter");
        var dateFromEl = document.getElementById("purchases-date-from");
        var dateToEl = document.getElementById("purchases-date-to");
        var clearBtn = document.getElementById("purchases-clear-filters");

        if (searchEl) {
            searchEl.addEventListener("input", function () {
                window.clearTimeout(searchTimer);
                searchTimer = window.setTimeout(function () {
                    loadPurchases(1);
                }, 300);
            });
        }
        if (saleTypeFilterEl) {
            saleTypeFilterEl.addEventListener("change", function () {
                loadPurchases(1);
            });
        }
        if (invoiceStatusFilterEl) {
            invoiceStatusFilterEl.addEventListener("change", function () {
                loadPurchases(1);
            });
        }
        if (dateFromEl) dateFromEl.addEventListener("change", function () { loadPurchases(1); });
        if (dateToEl) dateToEl.addEventListener("change", function () { loadPurchases(1); });
        if (clearBtn) clearBtn.addEventListener("click", clearFilters);

        var paymentTypeAddBtn = document.getElementById("purchase-payment-type-add-btn");
        var paymentTypeSaveBtn = document.getElementById("purchase-payment-type-save-btn");
        var paymentTypeCancelBtn = document.getElementById("purchase-payment-type-cancel-btn");
        var customerAddBtn = document.getElementById("purchase-customer-add-btn");
        var invoiceAddBtn = document.getElementById("purchase-invoice-add-btn");
        if (customerAddBtn) {
            customerAddBtn.addEventListener("click", openAddCustomerModal);
        }
        if (invoiceAddBtn) {
            invoiceAddBtn.addEventListener("click", openAddInvoiceModal);
        }
        document.querySelectorAll(".purchase-tax-add-btn").forEach(function (taxAddBtn) {
            taxAddBtn.addEventListener("click", openAddTaxModal);
        });

        window.addEventListener("inventory:customer-created", function (e) {
            var customer = e.detail && e.detail.customer;
            loadCustomers(customer && customer.id ? customer.id : "").then(function () {
                if (customer && customer.id) {
                    applyCustomerAddressesFromSelection(customer.id, false);
                }
            });
        });

        window.addEventListener("inventory:invoice-setting-created", function (e) {
            var invoiceSetting = e.detail && e.detail.invoiceSetting;
            loadInvoiceSettings(invoiceSetting && invoiceSetting.id ? invoiceSetting.id : "");
        });

        window.addEventListener("inventory:tax-created", function () {
            loadTaxes().then(function () {
                refreshAllRowTaxSelects();
            });
        });

        var customerSelect = document.getElementById("purchase-customer");
        if (customerSelect) {
            customerSelect.addEventListener("change", onCustomerSelectionChange);
        }

        if (paymentTypeAddBtn) {
            paymentTypeAddBtn.addEventListener("click", function () {
                var panel = document.getElementById("purchase-payment-type-new-panel");
                togglePaymentTypePanel(panel.classList.contains("inv-hidden"));
            });
        }
        if (paymentTypeSaveBtn) paymentTypeSaveBtn.addEventListener("click", saveNewPaymentType);
        if (paymentTypeCancelBtn) {
            paymentTypeCancelBtn.addEventListener("click", function () {
                togglePaymentTypePanel(false);
            });
        }

        if (window.InventoryModal) {
            InventoryModal.wire("purchase-add-payment-modal");
            InventoryModal.wire("purchase-payment-history-modal");
            ["purchase-add-payment-modal", "purchase-payment-history-modal"].forEach(function (modalId) {
                var modal = document.getElementById(modalId);
                if (!modal || modal.dataset.paymentModalCloseWired === "1") return;
                modal.dataset.paymentModalCloseWired = "1";
                modal.addEventListener("click", function (e) {
                    if (
                        e.target.closest("[data-modal-close]") ||
                        e.target.classList.contains("inv-modal-backdrop")
                    ) {
                        if (window.InventorySearchableSelect) {
                            InventorySearchableSelect.closeAll();
                        }
                    }
                });
            });
        }

        var addPaymentSaveBtn = document.getElementById("purchase-add-payment-save-btn");
        if (addPaymentSaveBtn) addPaymentSaveBtn.addEventListener("click", submitAddPayment);

        var addPaymentAmountEl = document.getElementById("purchase-add-payment-amount");
        if (addPaymentAmountEl) {
            addPaymentAmountEl.addEventListener("input", function () {
                syncAddPaymentDueField(addPaymentPendingAmount);
            });
        }

        var addPaymentDateEl = document.getElementById("purchase-add-payment-date");
        if (addPaymentDateEl) {
            addPaymentDateEl.addEventListener("change", function () {
                syncAddPaymentNextDueMin();
                syncAddPaymentDueField(addPaymentPendingAmount);
            });
        }

        var viewAddPaymentBtn = document.getElementById("purchase-view-add-payment-btn");
        if (viewAddPaymentBtn) {
            viewAddPaymentBtn.addEventListener("click", function () {
                if (viewingPurchaseId) {
                    openAddPaymentModal(
                        viewingPurchaseId,
                        viewingPurchase && viewingPurchase.sale_type
                    );
                }
            });
        }

        var viewPaymentHistoryBtn = document.getElementById("purchase-view-payment-history-btn");
        if (viewPaymentHistoryBtn) {
            viewPaymentHistoryBtn.addEventListener("click", function () {
                if (viewingPurchaseId) {
                    openPaymentHistoryModal(
                        viewingPurchaseId,
                        viewingPurchase && viewingPurchase.sale_type
                    );
                }
            });
        }

        var tbody = document.getElementById("purchases-table-body");
        if (tbody) {
            tbody.addEventListener("click", function (e) {
                var toggleBtn = e.target.closest(".inv-products-sold-toggle");
                if (toggleBtn) {
                    e.preventDefault();
                    var wrap = toggleBtn.closest(".inv-products-sold");
                    if (!wrap) return;
                    var collapsed = wrap.querySelector(".inv-products-sold-collapsed");
                    var expanded = wrap.querySelector(".inv-products-sold-expanded");
                    if (collapsed) collapsed.classList.toggle("inv-hidden");
                    if (expanded) expanded.classList.toggle("inv-hidden");
                    return;
                }

                var viewBtn = e.target.closest(".inv-purchase-view");
                if (viewBtn) {
                    if (viewBtn.getAttribute("data-sale-type") === "service") {
                        openViewServiceSale(viewBtn.getAttribute("data-id"));
                    } else {
                        openViewPurchase(viewBtn.getAttribute("data-id"));
                    }
                    return;
                }

                var editBtn = e.target.closest(".inv-purchase-edit");
                if (editBtn) {
                    if (editBtn.getAttribute("data-sale-type") === "service") {
                        openEditServiceSale(editBtn.getAttribute("data-id"));
                    } else {
                        openEditPurchase(editBtn.getAttribute("data-id"));
                    }
                    return;
                }

                var printBtn = e.target.closest(".inv-purchase-print");
                if (printBtn) {
                    exportSalesPrint([{
                        id: printBtn.getAttribute("data-id"),
                        sale_type: printBtn.getAttribute("data-sale-type") || "product"
                    }]);
                    return;
                }

                var sendPdfBtn = e.target.closest(".inv-purchase-send-pdf");
                if (sendPdfBtn) {
                    sendSaleInvoicePdf(
                        sendPdfBtn.getAttribute("data-id"),
                        sendPdfBtn.getAttribute("data-sale-type") || "product"
                    );
                    return;
                }

                var addPaymentBtn = e.target.closest(".inv-purchase-add-payment");
                if (addPaymentBtn) {
                    openAddPaymentModal(
                        addPaymentBtn.getAttribute("data-id"),
                        addPaymentBtn.getAttribute("data-sale-type") || "product"
                    );
                    return;
                }

                var historyBtn = e.target.closest(".inv-purchase-invoice-history");
                if (historyBtn) {
                    openPaymentHistoryModal(
                        historyBtn.getAttribute("data-id"),
                        historyBtn.getAttribute("data-sale-type") || "product"
                    );
                    return;
                }

                var cancelBtn = e.target.closest(".inv-purchase-mark-cancelled");
                if (cancelBtn) {
                    markPurchaseCancelled(
                        cancelBtn.getAttribute("data-id"),
                        cancelBtn.getAttribute("data-sale-type") || "product"
                    );
                }
            });
        }
    }

    return {
        init: init,
        saveSalePrintTermsOverrides: saveSalePrintTermsOverrides
    };
})();
